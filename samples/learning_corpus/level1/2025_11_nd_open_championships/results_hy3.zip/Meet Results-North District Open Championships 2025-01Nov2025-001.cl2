A08V3      02Meet Results                  Hy-Tek, Ltd         WMM 8.0Fh Hy-Tek, Ltd         866-456-511111022025                                    MM40    N52
B18        North District Open ChampionshRegent Walk                                 Aberdeen            ABAB24 1SX  GBR 1101202511022025   0        S 000   N68
C18          NANXAberdeen Asc                  Aberdeen        Christopher Komar     59 Cove Gardens       Cove Bay, Aberdeen  ABAB12 3QR  GBR               N03
D08        Boyapati, Juven             90035629    A   0928200916MM 1002107 UNOV11012025 1:13.44S 1:12.34S                   5 1 0 0 67           9502      NN60
D390035629                                                                                                                                                   N58
G08            Boyapati, Juven             90035629    1 2  50C   34.70 1:12.34                                                                P             N55
D08        Bradley, Jack               90035205    A   1130201114MM 4001101 UNOV11012025 4:59.18S 4:56.90S                   6 7 0 0 44           9501      NN59
D390035205                                                                                                                                                   N48
G08            Bradley, Jack               90035205    1 8  50C   31.64 1:08.27 1:45.49 2:23.49 3:01.48 3:39.98 4:19.37 4:56.90                P             N09
D08        Bradley, Jack               90035205    A   1130201114MM 1003528 UNOV11022025 1:22.30S 1:20.88S                   2 2     30           9503      NN29
G08            Bradley, Jack               90035205    1 2  50C   38.14 1:20.88                                                                P             N54
D08        Bradley, Jack               90035205    A   1130201114MM 1003408 UNOV11022025 1:22.30S 1:20.88S                   6 2 0 0 66           9503      NN59
G08            Bradley, Jack               90035205    1 2  50C   38.14 1:20.88                                                                P             N54
D08        Brown, Kiren                90023367    A   0514200817MM 2005526 UNOV11022025 2:24.60S 2:22.65S                   2 4      4           9505      NN29
D390023367                                                                                                                                                   N48
G08            Brown, Kiren                90023367    1 4  50C   28.54 1:05.42 1:50.61 2:22.65                                                P             N85
D08        Brown, Kiren                90023367    A   0514200817MM  503103 UNOV11012025   34.80S   33.65S                   2 9 0 0 44           9503      NN98
D08        Brown, Kiren                90023367    A   0514200817MM 2004105 UNOV11012025 2:24.00S 2:22.77S                   4 8 0 0 17           9504      NN49
G08            Brown, Kiren                90023367    1 4  50C   31.07 1:07.69 1:46.60 2:22.77                                                P             N95
D08        Brown, Kiren                90023367    A   0514200817MM  504111 UNOV11012025   26.80S   27.29S                   5 9 0 0 22           9504      NN98
D08        Brown, Kiren                90023367    A   0514200817MM 1004410 UNOV11022025 1:00.70S 1:00.59S                   2 8 0 0 14           9504      NN39
G08            Brown, Kiren                90023367    1 2  50C   28.05 1:00.59                                                                P             N44
D08        Brown, Kiren                90023367    A   0514200817MM  501412 UNOV11022025   25.77S   25.99S                   3 7 0 0 34           9501      NN98
D08        Brown, Kiren                90023367    A   0514200817MM 2005406 UNOV11022025 2:24.60S 2:22.65S                   6 4 0 0 35           9505      NN49
G08            Brown, Kiren                90023367    1 4  50C   28.54 1:05.42 1:50.61 2:22.65                                                P             N85
D08        Bruce, Aiden                90014731    A   0721200817MM 4001101 UNOV11012025 4:07.54S 4:12.98S          4:20.20S 4 3 1 2  5 10  1.   0950100    NN60
D390014731                                                                                                                                                   N48
G08            Bruce, Aiden                90014731    1 8  50C   28.15   59.40 1:31.11 2:03.07 2:35.50 3:07.95 3:40.85 4:12.98                P             N28
G08            Bruce, Aiden                90014731    1 8  50C   28.53   59.64 1:32.40 2:05.33 2:38.70 3:12.66 3:46.82 4:20.20                F             N28
D08        Bruce, Aiden                90014731    A   0721200817MM  503103 UNOV11012025   30.70S   31.87S                   5 7 0 0 22           9503      NN68
D08        Bruce, Aiden                90014731    A   0721200817MM 1001109 UNOV11012025   55.90S   57.76S                   1 2 0 0 47           9501      NN78
G08            Bruce, Aiden                90014731    1 2  50C   27.09   57.76                                                                P             N93
D08        Bruce, Aiden                90014731    A   0721200817MM 2003113 UNOV11012025 2:28.22S 2:36.38S                   4 2 0 0 22           9503      NN19
G08            Bruce, Aiden                90014731    1 4  50C   34.75 1:15.03 1:55.35 2:36.38                                                P             N65
D08        Bruce, Aiden                90014731    A   0721200817MM 2001402 UNOV11022025 1:56.01S 1:58.61S          2:02.77S 4 3 1 8  9 10  1.   0950100    NN70
G08            Bruce, Aiden                90014731    1 4  50C   27.40   57.43 1:27.79 1:58.61                                                P             N45
G08            Bruce, Aiden                90014731    1 4  50C   27.20   57.74 1:30.11 2:02.77                                                F             N25
D08        Bruce, Aiden                90014731    A   0721200817MM 1003408 UNOV11022025 1:07.92S 1:11.28S                   2 6 0 0 21           9503      NN19
G08            Bruce, Aiden                90014731    1 2  50C   33.14 1:11.28                                                                P             N14
D08        Bruce, Aiden                90014731    A   0721200817MM  501412 UNOV11022025   24.96S   25.97S                   5 8 0 0 33           9501      NN78
D08        Craik, Beth                 90011925    A   1207200817FF 2001102 UNOV11012025 2:17.05S 2:14.14S                   1 9 0 0 18           9501      NN68
D390011925                                                                                                                                                   N48
G08            Craik, Beth                 90011925    1 4  50C   30.68 1:04.74 1:39.69 2:14.14                                                P             N25
D08        Craik, Beth                 90011925    A   1207200817FF 2005106 UNOV11012025 2:31.16S 2:31.42S                   2 7 0 0 15           9505      NN78
G08            Craik, Beth                 90011925    1 4  50C   32.86 1:11.67 1:56.37 2:31.42                                                P             N25
D08        Craik, Beth                 90011925    A   1207200817FF 1003108 UNOV11012025 1:16.90S 1:19.12S                   4 2 0 0 16           9503      NN78
G08            Craik, Beth                 90011925    1 2  50C   37.35 1:19.12                                                                P             N73
D08        Craik, Beth                 90011925    A   1207200817FF  503403 UNOV11022025   34.60S   35.05S                   7 2 0 0 11           9503      NN18
D08        Craik, Beth                 90011925    A   1207200817FF 1002407 UNOV11022025 1:09.40S 1:09.40S                   3 8 0 0 17           9502      NN78
G08            Craik, Beth                 90011925    1 2  50C   33.88 1:09.40                                                                P             N83
D08        Craik, Beth                 90011925    A   1207200817FF 1001409 UNOV11022025 1:01.60S 1:01.35S                   1 7 0 0 23           9501      NN68
G08            Craik, Beth                 90011925    1 2  50C   29.77 1:01.35                                                                P             N83
D08        Craik, Beth                 90011925    A   1207200817FF 2003413 UNOV11022025 2:49.13S 2:51.01S                   4 7 0 0 19           9503      NN78
G08            Craik, Beth                 90011925    1 4  50C   39.10 1:23.22 2:07.21 2:51.01                                                P             N15
D08        Hayes, Ciaran               1293892     A   0818200520MM 1002107 UNOV11012025 1:06.60S 1:07.48S                   7 4 0 0 44           9502      NN59
D31293892                                                                                                                                                    N48
G08            Hayes, Ciaran               1293892     1 2  50C   31.71 1:07.48                                                                P             N54
D08        Hayes, Ciaran               1293892     A   0818200520MM  503103 UNOV11012025   33.14S   32.77S                   3 2 0 0 31           9503      NN09
D08        Hayes, Ciaran               1293892     A   0818200520MM 2003113 UNOV11012025 2:40.68S 2:36.12S                   1 5 0 0 20           9503      NN59
G08            Hayes, Ciaran               1293892     1 4  50C   34.85 1:14.99 1:55.85 2:36.12                                                P             N16
D08        Hayes, Ciaran               1293892     A   0818200520MM 4005201 UNOV11012025 4:58.80S                   5:07.26S     4 0    31       99505      NN59
G08            Hayes, Ciaran               1293892     1 8  50C   31.79 1:10.46 1:51.49 2:31.67 3:13.96 3:57.55 4:32.81 5:07.26                F             N98
D08        Hayes, Ciaran               1293892     A   0818200520MM  502404 UNOV11022025   30.15S   30.04S                   3 7 0 0 33           9502      NN98
D08        Hayes, Ciaran               1293892     A   0818200520MM 2005406 UNOV11022025 2:21.20S 2:24.31S                   2 0 0 0 39           9505      NN59
G08            Hayes, Ciaran               1293892     1 4  50C   30.86 1:09.20 1:49.56 2:24.31                                                P             N06
D08        Hayes, Ciaran               1293892     A   0818200520MM 1003408 UNOV11022025 1:13.45S 1:12.57S                   1 5 0 0 28           9503      NN59
G08            Hayes, Ciaran               1293892     1 2  50C   34.16 1:12.57                                                                P             N54
D08        Lamont, Lexie               90010212    A   0511200916FF 2001102 UNOV11012025 2:07.50S 2:06.20S          2:06.83S 2 5 1 6  4  5  6.   5950100    NN01
D390010212                                                                                                                                                   N48
G08            Lamont, Lexie               90010212    1 4  50C   28.97 1:01.49 1:33.69 2:06.20                                                P             N16
G08            Lamont, Lexie               90010212    1 4  50C   29.28 1:01.48 1:33.95 2:06.83                                                F             N16
D08        Lamont, Lexie               90010212    A   0511200916FF 2005106 UNOV11012025 2:22.70S 2:23.10S          2:24.82S 2 5 1 3  3  5  6.   5950500    NN01
G08            Lamont, Lexie               90010212    1 4  50C   32.11 1:09.35 1:49.68 2:23.10                                                P             N16
G08            Lamont, Lexie               90010212    1 4  50C   31.33 1:09.55 1:50.64 2:24.82                                                F             N06
D08        Lamont, Lexie               90010212    A   0511200916FF 1004110 UNOV11012025 1:08.42S 1:10.47S          1:07.82S 3 0 1 9 27 13       39504      NN80
G08            Lamont, Lexie               90010212    1 2  50C   32.89 1:10.47                                                                P             N74
G08            Lamont, Lexie               90010212    1 2  50C   31.77 1:07.82                                                                F             N64
D08        Lamont, Lexie               90010212    A   0511200916FF 1001409 UNOV11022025   58.60S   58.96S            58.87S 4 6 2 1  8  6  5.   6950100    NN60
G08            Lamont, Lexie               90010212    1 2  50C   28.09   58.96                                                                P             N54
G08            Lamont, Lexie               90010212    1 2  50C   28.06   58.87                                                                F             N44
D08        Lamont, Lexie               90010212    A   0511200916FF 2003413 UNOV11022025 2:42.00S 2:41.39S          2:41.85S 4 3 1 3  3  4  7.   4950300    NN01
G08            Lamont, Lexie               90010212    1 4  50C   36.61 1:18.33 1:59.66 2:41.39                                                P             N26
G08            Lamont, Lexie               90010212    1 4  50C   37.13 1:19.14 2:00.60 2:41.85                                                F             N06
D08        Lamont, Lexie               90010212    A   0511200916FF 4005501 UNOV11022025 5:10.60S                   5:03.84S     5 1     2  9.   2950500    NN89
G08            Lamont, Lexie               90010212    1 8  50C   33.50 1:12.09 1:51.42 2:29.07 3:10.81 3:53.49 4:29.80 5:03.84                F             N09
D08        McCaul, Austin              90014317    A   0211201015MM 2001522 UNOV11022025 2:10.41S 2:08.24S                   2 6     10           9501      NN69
D390014317                                                                                                                                                   N48
G08            McCaul, Austin              90014317    1 4  50C   29.28 1:02.14 1:36.17 2:08.24                                                P             N36
D08        McCaul, Austin              90014317    A   0211201015MM 2004105 UNOV11012025 2:27.40S 2:27.68S                   3 8 0 0 24           9504      NN99
G08            McCaul, Austin              90014317    1 4  50C   31.38 1:08.54 1:47.52 2:27.68                                                P             N46
D08        McCaul, Austin              90014317    A   0211201015MM 2002414 UNOV11022025 2:24.90S 2:21.86S                   1 5 0 0 26           9502      NN99
G08            McCaul, Austin              90014317    1 4  50C   32.15 1:08.28 1:45.25 2:21.86                                                P             N36
D08        McCaul, Austin              90014317    A   0211201015MM 2001402 UNOV11022025 2:10.41S 2:08.24S                   6 6 0 0 47           9501      NN89
G08            McCaul, Austin              90014317    1 4  50C   29.28 1:02.14 1:36.17 2:08.24                                                P             N36
D08        Moffat, Frida               90030863    A   0325201114FF 1003108 UNOV11012025 1:28.31S 1:27.46S                   6 8 0 0 46           9503      NN59
D390030863                                                                                                                                                   N48
G08            Moffat, Frida               90030863    1 2  50C   41.57 1:27.46                                                                P             N64
D08        Moffat, Frida               90030863    A   0325201114FF 2003533 UNOV11022025 3:09.01S 3:05.82S                   2 0     10           9503      NN29
G08            Moffat, Frida               90030863    1 4  50C   41.87 1:28.97 2:18.49 3:05.82                                                P             N16
D08        Moffat, Frida               90030863    A   0325201114FF 2003413 UNOV11022025 3:09.01S 3:05.82S                   6 0 0 0 46           9503      NN59
G08            Moffat, Frida               90030863    1 4  50C   41.87 1:28.97 2:18.49 3:05.82                                                P             N16
D08        Park, Eve                   90023349    A   0504201114FF 1004110 UNOV11012025 1:16.09S 1:18.17S                   5 6 0 0 50           9504      NN08
D390023349                                                                                                                                                   N48
G08            Park, Eve                   90023349    1 2  50C   37.06 1:18.17                                                                P             N13
D08        Reid, Rebecca               894235      A   0112200223FF  502104 UNOV11012025   29.24S   29.92S            29.98S 4 5 2 2  5  7  4.   7950200    NN00
D3894235                                                                                                                                                     N38
D08        Reid, Rebecca               894235      A   0112200223FF 2005106 UNOV11012025 2:17.52S 2:23.53S          2:21.40S 3 4 1 6  4  3  8.   3950500    NN60
G08            Reid, Rebecca               894235      1 4  50C   30.95 1:06.41 1:49.16 2:23.53                                                P             N75
G08            Reid, Rebecca               894235      1 4  50C   32.30 1:07.35 1:49.25 2:21.40                                                F             N65
D08        Reid, Rebecca               894235      A   0112200223FF  501112 UNOV11012025   26.80S   27.98S                   7 6 0 0 14           9501      NN68
D08        Reid, Rebecca               894235      A   0112200223FF 2002114 UNOV11012025 2:17.52S 2:20.94S          2:19.81S 2 4 1 5  2  2  9.   2950200    NN60
G08            Reid, Rebecca               894235      1 4  50C   32.31 1:07.82 1:44.09 2:20.94                                                P             N75
G08            Reid, Rebecca               894235      1 4  50C   32.58 1:07.89 1:43.49 2:19.81                                                F             N85
D08        Reid, Rebecca               894235      A   0112200223FF  503403 UNOV11022025   33.12S   33.80S            33.42S 5 4 2 3  3  3  8.   3950300    NN89
D08        Reid, Rebecca               894235      A   0112200223FF 1002407 UNOV11022025 1:03.36S 1:04.68S          1:05.40S 4 5 2 2  5  7  4.   7950200    NN60
G08            Reid, Rebecca               894235      1 2  50C   31.18 1:04.68                                                                P             N34
G08            Reid, Rebecca               894235      1 2  50C   31.37 1:05.40                                                                F             N24
D08        Reid, Rebecca               894235      A   0112200223FF 1001409 UNOV11022025   57.90S   59.71S          1:00.54S 4 3 2 9 11  9  2.   9950100    NN30
G08            Reid, Rebecca               894235      1 2  50C   28.80   59.71                                                                P             N14
G08            Reid, Rebecca               894235      1 2  50C   28.68 1:00.54                                                                F             N24
D08        Robertson, Alanah           90013543    A   0327200817FF  501112 UNOV11012025   28.80S   29.15S                   4 1 0 0 35           9501      NN60
D390013543                                                                                                                                                   N48
D08        Robertson, Jasmine          90019970    A   0807200916FF 1001529 UNOV11022025 1:03.88S 1:02.26S                   3 1      8           9501      NN51
D390019970                                                                                                                                                   N58
G08            Robertson, Jasmine          90019970    1 2  50C   29.83 1:02.26                                                                P             N86
D08        Robertson, Jasmine          90019970    A   0807200916FF  502104 UNOV11012025   31.62S   31.80S            31.54S 3 1 1 1 20 15       59502      NN22
D08        Robertson, Jasmine          90019970    A   0807200916FF 2005106 UNOV11012025 2:37.54S 2:38.06S                   1 3 0 0 32           9505      NN81
G08            Robertson, Jasmine          90019970    1 4  50C   32.38 1:09.63 2:00.14 2:38.06                                                P             N28
D08        Robertson, Jasmine          90019970    A   0807200916FF  501112 UNOV11012025   29.00S   28.66S            28.57S 4 9 1 9 25 18       89501      NN42
D08        Robertson, Jasmine          90019970    A   0807200916FF 2002114 UNOV11012025 2:31.60S 2:31.51S                   2 1 0 0 19           9502      NN71
G08            Robertson, Jasmine          90019970    1 4  50C   34.77 1:13.23 1:52.26 2:31.51                                                P             N28
D08        Robertson, Jasmine          90019970    A   0807200916FF 1002407 UNOV11022025 1:08.30S 1:07.70S          1:07.86S 4 1 1 5 13 13       39502      NN03
G08            Robertson, Jasmine          90019970    1 2  50C   32.64 1:07.70                                                                P             N86
G08            Robertson, Jasmine          90019970    1 2  50C   32.82 1:07.86                                                                F             N86
D08        Robertson, Jasmine          90019970    A   0807200916FF 1001409 UNOV11022025 1:03.88S 1:02.26S                   7 1 0 0 34           9501      NN81
G08            Robertson, Jasmine          90019970    1 2  50C   29.83 1:02.26                                                                P             N86
D08        Scott, Matthew              1293900     A   0124200421MM 4001101 UNOV11012025 4:30.60S 4:27.63S                   2 0 0 0 21           9501      NN00
D31293900                                                                                                                                                    N38
G08            Scott, Matthew              1293900     1 8  50C   28.80 1:01.15 1:34.23 2:08.12 2:42.55 3:17.69 3:53.19 4:27.63                P             N59
D08        Scott, Matthew              1293900     A   0124200421MM  504111 UNOV11012025   28.10S   28.62S                   2 0 0 0 35           9504      NN59
D08        Scott, Matthew              1293900     A   0124200421MM 2001402 UNOV11022025 2:04.80S 2:04.57S                   1 2 0 0 33           9501      NN00
G08            Scott, Matthew              1293900     1 4  50C   28.70 1:00.20 1:32.55 2:04.57                                                P             N56
D08        Scott, Matthew              1293900     A   0124200421MM  501412 UNOV11022025   26.10S   26.45S                   2 5 0 0 42           9501      NN59
D08        Scott, Suzanna              90044438    A   0726201213FF 1002527 UNOV11022025 1:14.50S 1:11.27S                   1 7      1           9502      NN99
D390044438                                                                                                                                                   N58
G08            Scott, Suzanna              90044438    1 2  50C   34.09 1:11.27                                                                P             N35
D08        Scott, Suzanna              90044438    A   0726201213FF  502104 UNOV11012025   34.00S   33.39S                   1 5 0 0 32           9502      NN69
D08        Scott, Suzanna              90044438    A   0726201213FF 2002114 UNOV11012025 2:40.80S 2:37.24S                   1 8 0 0 29           9502      NN20
G08            Scott, Suzanna              90044438    1 4  50C   36.06 1:15.68 1:56.99 2:37.24                                                P             N86
D08        Scott, Suzanna              90044438    A   0726201213FF 1002407 UNOV11022025 1:14.50S 1:11.27S                   5 7 0 0 23           9502      NN20
G08            Scott, Suzanna              90044438    1 2  50C   34.09 1:11.27                                                                P             N35
D08        Slane, Charlie              90021661    A   1007201015MM 2003113 UNOV11012025 2:50.60S 2:42.18S                   7 1 0 0 34           9503      NN89
D390021661                                                                                                                                                   N48
G08            Slane, Charlie              90021661    1 4  50C   36.45 1:18.39 2:01.65 2:42.18                                                P             N46
D08        Slane, Charlie              90021661    A   1007201015MM 1003528 UNOV11022025 1:14.53S 1:13.93S                   5 5      5           9503      NN69
G08            Slane, Charlie              90021661    1 2  50C   34.46 1:13.93                                                                P             N94
D08        Slane, Charlie              90021661    A   1007201015MM  503103 UNOV11012025   33.78S   33.60S                   3 8 0 0 41           9503      NN39
D08        Slane, Charlie              90021661    A   1007201015MM 1003408 UNOV11022025 1:14.53S 1:13.93S                   9 5 0 0 36           9503      NN99
G08            Slane, Charlie              90021661    1 2  50C   34.46 1:13.93                                                                P             N94
D08        Smith, Kalila               90015835    A   1221201015FF 1001529 UNOV11022025 1:02.49S 1:03.31S                   3 5     12           9501      NN39
D390015835                                                                                                                                                   N58
G08            Smith, Kalila               90015835    1 2  50C   29.78 1:03.31                                                                P             N74
D08        Smith, Kalila               90015835    A   1221201015FF  502104 UNOV11012025   29.80S   29.97S            30.15S 5 3 2 7  6  9  2.   9950200    NN30
D08        Smith, Kalila               90015835    A   1221201015FF 1004110 UNOV11012025 1:04.20S 1:04.88S          1:04.68S 4 6 2 8  8  6  5.   6950400    NN01
G08            Smith, Kalila               90015835    1 2  50C   32.09 1:04.88                                                                P             N74
G08            Smith, Kalila               90015835    1 2  50C   30.44 1:04.68                                                                F             N64
D08        Smith, Kalila               90015835    A   1221201015FF 2002114 UNOV11012025 2:32.40S 2:33.63S                   4 8 0 0 21           9502      NN59
G08            Smith, Kalila               90015835    1 4  50C   34.84 1:14.77 1:55.63 2:33.63                                                P             N16
D08        Smith, Kalila               90015835    A   1221201015FF 2004405 UNOV11022025 2:28.28S 2:26.46S          2:24.64S 4 6 1 2  5  4  7.   4950400    NN11
G08            Smith, Kalila               90015835    1 4  50C   32.10 1:11.88 1:49.55 2:26.46                                                P             N16
G08            Smith, Kalila               90015835    1 4  50C   31.96 1:09.78 1:50.16 2:24.64                                                F             N16
D08        Smith, Kalila               90015835    A   1221201015FF 1002407 UNOV11022025 1:08.50S 1:09.15S          1:08.85S 3 1 1 2 16 15       59502      NN80
G08            Smith, Kalila               90015835    1 2  50C   34.29 1:09.15                                                                P             N74
G08            Smith, Kalila               90015835    1 2  50C   33.50 1:08.85                                                                F             N64
D08        Smith, Kalila               90015835    A   1221201015FF 1001409 UNOV11022025 1:02.49S 1:03.31S                   7 5 0 0 41           9501      NN59
G08            Smith, Kalila               90015835    1 2  50C   29.78 1:03.31                                                                P             N74
D08        Snape, Willow               90040940    A   0408201411FF  503403 UNOV11022025   37.90S   38.73S                   3 6 0 0 48           9503      NN39
D390040940                                                                                                                                                   N48
D08        Snowdon, Lucas              90014689    A   1219200916MM 1003528 UNOV11022025 1:15.50S 1:12.23S                   4 5      1           9503      NN00
D390014689                                                                                                                                                   N58
G08            Snowdon, Lucas              90014689    1 2  50C   33.25 1:12.23                                                                P             N25
D08        Snowdon, Lucas              90014689    A   1219200916MM 4001101 UNOV11012025 4:25.22S 4:24.98S                   2 6 0 0 18           9501      NN30
G08            Snowdon, Lucas              90014689    1 8  50C   28.17 1:00.02 1:33.26 2:07.16 2:41.37 3:15.82 3:50.68 4:24.98                P             N69
D08        Snowdon, Lucas              90014689    A   1219200916MM 1002107 UNOV11012025 1:06.41S 1:03.67S          1:04.38S 1 1 1 1 19 17       79502      NN61
G08            Snowdon, Lucas              90014689    1 2  50C   30.61 1:03.67                                                                P             N25
G08            Snowdon, Lucas              90014689    1 2  50C   31.17 1:04.38                                                                F             N25
D08        Snowdon, Lucas              90014689    A   1219200916MM 2001402 UNOV11022025 2:04.73S 2:01.25S                   1 6 0 0 18           9501      NN20
G08            Snowdon, Lucas              90014689    1 4  50C   27.39   57.76 1:29.52 2:01.25                                                P             N56
D08        Snowdon, Lucas              90014689    A   1219200916MM 2005406 UNOV11022025 2:21.69S 2:20.66S                   2 9 0 0 26           9505      NN40
G08            Snowdon, Lucas              90014689    1 4  50C   30.48 1:05.30 1:48.17 2:20.66                                                P             N76
D08        Snowdon, Lucas              90014689    A   1219200916MM  501412 UNOV11022025   26.40S   25.81S            25.68S 2 0 1 0 28 18       89501      NN90
D08        Snowdon, Lucas              90014689    A   1219200916MM 1001109 UNOV11012025   58.82S   54.97S            58.54S 5 8 1 3 20 19       99501      NN11
G08            Snowdon, Lucas              90014689    1 2  50C   26.19   54.97                                                                P             N15
G08            Snowdon, Lucas              90014689    1 2  50C   27.02   58.54                                                                F             N05
D08        Snowdon, Lucas              90014689    A   1219200916MM 1003408 UNOV11022025 1:15.50S 1:12.23S          1:12.11S 8 5 1 8 25 17       79503      NN61
G08            Snowdon, Lucas              90014689    1 2  50C   33.25 1:12.23                                                                P             N25
G08            Snowdon, Lucas              90014689    1 2  50C   33.66 1:12.11                                                                F             N25
C18SS      SSNADXAberdeen Dolphin Swimming ClubAberdeen Dol    RGU Sport                                   Aberdeen            ScAB10 7JE                    N60
D08SS      Abernethy, Ethan M          90031862    AGBR0722200916MM  503103 UNOV11012025   34.63S   34.16S                   2 7 0 0 50           9503      NN71
D390031862      Ethan                                                                                                                                        N20
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 1002107 UNOV11012025 1:13.12S 1:11.02S                   5 2 0 0 62           9502      NN03
D390033914      Oliver / Ollie                                                                                                                               N62
G08SS          Bialonski, Olivier R        90033914    1 2  50C   34.91 1:11.02                                                                P             N47
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 2002534 UNOV11022025 2:38.09S 2:35.88S                   2 7     10           9502      NN03
G08SS          Bialonski, Olivier R        90033914    1 4  50C   36.33 1:15.81 1:56.18 2:35.88                                                P             N09
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 1003528 UNOV11022025 1:20.50S 1:20.92S                   3 0     31           9503      NN92
G08SS          Bialonski, Olivier R        90033914    1 2  50C   38.90 1:20.92                                                                P             N57
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 2003113 UNOV11012025 2:59.28S 2:57.51S                   5 4 0 0 61           9503      NN23
G08SS          Bialonski, Olivier R        90033914    1 4  50C   39.60 1:24.38 2:10.79 2:57.51                                                P             N09
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 1003408 UNOV11022025 1:20.50S 1:20.92S                   7 0 0 0 67           9503      NN13
G08SS          Bialonski, Olivier R        90033914    1 2  50C   38.90 1:20.92                                                                P             N57
D08SS      Bialonski, Olivier R        90033914    AGBR0911201114MM 2002414 UNOV11022025 2:38.09S 2:35.88S                   6 7 0 0 48           9502      NN23
G08SS          Bialonski, Olivier R        90033914    1 4  50C   36.33 1:15.81 1:56.18 2:35.88                                                P             N09
D08SS      Brodie, Andrew I            1180653     AGBR0422200520MM 1002107 UNOV11012025   56.10S   56.89S            55.83S 3 4 2 5  2  2  9.   2950200    NN12
D31180653                                                                                                                                                    N38
G08SS          Brodie, Andrew I            1180653     1 2  50C   26.80   56.89                                                                P             N55
G08SS          Brodie, Andrew I            1180653     1 2  50C   26.28   55.83                                                                F             N45
D08SS      Brodie, Andrew I            1180653     AGBR0422200520MM  502404 UNOV11022025   25.60S   25.91S            25.78S 4 4 2 3  3  3  7.   3950250    NN02
D08SS      Brodie, Andrew I            1180653     AGBR0422200520MM 2002414 UNOV11022025 2:02.10S 2:03.58S          2:01.88S 4 4 1 3  3  3  8.   3950200    NN72
G08SS          Brodie, Andrew I            1180653     1 4  50C   27.69   57.99 1:29.80 2:03.58                                                P             N07
G08SS          Brodie, Andrew I            1180653     1 4  50C   28.21   58.48 1:30.31 2:01.88                                                F             N86
D08SS      Chesher, Madeleine R        90031680    AGBR0301201015FF 1003108 UNOV11012025 1:24.06S 1:28.21S                   1 9 0 0 48           9503      NN72
D390031680      Madeleine                                                                                                                                    N71
G08SS          Chesher, Madeleine R        90031680    1 2  50C   42.46 1:28.21                                                                P             N27
D08SS      Chesher, Madeleine R        90031680    AGBR0301201015FF  503403 UNOV11022025   38.10S   39.53S                   3 1 0 0 54           9503      NN22
D08SS      Chesher, Madeleine R        90031680    AGBR0301201015FF 2003533 UNOV11022025 3:08.59S 3:15.76S                   2 8     16           9503      NN72
G08SS          Chesher, Madeleine R        90031680    1 4  50C   43.17 1:33.27 2:24.08 3:15.76                                                P             N78
D08SS      Chesher, Madeleine R        90031680    AGBR0301201015FF 2003413 UNOV11022025 3:08.59S 3:15.76S                   6 8 0 0 52           9503      NN82
G08SS          Chesher, Madeleine R        90031680    1 4  50C   43.17 1:33.27 2:24.08 3:15.76                                                P             N78
D08SS      Clubb, Ailsa M              90006961    AGBR0109200817FF  502104 UNOV11012025   30.41S   31.83S                   5 2 0 0 21           9502      NN99
D390006961                                                                                                                                                   N58
D08SS      Clubb, Ailsa M              90006961    AGBR0109200817FF 1004110 UNOV11012025 1:06.30S      NSS                   3 7 0 0  0           9504      NN10
G08SS          Clubb, Ailsa M              90006961    1 2  50C                                                                                P             N73
D08SS      Clubb, Ailsa M              90006961    AGBR0109200817FF 1002407 UNOV11022025 1:05.42S 1:09.74S                   2 3 0 0 20           9502      NN50
G08SS          Clubb, Ailsa M              90006961    1 2  50C   33.33 1:09.74                                                                P             N94
D08SS      Clubb, Ailsa M              90006961    AGBR0109200817FF  504411 UNOV11022025   27.60S   29.31S            29.72S 5 4 2 0  9 10  1.   0950400    NN31
D08SS      Clubb, Heather C            90021395    AGBR0324201015FF  502104 UNOV11012025   29.80S   30.78S            29.87S 4 3 1 4 12 11       19502      NN81
D390021395                                                                                                                                                   N48
D08SS      Clubb, Heather C            90021395    AGBR0324201015FF 2002114 UNOV11012025 2:23.88S 2:27.11S          2:24.78S 3 3 1 9 10  9  2.   9950200    NN82
G08SS          Clubb, Heather C            90021395    1 4  50C   32.97 1:10.26 1:48.78 2:27.11                                                P             N17
G08SS          Clubb, Heather C            90021395    1 4  50C   32.15 1:08.27 1:45.71 2:24.78                                                F             N17
D08SS      Clubb, Heather C            90021395    AGBR0324201015FF 1002407 UNOV11022025 1:06.08S 1:07.53S          1:05.42S 2 6 1 4 11 11       19502      NN42
G08SS          Clubb, Heather C            90021395    1 2  50C   31.80 1:07.53                                                                P             N65
G08SS          Clubb, Heather C            90021395    1 2  50C   31.16 1:05.42                                                                F             N55
D08SS      Clubb, Heather C            90021395    AGBR0324201015FF  504411 UNOV11022025   29.60S   30.54S            30.67S 5 1 1 2 21 16       69504      NN71
D08SS      Cook, Harry S               90019286    AGBR0905201015MM 1002107 UNOV11012025   58.00S   57.81S            57.13S 2 5 2 3  3  4  7.   4950200    NN21
D390019286      Harry                                                                                                                                        N40
G08SS          Cook, Harry S               90019286    1 2  50C   27.72   57.81                                                                P             N64
G08SS          Cook, Harry S               90019286    1 2  50C   27.41   57.13                                                                F             N54
D08SS      Cook, Harry S               90019286    AGBR0905201015MM 1001109 UNOV11012025   53.00S   57.10S                   4 2 0 0 40           9501      NN99
G08SS          Cook, Harry S               90019286    1 2  50C   26.48   57.10                                                                P             N64
D08SS      Cook, Harry S               90019286    AGBR0905201015MM  502404 UNOV11022025   26.30S   26.16S            26.09S 5 5 2 6  4  5  6.   5950200    NN21
D08SS      Cook, Harry S               90019286    AGBR0905201015MM  501412 UNOV11022025   23.80S   24.11S            24.72S 5 3 2 7  5 10  1.   0950100    NN11
D08SS      Cook, Harry S               90019286    AGBR0905201015MM 2002414 UNOV11022025 2:14.20S 2:13.02S          2:13.41S 2 3 1 8  8  8  3.   8950200    NN91
G08SS          Cook, Harry S               90019286    1 4  50C   31.31 1:05.70 1:39.27 2:13.02                                                P             N26
G08SS          Cook, Harry S               90019286    1 4  50C   30.00 1:03.43 1:37.99 2:13.41                                                F             N16
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2005526 UNOV11022025 2:26.70S 2:28.37S                   1 3     16           9505      NN61
D390019806      Anatole                                                                                                                                      N01
G08SS          Guises, Anatole             90019806    1 4  50C   30.52 1:08.71 1:53.30 2:28.37                                                P             N57
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 1002107 UNOV11012025 1:08.00S 1:05.22S                   6 6 0 0 30           9502      NN61
G08SS          Guises, Anatole             90019806    1 2  50C   30.20 1:05.22                                                                P             N95
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2003113 UNOV11012025 2:48.30S 2:46.95S                   8 6 0 0 45           9503      NN81
G08SS          Guises, Anatole             90019806    1 4  50C   36.83 1:20.37 2:04.17 2:46.95                                                P             N57
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2001522 UNOV11022025 2:13.10S 2:08.15S                   2 7      9           9501      NN41
G08SS          Guises, Anatole             90019806    1 4  50C   28.24 1:01.04 1:35.14 2:08.15                                                P             N47
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2004105 UNOV11012025 2:22.00S 2:23.98S                   4 1 0 0 19           9504      NN71
G08SS          Guises, Anatole             90019806    1 4  50C   30.24 1:06.87 1:44.99 2:23.98                                                P             N67
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 1004410 UNOV11022025 1:01.20S 1:02.34S          1:02.33S 3 0 1 7 25 17       79504      NN92
G08SS          Guises, Anatole             90019806    1 2  50C   29.01 1:02.34                                                                P             N06
G08SS          Guises, Anatole             90019806    1 2  50C   29.60 1:02.33                                                                F             N06
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2001402 UNOV11022025 2:13.10S 2:08.15S                   6 7 0 0 46           9501      NN61
G08SS          Guises, Anatole             90019806    1 4  50C   28.24 1:01.04 1:35.14 2:08.15                                                P             N47
D08SS      Guises, Anatole             90019806    AGBR1021200916MM 2005406 UNOV11022025 2:26.70S 2:28.37S                   5 3 0 0 54           9505      NN81
G08SS          Guises, Anatole             90019806    1 4  50C   30.52 1:08.71 1:53.30 2:28.37                                                P             N57
D08SS      Guises, Emilien             90023801    AGBR1012201114MM 2005526 UNOV11022025 2:27.40S 2:25.48S                   2 6      8           9505      NN41
D390023801      Emilien                                                                                                                                      N01
G08SS          Guises, Emilien             90023801    1 4  50C   31.18                 2:25.48                                                P             N06
D08SS      Guises, Emilien             90023801    AGBR1012201114MM 1003408 UNOV11022025 1:14.30S 1:14.26S                   1 8 0 0 38           9503      NN61
G08SS          Guises, Emilien             90023801    1 2  50C   33.50 1:14.26                                                                P             N95
D08SS      Guises, Emilien             90023801    AGBR1012201114MM 2004105 UNOV11012025 2:32.40S      DQS                   3 9 0 0  0           9504      NN21
G08SS          Guises, Emilien             90023801    1 4  50C   31.77 1:09.38 1:49.05 2:31.39                                                P             N57
D08SS      Guises, Emilien             90023801    AGBR1012201114MM 2003113 UNOV11012025 2:47.00S 2:42.92S                   6 5 0 0 39           9503      NN61
G08SS          Guises, Emilien             90023801    1 4  50C   35.16 1:16.99 2:00.76 2:42.92                                                P             N57
D08SS      Guises, Emilien             90023801    AGBR1012201114MM 2005406 UNOV11022025 2:27.40S 2:25.48S                   6 6 0 0 45           9505      NN71
G08SS          Guises, Emilien             90023801    1 4  50C   31.18                 2:25.48                                                P             N06
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM  503103 UNOV11012025   29.10S   30.20S            30.76S 7 3 3 9 10 10  1.   0950300    NN82
D390008802      Atanas                                                                                                                                       N60
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM 1001109 UNOV11012025   54.60S   55.41S            56.78S 4 0 1 1 24 17       79501      NN62
G08SS          Irinkov, Atanas M           90008802    1 2  50C   26.13   55.41                                                                P             N06
G08SS          Irinkov, Atanas M           90008802    1 2  50C   27.23   56.78                                                                F             N06
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM  504111 UNOV11012025   25.90S   27.01S            26.42S 3 2 1 5 15 11       19504      NN42
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM 1003408 UNOV11022025 1:08.51S 1:08.03S          1:07.49S 3 2 2 9 10  9  2.   9950300    NN63
G08SS          Irinkov, Atanas M           90008802    1 2  50C   31.35 1:08.03                                                                P             N26
G08SS          Irinkov, Atanas M           90008802    1 2  50C   31.84 1:07.49                                                                F             N26
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM 1004410 UNOV11022025   59.50S 1:02.57S                   4 7 0 0 27           9504      NN81
G08SS          Irinkov, Atanas M           90008802    1 2  50C   28.52 1:02.57                                                                P             N36
D08SS      Irinkov, Atanas M           90008802    AGBR0708200916MM  501412 UNOV11022025   24.10S   24.98S            24.83S 4 6 1 5 14 12       29501      NN52
D08SS      King, Olivia J              90002713    AGBR1118200718FF  502104 UNOV11012025   32.90S   34.61S                   4 9 0 0 38           9502      NN10
D390002713                                                                                                                                                   N48
D08SS      King, Olivia J              90002713    AGBR1118200718FF  501112 UNOV11012025   28.75S   29.64S                   4 7 0 0 49           9501      NN10
D08SS      King, Olivia J              90002713    AGBR1118200718FF  504411 UNOV11022025   30.60S   31.63S                   4 9 0 0 37           9504      NN10
D08SS      King, Olivia J              90002713    AGBR1118200718FF 1001529 UNOV11022025 1:02.60S 1:05.15S                   2 5     27           9501      NN40
G08SS          King, Olivia J              90002713    1 2  50C   31.14 1:05.15                                                                P             N94
D08SS      King, Olivia J              90002713    AGBR1118200718FF 1001409 UNOV11022025 1:02.60S 1:05.15S                   6 5 0 0 60           9501      NN50
G08SS          King, Olivia J              90002713    1 2  50C   31.14 1:05.15                                                                P             N94
D08SS      Laing, Eilish R             90033920    AGBR0409201213FF  503403 UNOV11022025   39.82S   39.62S                   1 3 0 0 55           9503      NN50
D390033920      Eilish                                                                                                                                       N60
D08SS      Macrae, Jessica E           90015701    AGBR0901201015FF 2004405 UNOV11022025 2:47.50S 2:46.21S                   2 0 0 0 23           9504      NN51
D390015701                                                                                                                                                   N48
G08SS          Macrae, Jessica E           90015701    1 4  50C   36.35 1:18.19 2:02.07 2:46.21                                                P             N47
D08SS      Macrae, Jessica E           90015701    AGBR0901201015FF  504411 UNOV11022025   30.40S   32.22S                   4 7 0 0 43           9504      NN90
D08SS      Macrae, Jessica E           90015701    AGBR0901201015FF 2005106 UNOV11012025 2:42.62S 2:55.98S                   6 6 0 0 52           9505      NN61
G08SS          Macrae, Jessica E           90015701    1 4  50C   36.84 1:21.47 2:14.73 2:55.98                                                P             N57
D08SS      Macrae, Jessica E           90015701    AGBR0901201015FF 1004110 UNOV11012025 1:16.63S 1:13.32S                   5 2 0 0 38           9504      NN51
G08SS          Macrae, Jessica E           90015701    1 2  50C   33.87 1:13.32                                                                P             N06
D08SS      Prusik, Adam                1291815     AGBR1123200817MM 1002107 UNOV11012025   59.34S   59.64S          1:01.53S 2 3 2 1  7  9  2.   9950200    NN51
D31291815                                                                                                                                                    N38
G08SS          Prusik, Adam                1291815     1 2  50C   28.93   59.64                                                                P             N64
G08SS          Prusik, Adam                1291815     1 2  50C   28.95 1:01.53                                                                F             N74
D08SS      Prusik, Adam                1291815     AGBR1123200817MM  504111 UNOV11012025   26.40S   27.28S                   5 8 0 0 21           9504      NN99
D08SS      Prusik, Adam                1291815     AGBR1123200817MM  502404 UNOV11022025   27.61S   27.96S                   5 6 0 0 14           9502      NN99
D08SS      Prusik, Adam                1291815     AGBR1123200817MM 1004410 UNOV11022025 1:00.60S 1:02.16S                   3 8 0 0 24           9504      NN30
G08SS          Prusik, Adam                1291815     1 2  50C   28.49 1:02.16                                                                P             N74
D08SS      Prusik, Adam                1291815     AGBR1123200817MM  501412 UNOV11022025   25.00S   25.62S                   4 8 0 0 25           9501      NN89
D08SS      Rattray, Lucas              90021667    AGBR1116200916MM 1002107 UNOV11012025 1:05.51S 1:09.98S                   4 9 0 0 58           9502      NN51
D390021667                                                                                                                                                   N58
G08SS          Rattray, Lucas              90021667    1 2  50C   32.84 1:09.98                                                                P             N85
D08SS      Rattray, Lucas              90021667    AGBR1116200916MM  502404 UNOV11022025   29.60S   30.64S                   4 9 0 0 43           9502      NN90
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF  502104 UNOV11012025   32.60S   32.83S            32.74S 3 0 1 9 27 19       99502      NN82
D390011180                                                                                                                                                   N48
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF 1004110 UNOV11012025 1:07.60S 1:10.65S                   3 8 0 0 28           9504      NN22
G08SS          Reekie-Ayala, Iona A        90011180    1 2  50C   32.38 1:10.65                                                                P             N66
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF  501112 UNOV11012025   29.00S   29.78S                   3 4 0 0 52           9501      NN71
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF  504411 UNOV11022025   29.80S   31.23S            30.81S 5 0 1 9 29 17       79504      NN82
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF 1001529 UNOV11022025 1:03.10S      NSS                   2 6      0           9501      NN71
G08SS          Reekie-Ayala, Iona A        90011180    1 2  50C                                                                                P             N45
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF  502104SUNOV11012025   32.83S            32.41S              1 5     1       1  02      NN41
D08SS      Reekie-Ayala, Iona A        90011180    AGBR0327201015FF 1001409 UNOV11022025 1:03.10S      NSS                   6 6 0 0  0           9501      NN81
G08SS          Reekie-Ayala, Iona A        90011180    1 2  50C                                                                                P             N45
D08SS      Sainsbury, Matthew          90021670    AGBR0615200916MM 1003528 UNOV11022025 1:20.12S 1:14.31S                   5 0      6           9503      NN72
D390021670      Matthew                                                                                                                                      N11
G08SS          Sainsbury, Matthew          90021670    1 2  50C   34.43 1:14.31                                                                P             N37
D08SS      Sainsbury, Matthew          90021670    AGBR0615200916MM 1002107 UNOV11012025 1:11.44S 1:08.50S                   7 0 0 0 50           9502      NN03
G08SS          Sainsbury, Matthew          90021670    1 2  50C   32.56 1:08.50                                                                P             N47
D08SS      Sainsbury, Matthew          90021670    AGBR0615200916MM 2003113 UNOV11012025 2:42.71S 2:42.11S                   1 7 0 0 33           9503      NN03
G08SS          Sainsbury, Matthew          90021670    1 4  50C   35.60 1:16.62 1:59.07 2:42.11                                                P             N88
D08SS      Sainsbury, Matthew          90021670    AGBR0615200916MM  502404 UNOV11022025   30.78S   30.98S                   2 6 0 0 45           9502      NN62
D08SS      Sainsbury, Matthew          90021670    AGBR0615200916MM 1003408 UNOV11022025 1:20.12S 1:14.31S                   9 0 0 0 39           9503      NN03
G08SS          Sainsbury, Matthew          90021670    1 2  50C   34.43 1:14.31                                                                P             N37
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF 1003108 UNOV11012025 1:18.20S 1:19.20S                   2 1 0 0 17           9503      NN90
D390009041                                                                                                                                                   N48
G08SS          Shand, Rebecca              90009041    1 2  50C   37.33 1:19.20                                                                P             N35
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF  501112 UNOV11012025   27.90S   28.82S                   8 0 0 0 29           9501      NN40
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF  503403 UNOV11022025   35.20S   36.14S                   5 1 0 0 17           9503      NN40
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF  504411 UNOV11022025   29.20S   30.92S                   5 2 0 0 23           9504      NN40
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF 2003413 UNOV11022025 2:51.70S 2:50.97S                   4 8 0 0 18           9503      NN01
G08SS          Shand, Rebecca              90009041    1 4  50C   37.88 1:21.79 2:06.72 2:50.97                                                P             N96
D08SS      Shand, Rebecca              90009041    AGBR0818200718FF 2001102 UNOV11012025 2:18.50S 2:18.86S                   5 5 0 0 38           9501      NN01
G08SS          Shand, Rebecca              90009041    1 4  50C   31.49 1:07.21 1:43.52 2:18.86                                                P             N86
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF 1001529 UNOV11022025 1:04.09S 1:04.67S                   4 0     23           9501      NN01
D390023593      Alise                                                                                                                                        N20
G08SS          Sirmele, Alise              90023593    1 2  50C   31.20 1:04.67                                                                P             N55
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF  502104 UNOV11012025   33.34S   34.69S                   2 2 0 0 39           9502      NN70
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF  501112 UNOV11012025   29.10S   29.48S                   3 5 0 0 43           9501      NN60
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF 2002114 UNOV11012025 2:39.74S 2:44.21S                   1 2 0 0 43           9502      NN21
G08SS          Sirmele, Alise              90023593    1 4  50C   38.52 1:20.36 2:02.91 2:44.21                                                P             N07
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF 1002407 UNOV11022025 1:11.72S 1:14.66S                   2 0 0 0 37           9502      NN11
G08SS          Sirmele, Alise              90023593    1 2  50C   35.99 1:14.66                                                                P             N65
D08SS      Sirmele, Alise              90023593    AGBR0819201015FF 1001409 UNOV11022025 1:04.09S 1:04.67S                   8 0 0 0 55           9501      NN21
G08SS          Sirmele, Alise              90023593    1 2  50C   31.20 1:04.67                                                                P             N55
D08SS      Smith, Archie C             1311418     AGBR0221200718MM  503103 UNOV11012025   31.11S   30.68S                   5 1 0 0 15           9503      NN30
D31311418       Archie                                                                                                                                       N40
D08SS      Smith, Archie C             1311418     AGBR0221200718MM 1001109 UNOV11012025   54.10S   54.07S                   2 7 0 0 13           9501      NN30
G08SS          Smith, Archie C             1311418     1 2  50C   25.49   54.07                                                                P             N05
D08SS      Smith, Archie C             1311418     AGBR0221200718MM  504111 UNOV11012025   26.00S   27.46S                   4 7 0 0 24           9504      NN30
D08SS      Smith, Archie C             1311418     AGBR0221200718MM  502404 UNOV11022025   27.62S   27.55S            27.03S 4 6 2 9 10  9  2.   9950200    NN71
D08SS      Smith, Archie C             1311418     AGBR0221200718MM  501412 UNOV11022025   24.10S   24.47S                   5 6 0 0 11           9501      NN30
D08SS      Smith, Archie C             1311418     AGBR0221200718MM  501412SUNOV11022025   24.47S            24.03S              1 4     2       2  01      NN10
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM 1002107 UNOV11012025 1:05.25S 1:09.13S                   4 0 0 0 54           9502      NN61
D390013384                                                                                                                                                   N48
G08SS          Souter, Dexter C            90013384    1 2  50C   31.73 1:09.13                                                                P             N06
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM  504111 UNOV11012025   29.00S   30.44S                   1 0 0 0 44           9504      NN11
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM  502404 UNOV11022025   29.37S   31.11S                   5 0 0 0 46           9502      NN11
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM  501412 UNOV11022025   26.60S   27.46S                   1 2 0 0 55           9501      NN11
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM 2002414 UNOV11022025 2:20.75S 2:27.72S                   4 8 0 0 36           9502      NN71
G08SS          Souter, Dexter C            90013384    1 4  50C   33.10 1:10.93 1:49.95 2:27.72                                                P             N57
D08SS      Souter, Dexter C            90013384    AGBR0706200916MM 1001109 UNOV11012025   58.72S 1:01.92S                   5 1 0 0 59           9501      NN51
G08SS          Souter, Dexter C            90013384    1 2  50C   28.34 1:01.92                                                                P             N06
E08SS      ASSNADX  X 2006301 UNOV  011012025 1:43.05S                   1:45.50S     2 2     6                                                5N13001  X    N06
F08SS          SSNADXASmith, Archie C             1311418     GBR0221200718M  1             1311418       Archie                                             N59
G08SS          Smith, Archie C             1311418     1 4  50C   24.57                                                                        F             N54
F08SS          SSNADXACook, Harry S               90019286    GBR0905201015M  2             90019286      Harry                                              N19
G08SS          Cook, Harry S               90019286    1 4  50C   48.59                                                                        F             N14
F08SS          SSNADXAClubb, Ailsa M              90006961    GBR0109200817F  3             90006961                                                         N37
G08SS          Clubb, Ailsa M              90006961    1 4  50C 1:17.00                                                                        F             N34
F08SS          SSNADXAClubb, Heather C            90021395    GBR0324201015F  4             90021395                                                         N97
G08SS          Clubb, Heather C            90021395    1 4  50C 1:45.50                                                                        F             N15
E08SS      BSSNADX  X 2006301 UNOV  011012025 1:46.08S                   1:46.93S     2 0     8                                                7N13001  X    N16
F08SS          SSNADXBIrinkov, Atanas M           90008802    GBR0708200916M  1             90008802      Atanas                                             N80
G08SS          Irinkov, Atanas M           90008802    1 4  50C   24.82                                                                        F             N55
F08SS          SSNADXBPrusik, Adam                1291815     GBR1123200817M  2             1291815                                                          N07
G08SS          Prusik, Adam                1291815     1 4  50C   49.76                                                                        F             N04
F08SS          SSNADXBShand, Rebecca              90009041    GBR0818200718F  3             90009041                                                         N77
G08SS          Shand, Rebecca              90009041    1 4  50C 1:18.06                                                                        F             N84
F08SS          SSNADXBSirmele, Alise              90023593    GBR0819201015F  4             90023593      Alise                                              N79
G08SS          Sirmele, Alise              90023593    1 4  50C 1:46.93                                                                        F             N15
E08SS      ASSNADX  X 2007601 UNOV  011022025 1:50.55S                   1:53.72S     2 3     4                                                4N13005  X    N16
F08SS          SSNADXABrodie, Andrew I            1180653     GBR0422200520M  1             1180653                                                          N87
G08SS          Brodie, Andrew I            1180653     1 4  50C   26.85                                                                        F             N94
F08SS          SSNADXAIrinkov, Atanas M           90008802    GBR0708200916M  2             90008802      Atanas                                             N80
G08SS          Irinkov, Atanas M           90008802    1 4  50C   56.51                                                                        F             N55
F08SS          SSNADXAClubb, Ailsa M              90006961    GBR0109200817F  3             90006961                                                         N37
G08SS          Clubb, Ailsa M              90006961    1 4  50C 1:25.86                                                                        F             N44
F08SS          SSNADXAClubb, Heather C            90021395    GBR0324201015F  4             90021395                                                         N97
G08SS          Clubb, Heather C            90021395    1 4  50C 1:53.72                                                                        F             N15
E08SS      BSSNADX  X 2007601 UNOV  011022025 1:56.26S                   1:54.64S     2 1     5                                                5N13005  X    N26
F08SS          SSNADXBCook, Harry S               90019286    GBR0905201015M  1             90019286      Harry                                              N19
G08SS          Cook, Harry S               90019286    1 4  50C   26.30                                                                        F             N04
F08SS          SSNADXBSmith, Archie C             1311418     GBR0221200718M  2             1311418       Archie                                             N59
G08SS          Smith, Archie C             1311418     1 4  50C   56.19                                                                        F             N54
F08SS          SSNADXBReekie-Ayala, Iona A        90011180    GBR0327201015F  3             90011180                                                         N98
G08SS          Reekie-Ayala, Iona A        90011180    1 4  50C 1:26.72                                                                        F             N16
F08SS          SSNADXBShand, Rebecca              90009041    GBR0818200718F  4             90009041                                                         N77
G08SS          Shand, Rebecca              90009041    1 4  50C 1:54.64                                                                        F             N84
C18SS      SSNAOXAlford Otters                 Alford Otter    Alford Community Campu                      Alford              ABAB33 8TY                    N69
D08SS      Glennie, James              90015405    AGBR0601201015MM 2001522 UNOV11022025 2:14.42S 2:10.76S                   3 1     14           9501      NN90
D390015405                                                                                                                                                   N48
G08SS          Glennie, James              90015405    1 4  50C   29.16 1:02.52 1:37.03 2:10.76                                                P             N96
D08SS      Glennie, James              90015405    AGBR0601201015MM  503103 UNOV11012025   34.83S   34.37S                   1 4 0 0 54           9503      NN60
D08SS      Glennie, James              90015405    AGBR0601201015MM 1002107 UNOV11012025 1:10.65S 1:09.62S                   8 8 0 0 57           9502      NN11
G08SS          Glennie, James              90015405    1 2  50C   33.07 1:09.62                                                                P             N55
D08SS      Glennie, James              90015405    AGBR0601201015MM 2003113 UNOV11012025 2:56.09S 2:59.94S                   8 0 0 0 64           9503      NN21
G08SS          Glennie, James              90015405    1 4  50C   38.60 1:23.00 2:11.44 2:59.94                                                P             N96
D08SS      Glennie, James              90015405    AGBR0601201015MM 1003528 UNOV11022025 1:19.82S 1:16.95S                   5 8     12           9503      NN01
G08SS          Glennie, James              90015405    1 2  50C   34.87 1:16.95                                                                P             N55
D08SS      Glennie, James              90015405    AGBR0601201015MM 2002534 UNOV11022025 2:32.84S 2:28.57S                   2 3      3           9502      NN90
G08SS          Glennie, James              90015405    1 4  50C   33.86 1:11.63 1:50.74 2:28.57                                                P             N07
D08SS      Glennie, James              90015405    AGBR0601201015MM 1003408 UNOV11022025 1:19.82S 1:16.95S                   9 8 0 0 47           9503      NN21
G08SS          Glennie, James              90015405    1 2  50C   34.87 1:16.95                                                                P             N55
D08SS      Glennie, James              90015405    AGBR0601201015MM 2001402 UNOV11022025 2:14.42S 2:10.76S                   7 1 0 0 52           9501      NN01
G08SS          Glennie, James              90015405    1 4  50C   29.16 1:02.52 1:37.03 2:10.76                                                P             N96
D08SS      Glennie, James              90015405    AGBR0601201015MM 2002414 UNOV11022025 2:32.84S 2:28.57S                   6 3 0 0 39           9502      NN21
G08SS          Glennie, James              90015405    1 4  50C   33.86 1:11.63 1:50.74 2:28.57                                                P             N07
D08SS      Massie, Tom                 90008092    AGBR0120200916MM 1002107 UNOV11012025 1:07.47S 1:08.01S                   7 3 0 0 46           9502      NN10
D390008092                                                                                                                                                   N48
G08SS          Massie, Tom                 90008092    1 2  50C   32.88 1:08.01                                                                P             N54
D08SS      Massie, Tom                 90008092    AGBR0120200916MM 2005526 UNOV11022025 2:27.44S 2:24.51S                   1 6      5           9505      NN99
G08SS          Massie, Tom                 90008092    1 4  50C   30.49 1:06.47 1:50.58 2:24.51                                                P             N95
D08SS      Massie, Tom                 90008092    AGBR0120200916MM 2004105 UNOV11012025 2:27.92S 2:34.41S                   2 8 0 0 32           9504      NN10
G08SS          Massie, Tom                 90008092    1 4  50C   30.74 1:09.15 1:51.08 2:34.41                                                P             N95
D08SS      Massie, Tom                 90008092    AGBR0120200916MM  504111 UNOV11012025   26.80S   28.68S                   3 0 0 0 36           9504      NN69
D08SS      Massie, Tom                 90008092    AGBR0120200916MM  502404 UNOV11022025   30.90S   30.42S                   2 2 0 0 39           9502      NN59
D08SS      Massie, Tom                 90008092    AGBR0120200916MM 1004410 UNOV11022025 1:02.30S 1:03.59S          1:04.79S 2 9 1 9 32 20       09504      NN41
G08SS          Massie, Tom                 90008092    1 2  50C   29.43 1:03.59                                                                P             N54
G08SS          Massie, Tom                 90008092    1 2  50C   29.08 1:04.79                                                                F             N54
D08SS      Massie, Tom                 90008092    AGBR0120200916MM 2005406 UNOV11022025 2:27.44S 2:24.51S                   5 6 0 0 41           9505      NN20
G08SS          Massie, Tom                 90008092    1 4  50C   30.49 1:06.47 1:50.58 2:24.51                                                P             N95
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 2003113 UNOV11012025 2:57.31S 3:04.30S                   6 0 0 0 67           9503      NN41
D390017955                                                                                                                                                   N58
G08SS          Ruddick, Scott              90017955    1 4  50C   42.60 1:29.39 2:17.31 3:04.30                                                P             N17
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 2002534 UNOV11022025 2:38.66S 2:34.98S                   1 7      9           9502      NN31
G08SS          Ruddick, Scott              90017955    1 4  50C   36.44 1:15.48 1:55.58 2:34.98                                                P             N37
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 2004105 UNOV11012025 2:41.34S 2:42.78S                   1 8 0 0 40           9504      NN41
G08SS          Ruddick, Scott              90017955    1 4  50C   35.14 1:16.15 1:58.98 2:42.78                                                P             N27
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 4005201 UNOV11012025 5:28.14S                   5:28.00S     1 6    41       59505      NN31
G08SS          Ruddick, Scott              90017955    1 8  50C   35.10 1:16.09 1:57.72 2:39.36 3:26.43 4:14.30 4:51.38 5:28.00                F             N00
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 4001101 UNOV11012025 4:57.21S 4:57.22S                   6 6 0 0 45           9501      NN41
G08SS          Ruddick, Scott              90017955    1 8  50C   32.09 1:08.69 1:46.83 2:25.25 3:04.04 3:42.56 4:21.52 4:57.22                P             N10
D08SS      Ruddick, Scott              90017955    AGBR0523200916MM 2002414 UNOV11022025 2:38.66S 2:34.98S                   5 7 0 0 47           9502      NN51
G08SS          Ruddick, Scott              90017955    1 4  50C   36.44 1:15.48 1:55.58 2:34.98                                                P             N37
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 2001102 UNOV11012025 2:16.69S 2:14.51S                   1 7 0 0 21           9501      NN80
D390033996                                                                                                                                                   N58
G08SS          Taylor, Grace               90033996    1 4  50C   31.05 1:05.61 1:40.78 2:14.51                                                P             N76
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 2005106 UNOV11012025 2:35.60S 2:34.36S                   1 4 0 0 23           9505      NN80
G08SS          Taylor, Grace               90033996    1 4  50C   33.60 1:13.87 1:59.88 2:34.36                                                P             N86
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 1004110 UNOV11012025 1:10.90S 1:10.82S                   1 8 0 0 29           9504      NN80
G08SS          Taylor, Grace               90033996    1 2  50C   32.82 1:10.82                                                                P             N25
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 2002114 UNOV11012025 2:32.95S 2:30.05S                   2 8 0 0 14           9502      NN80
G08SS          Taylor, Grace               90033996    1 4  50C   35.07 1:13.50 1:52.59 2:30.05                                                P             N76
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 2004405 UNOV11022025 2:32.80S 2:32.01S          2:29.60S 2 2 1 9 10  9  2.   9950400    NN42
G08SS          Taylor, Grace               90033996    1 4  50C   34.01 1:12.77 1:52.24 2:32.01                                                P             N66
G08SS          Taylor, Grace               90033996    1 4  50C   34.50 1:11.43 1:51.78 2:29.60                                                F             N76
D08SS      Taylor, Grace               90033996    AGBR0515201312FF  504411 UNOV11022025   32.10S   32.09S                   2 7 0 0 42           9504      NN30
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 2003413 UNOV11022025 2:59.11S 2:54.94S                   1 7 0 0 27           9503      NN90
G08SS          Taylor, Grace               90033996    1 4  50C   40.82 1:26.97 2:12.06 2:54.94                                                P             N86
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 4005501 UNOV11022025 5:25.20S                   5:19.05S     4 8    10  1.   2950500    NN11
G08SS          Taylor, Grace               90033996    1 8  50C   34.47 1:14.77 1:55.12 2:35.43 3:22.42 4:09.50 4:45.49 5:19.05                F             N69
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 1001529 UNOV11022025 1:03.90S 1:02.13S                   4 8      5           9501      NN50
G08SS          Taylor, Grace               90033996    1 2  50C   30.07 1:02.13                                                                P             N25
D08SS      Taylor, Grace               90033996    AGBR0515201312FF 1001409 UNOV11022025 1:03.90S 1:02.13S                   8 8 0 0 30           9501      NN80
G08SS          Taylor, Grace               90033996    1 2  50C   30.07 1:02.13                                                                P             N25
D08SS      Taylor, William             90029071    AGBR0524201114MM 2002534 UNOV11022025 2:35.84S 2:36.89S                   2 2     11           9502      NN61
D390029071                                                                                                                                                   N48
G08SS          Taylor, William             90029071    1 4  50C   36.44 1:16.99 1:58.10 2:36.89                                                P             N77
D08SS      Taylor, William             90029071    AGBR0524201114MM 2004105 UNOV11012025 2:47.22S 2:44.52S                   5 5 0 0 42           9504      NN81
G08SS          Taylor, William             90029071    1 4  50C   33.60 1:12.81 1:55.71 2:44.52                                                P             N67
D08SS      Taylor, William             90029071    AGBR0524201114MM 2002414 UNOV11022025 2:35.84S 2:36.89S                   6 2 0 0 49           9502      NN91
G08SS          Taylor, William             90029071    1 4  50C   36.44 1:16.99 1:58.10 2:36.89                                                P             N77
C18SS      SSMASXArbroath St Thomas Asc        St Thomas       Arbroath Sports Centre                      Arbroath            ANDD11 3EW                    N71
D08SS      Stirling, Haydyn A          1203064     AGBR0919200619MM 2001402 UNOV11022025 2:04.10S 2:02.67S                   2 9 0 0 25           9501      NN22
D31203064                                                                                                                                                    N38
G08SS          Stirling, Haydyn A          1203064     1 4  50C   28.34   59.51 1:31.69 2:02.67                                                P             N87
D08SS      Stirling, Haydyn A          1203064     AGBR0919200619MM 2005406 UNOV11022025 2:19.14S 2:19.62S                   4 8 0 0 22           9505      NN42
G08SS          Stirling, Haydyn A          1203064     1 4  50C   29.88 1:05.94 1:46.81 2:19.62                                                P             N18
D08SS      Stirling, Haydyn A          1203064     AGBR0919200619MM 2002414 UNOV11022025 2:22.20S 2:20.36S                   2 0 0 0 21           9502      NN22
G08SS          Stirling, Haydyn A          1203064     1 4  50C   33.24 1:09.36 1:45.66 2:20.36                                                P             N08
C18          NBKXBuckie Asc                    Buckie                                                                                                        N93
D08        Coull, Isla H               1135406     A   0618200520FF  503403 UNOV11022025   37.80S   38.33S                   3 4 0 0 40           9503      NN48
D31135406                                                                                                                                                    N38
D08        Imlach, Orla T              90029226    A   0830201114FF 1003108 UNOV11012025 1:22.90S 1:23.16S                   1 7 0 0 36           9503      NN39
D390029226                                                                                                                                                   N48
G08            Imlach, Orla T              90029226    1 2  50C   39.35 1:23.16                                                                P             N54
D08        Imlach, Orla T              90029226    A   0830201114FF 2003413 UNOV11022025 2:57.42S 2:59.53S                   1 3 0 0 38           9503      NN49
G08            Imlach, Orla T              90029226    1 4  50C   38.78 1:24.30 2:11.99 2:59.53                                                P             N06
D08        Imlach, Orla T              90029226    A   0830201114FF  503403 UNOV11022025   37.45S   36.58S            36.23S 4 1 1 9 22 18       89503      NN00
D08        Murray, Emmie               90031226    A   0317201312FF 2002114 UNOV11012025 2:37.93S 2:36.93S                   1 5 0 0 28           9502      NN79
D390031226                                                                                                                                                   N48
G08            Murray, Emmie               90031226    1 4  50C   37.06 1:17.09 1:57.69 2:36.93                                                P             N36
D08        Murray, Emmie               90031226    A   0317201312FF 1002407 UNOV11022025 1:13.42S 1:13.21S                   1 8 0 0 34           9502      NN69
G08            Murray, Emmie               90031226    1 2  50C   35.87 1:13.21                                                                P             N74
D08        Murray, Emmie               90031226    A   0317201312FF 2003533 UNOV11022025 3:06.34S 3:11.78S                   1 2     14           9503      NN59
G08            Murray, Emmie               90031226    1 4  50C   44.01 1:32.07 2:21.79 3:11.78                                                P             N26
D08        Murray, Emmie               90031226    A   0317201312FF 1003108 UNOV11012025 1:28.08S 1:25.74S                   5 1 0 0 43           9503      NN79
G08            Murray, Emmie               90031226    1 2  50C   41.18 1:25.74                                                                P             N74
D08        Murray, Emmie               90031226    A   0317201312FF 4001521 UNOV11022025 5:10.50S 5:11.18S                   1 5      2           9501      NN39
G08            Murray, Emmie               90031226    1 8  50C   34.97 1:14.23 1:54.10 2:33.50 3:12.95 3:53.20 4:33.17 5:11.18                P             N09
D08        Murray, Emmie               90031226    A   0317201312FF 4001401 UNOV11022025 5:10.50S 5:11.18S                   5 5 0 0 39           9501      NN69
G08            Murray, Emmie               90031226    1 8  50C   34.97 1:14.23 1:54.10 2:33.50 3:12.95 3:53.20 4:33.17 5:11.18                P             N09
D08        Murray, Emmie               90031226    A   0317201312FF 2003413 UNOV11022025 3:06.34S 3:11.78S                   5 2 0 0 50           9503      NN79
G08            Murray, Emmie               90031226    1 4  50C   44.01 1:32.07 2:21.79 3:11.78                                                P             N26
D08        Murray, Lillie              90031774    A   1020201015FF 1003108 UNOV11012025 1:20.70S 1:20.73S          1:20.89S 4 0 1 9 24 19       99503      NN41
D390031774                                                                                                                                                   N58
G08            Murray, Lillie              90031774    1 2  50C   38.76 1:20.73                                                                P             N25
G08            Murray, Lillie              90031774    1 2  50C   38.98 1:20.89                                                                F             N25
D08        Murray, Lillie              90031774    A   1020201015FF 2003413 UNOV11022025 3:00.62S 2:57.38S                   1 0 0 0 31           9503      NN00
G08            Murray, Lillie              90031774    1 4  50C   39.88 1:23.33 2:10.89 2:57.38                                                P             N76
D08        Murray, Lillie              90031774    A   1020201015FF  503403 UNOV11022025   35.60S   36.58S            36.20S 7 0 1 0 22 16       69503      NN60
D08        Wood, Bethyn M              90020951    A   0212201114FF  504411 UNOV11022025   32.06S   32.36S                   2 2 0 0 46           9504      NN98
D390020951                                                                                                                                                   N48
D08        Wood, Bethyn M              90020951    A   0212201114FF 2004405 UNOV11022025 2:50.39S 2:43.94S                   2 9 0 0 21           9504      NN59
G08            Wood, Bethyn M              90020951    1 4  50C   35.42 1:16.83 2:00.57 2:43.94                                                P             N16
D08        Wood, Bethyn M              90020951    A   0212201114FF 4005501 UNOV11022025 5:47.80S                   5:39.22S     2 9    28       59505      NN59
G08            Wood, Bethyn M              90020951    1 8  50C   35.82 1:18.88 2:03.02 2:45.42 3:33.41 4:21.75 5:01.43 5:39.22                F             N98
D08        Wood, Bethyn M              90020951    A   0212201114FF 2005106 UNOV11012025 2:42.80S 2:39.50S                   5 6 0 0 34           9505      NN59
G08            Wood, Bethyn M              90020951    1 4  50C   34.16 1:15.14 2:03.85 2:39.50                                                P             N06
D08        Wood, Bethyn M              90020951    A   0212201114FF 1004110 UNOV11012025 1:14.00S 1:13.95S                   7 6 0 0 39           9504      NN59
G08            Wood, Bethyn M              90020951    1 2  50C   35.46 1:13.95                                                                P             N64
D08        Wood, Bethyn M              90020951    A   0212201114FF 2003533 UNOV11022025 3:02.59S 3:02.05S                   2 3      6           9503      NN29
G08            Wood, Bethyn M              90020951    1 4  50C   40.93 1:27.49 2:14.87 3:02.05                                                P             N16
D08        Wood, Bethyn M              90020951    A   0212201114FF 2003413 UNOV11022025 3:02.59S 3:02.05S                   6 3 0 0 41           9503      NN59
G08            Wood, Bethyn M              90020951    1 4  50C   40.93 1:27.49 2:14.87 3:02.05                                                P             N16
C18SS      SSWCGXCity Of Glasgow Swim Team     Co Glasgow      350 Wellshot Road                           Glasgow             GLG32 7QP                     N59
D08SS      Basketter, Jensen           90033333    AGBR0708201114MM 2004105 UNOV11012025 2:35.70S 2:25.48S                   1 7 0 0 23           9504      NN42
D390033333                                                                                                                                                   N48
G08SS          Basketter, Jensen           90033333    1 4  50C   31.76 1:07.29 1:46.34 2:25.48                                                P             N38
D08SS      Basketter, Jensen           90033333    AGBR0708201114MM 2003113 UNOV11012025 2:40.90S 2:35.89S                   1 6 0 0 19           9503      NN52
G08SS          Basketter, Jensen           90033333    1 4  50C   34.75 1:14.85 1:55.24 2:35.89                                                P             N38
D08SS      Basketter, Jensen           90033333    AGBR0708201114MM 4005201 UNOV11012025 5:14.50S                   4:57.75S     2 2    21       19505      NN42
G08SS          Basketter, Jensen           90033333    1 8  50C   32.07 1:08.05 1:47.27 2:25.04 3:05.66 3:47.51 4:23.42 4:57.75                F             N11
D08SS      Basketter, Jensen           90033333    AGBR0708201114MM 2005406 UNOV11022025 2:22.93S 2:18.89S                   1 7 0 0 20           9505      NN52
G08SS          Basketter, Jensen           90033333    1 4  50C   30.54 1:06.62 1:46.04 2:18.89                                                P             N28
D08SS      Basketter, Jensen           90033333    AGBR0708201114MM 2002414 UNOV11022025 2:27.50S 2:21.75S                   1 1 0 0 24           9502      NN42
G08SS          Basketter, Jensen           90033333    1 4  50C   33.70 1:09.74 1:45.85 2:21.75                                                P             N38
D08SS      Brown, Ciaran               90022008    AGBR1022200817MM  503103 UNOV11012025   32.20S   32.27S                   4 4 0 0 24           9503      NN20
D390022008                                                                                                                                                   N48
D08SS      Brown, Ciaran               90022008    AGBR1022200817MM  504111 UNOV11012025   28.53S   28.86S                   1 6 0 0 39           9504      NN30
D08SS      Brown, Ciaran               90022008    AGBR1022200817MM 2003113 UNOV11012025 2:36.87S 2:41.37S                   2 0 0 0 32           9503      NN80
G08SS          Brown, Ciaran               90022008    1 4  50C   35.87 1:16.73 1:58.42 2:41.37                                                P             N76
D08SS      Brown, Ciaran               90022008    AGBR1022200817MM 1003408 UNOV11022025 1:11.50S 1:12.52S                   2 8 0 0 27           9503      NN80
G08SS          Brown, Ciaran               90022008    1 2  50C   33.66 1:12.52                                                                P             N15
D08SS      Brown, Ciaran               90022008    AGBR1022200817MM  501412 UNOV11022025   26.50S   26.96S                   1 3 0 0 52           9501      NN30
D08SS      Collins, Ethan              90005640    AGBR0528200916MM  503103 UNOV11012025   30.30S   30.53S            29.88S 5 2 1 4 12 21       19503      NN71
D390005640                                                                                                                                                   N48
D08SS      Collins, Ethan              90005640    AGBR0528200916MM 1002107 UNOV11012025   57.74S   59.66S            59.42S 3 5 2 8  8  6  5.   6950200    NN22
G08SS          Collins, Ethan              90005640    1 2  50C   28.61   59.66                                                                P             N45
G08SS          Collins, Ethan              90005640    1 2  50C   29.04   59.42                                                                F             N35
D08SS      Collins, Ethan              90005640    AGBR0528200916MM  504111 UNOV11012025   25.70S   26.20S            26.25S 3 6 2 8  8  6  5.   6950400    NN02
D08SS      Collins, Ethan              90005640    AGBR0528200916MM 2005406 UNOV11022025 2:12.20S 2:12.67S          2:09.66S 3 3 1 1  8  5  6.   5950500    NN82
G08SS          Collins, Ethan              90005640    1 4  50C   27.61 1:02.32 1:39.87 2:12.67                                                P             N07
G08SS          Collins, Ethan              90005640    1 4  50C   27.97 1:01.81 1:39.10 2:09.66                                                F             N07
D08SS      Collins, Ethan              90005640    AGBR0528200916MM 1004410 UNOV11022025   56.50S   57.81S            56.68S 3 3 2 7  6  4  7.   4950400    NN22
G08SS          Collins, Ethan              90005640    1 2  50C   27.31   57.81                                                                P             N45
G08SS          Collins, Ethan              90005640    1 2  50C   27.36   56.68                                                                F             N45
D08SS      Collins, Ethan              90005640    AGBR0528200916MM  501412 UNOV11022025   24.20S   24.77S            24.36S 6 2 1 4 13 11       19501      NN71
D08SS      Collins, Ethan              90005640    AGBR0528200916MM  503103SUNOV11012025   30.53S            30.48S              1 5     1       1  03      NN50
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF 2005106 UNOV11012025 2:25.50S 2:28.62S                   2 3 0 0 12           9505      NN12
D390011253                                                                                                                                                   N48
G08SS          Crawford, Abigail           90011253    1 4  50C   31.43 1:08.66 1:52.23 2:28.62                                                P             N08
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF 1004110 UNOV11012025 1:04.70S 1:07.54S          1:05.08S 2 6 1 4 13 11       19504      NN33
G08SS          Crawford, Abigail           90011253    1 2  50C   31.65 1:07.54                                                                P             N56
G08SS          Crawford, Abigail           90011253    1 2  50C   30.64 1:05.08                                                                F             N56
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF 2002114 UNOV11012025 2:23.30S 2:24.67S          2:24.17S 4 3 1 1  6  7  4.   7950200    NN63
G08SS          Crawford, Abigail           90011253    1 4  50C   33.80 1:10.28 1:47.55 2:24.67                                                P             N08
G08SS          Crawford, Abigail           90011253    1 4  50C   33.66 1:09.85 1:47.55 2:24.17                                                F             N08
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF 2004405 UNOV11022025 2:22.40S 2:30.65S          2:29.91S 3 4 1 0  9 10  1.   0950400    NN63
G08SS          Crawford, Abigail           90011253    1 4  50C   31.83 1:09.71 1:49.72 2:30.65                                                P             N08
G08SS          Crawford, Abigail           90011253    1 4  50C   32.93 1:10.83 1:50.30 2:29.91                                                F             N97
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF  504411 UNOV11022025   29.20S   30.82S            30.37S 7 7 1 7 22 15       59504      NN72
D08SS      Crawford, Abigail           90011253    AGBR0302200916FF 4005501 UNOV11022025 5:08.11S                   5:17.79S     5 2     7  4.   7950500    NN42
G08SS          Crawford, Abigail           90011253    1 8  50C   33.50 1:12.94 1:53.55 2:33.92 3:18.87 4:04.79 4:42.20 5:17.79                F             N01
D08SS      Cumming, Alice              1279169     AGBR0411200817FF 2001102 UNOV11012025 2:09.30S 2:08.64S          2:08.52S 2 3 1 1  7  8  3.   8950100    NN52
D31279169                                                                                                                                                    N48
G08SS          Cumming, Alice              1279169     1 4  50C   28.88 1:01.21 1:35.09 2:08.64                                                P             N96
G08SS          Cumming, Alice              1279169     1 4  50C   29.95 1:02.59 1:35.78 2:08.52                                                F             N96
D08SS      Cumming, Alice              1279169     AGBR0411200817FF 1004110 UNOV11012025 1:02.60S 1:04.10S          1:04.19S 3 5 2 2  5  5  6.   5950400    NN42
G08SS          Cumming, Alice              1279169     1 2  50C   29.90 1:04.10                                                                P             N45
G08SS          Cumming, Alice              1279169     1 2  50C   29.72 1:04.19                                                                F             N45
D08SS      Cumming, Alice              1279169     AGBR0411200817FF 2004405 UNOV11022025 2:23.22S 2:24.04S          2:24.92S 2 4 1 3  3  5  6.   5950400    NN52
G08SS          Cumming, Alice              1279169     1 4  50C   31.29 1:07.84 1:45.53 2:24.04                                                P             N96
G08SS          Cumming, Alice              1279169     1 4  50C   30.71 1:06.90 1:45.54 2:24.92                                                F             N86
D08SS      Cumming, Alice              1279169     AGBR0411200817FF 1001409 UNOV11022025   59.60S 1:00.23S                   3 7 0 0 14           9501      NN80
G08SS          Cumming, Alice              1279169     1 2  50C   28.96 1:00.23                                                                P             N45
D08SS      Cumming, Alice              1279169     AGBR0411200817FF 4005501 UNOV11022025 5:02.30S                   4:59.36S     5 5     1 10.   1950500    NN31
G08SS          Cumming, Alice              1279169     1 8  50C   31.17 1:07.82 1:47.70 2:26.11 3:07.89 3:50.24 4:25.43 4:59.36                F             N89
D08SS      Cunningham, Ella            90018622    AGBR1013200916FF 2005106 UNOV11012025 2:27.00S 2:33.51S                   3 2 0 0 20           9505      NN81
D390018622                                                                                                                                                   N48
G08SS          Cunningham, Ella            90018622    1 4  50C   34.13 1:11.94 1:56.86 2:33.51                                                P             N77
D08SS      Cunningham, Ella            90018622    AGBR1013200916FF 1003108 UNOV11012025 1:16.80S 1:20.19S          1:15.51S 2 6 1 8 21 11       19503      NN13
G08SS          Cunningham, Ella            90018622    1 2  50C   38.58 1:20.19                                                                P             N36
G08SS          Cunningham, Ella            90018622    1 2  50C   34.86 1:15.51                                                                F             N26
D08SS      Cunningham, Ella            90018622    AGBR1013200916FF  501112 UNOV11012025   28.40S   28.56S            28.84S 5 2 1 0 24 20       09501      NN42
D08SS      Cunningham, Ella            90018622    AGBR1013200916FF  503403 UNOV11022025   34.50S   35.17S            34.71S 6 6 1 4 13 12       29503      NN42
D08SS      Cunningham, Ella            90018622    AGBR1013200916FF 1001409 UNOV11022025 1:00.40S 1:02.88S                   2 0 0 0 39           9501      NN81
G08SS          Cunningham, Ella            90018622    1 2  50C   30.14 1:02.88                                                                P             N26
D08SS      Dobson, Amy                 90009904    AGBR0605201015FF 1001529 UNOV11022025 1:02.80S 1:03.18S                   3 3     11           9501      NN89
D390009904                                                                                                                                                   N58
G08SS          Dobson, Amy                 90009904    1 2  50C   30.16 1:03.18                                                                P             N44
D08SS      Dobson, Amy                 90009904    AGBR0605201015FF 4001401 UNOV11022025 4:53.87S 4:53.94S                   2 7 0 0 23           9501      NN10
G08SS          Dobson, Amy                 90009904    1 8  50C   32.53 1:08.16 1:44.67 2:21.70 2:59.22 3:37.22 4:15.94 4:53.94                P             N98
D08SS      Dobson, Amy                 90009904    AGBR0605201015FF 1002407 UNOV11022025 1:10.20S 1:11.96S          1:12.46S 2 8 1 9 28 19       99502      NN41
G08SS          Dobson, Amy                 90009904    1 2  50C   35.39 1:11.96                                                                P             N54
G08SS          Dobson, Amy                 90009904    1 2  50C   34.97 1:12.46                                                                F             N44
D08SS      Dobson, Amy                 90009904    AGBR0605201015FF 1001409 UNOV11022025 1:02.80S 1:03.18S                   7 3 0 0 40           9501      NN00
G08SS          Dobson, Amy                 90009904    1 2  50C   30.16 1:03.18                                                                P             N44
D08SS      Garrity, Matthew            932797      AGBR0412200421MM  503103 UNOV11012025   28.20S   29.36S            28.84S 6 4 3 3  3  2  9.   2950300    NN82
D3932797                                                                                                                                                     N38
D08SS      Garrity, Matthew            932797      AGBR0412200421MM 2003113 UNOV11012025 2:16.08S 2:23.41S          2:20.04S 3 4 1 2  5  3  8.   3950300    NN43
G08SS          Garrity, Matthew            932797      1 4  50C   31.94 1:07.53 1:44.33 2:23.41                                                P             N97
G08SS          Garrity, Matthew            932797      1 4  50C   32.38 1:07.85 1:43.21 2:20.04                                                F             N87
D08SS      Garrity, Matthew            932797      AGBR0412200421MM 1003408 UNOV11022025 1:01.94S 1:03.73S          1:03.40S 3 4 2 5  2  2  9.   2950300    NN53
G08SS          Garrity, Matthew            932797      1 2  50C   30.10 1:03.73                                                                P             N46
G08SS          Garrity, Matthew            932797      1 2  50C   29.53 1:03.40                                                                F             N46
D08SS      Gillies, James              90004585    AGBR1111200817MM 2004105 UNOV11012025 2:18.60S 2:12.34S          2:12.34S 4 2 1 7  6  6  5.   6950400    NN72
D390004585                                                                                                                                                   N58
G08SS          Gillies, James              90004585    1 4  50C   28.12 1:01.57 1:35.74 2:12.34                                                P             N07
G08SS          Gillies, James              90004585    1 4  50C   27.47 1:00.49 1:34.75 2:12.34                                                F             N96
D08SS      Gillies, James              90004585    AGBR1111200817MM 1001109 UNOV11012025   54.80S   54.30S                   3 0 0 0 16           9501      NN70
G08SS          Gillies, James              90004585    1 2  50C   25.76   54.30                                                                P             N35
D08SS      Gillies, James              90004585    AGBR1111200817MM  504111 UNOV11012025   26.50S   27.25S                   5 0 0 0 19           9504      NN60
D08SS      Gillies, James              90004585    AGBR1111200817MM 2001402 UNOV11022025 2:02.34S 1:58.02S          1:57.20S 3 8 1 7  7  6  5.   6950100    NN72
G08SS          Gillies, James              90004585    1 4  50C   26.61   56.78 1:27.23 1:58.02                                                P             N86
G08SS          Gillies, James              90004585    1 4  50C   26.48   56.15 1:26.42 1:57.20                                                F             N76
D08SS      Gillies, James              90004585    AGBR1111200817MM 1004410 UNOV11022025   57.10S   58.19S            58.33S 4 6 2 1  7  7  4.   7950400    NN12
G08SS          Gillies, James              90004585    1 2  50C   27.14   58.19                                                                P             N45
G08SS          Gillies, James              90004585    1 2  50C   26.59   58.33                                                                F             N35
D08SS      Gillies, James              90004585    AGBR1111200817MM  501412 UNOV11022025   25.18S   25.13S                   4 9 0 0 15           9501      NN60
D08SS      Gumbrell, Cara              1290476     AGBR0424200718FF  502104 UNOV11012025   33.32S   33.04S                   2 6 0 0 29           9502      NN40
D31290476                                                                                                                                                    N48
D08SS      Gumbrell, Cara              1290476     AGBR0424200718FF  501112 UNOV11012025   28.40S   28.97S                   5 3 0 0 34           9501      NN50
D08SS      Kay, Aiden                  90029888    AGBR0813200322MM 1001109 UNOV11012025   49.60S   50.30S            50.14S 2 4 2 5  2  2  9.   2950100    NN40
D390029888                                                                                                                                                   N58
G08SS          Kay, Aiden                  90029888    1 2  50C   24.09   50.30                                                                P             N73
G08SS          Kay, Aiden                  90029888    1 2  50C   24.09   50.14                                                                F             N73
D08SS      Kay, Aiden                  90029888    AGBR0813200322MM 2001402 UNOV11022025 1:51.60S 1:53.82S          1:52.22S 4 5 1 6  4  3  8.   3950100    NN11
G08SS          Kay, Aiden                  90029888    1 4  50C   27.09   56.13 1:24.51 1:53.82                                                P             N25
G08SS          Kay, Aiden                  90029888    1 4  50C   26.20   54.17 1:22.84 1:52.22                                                F             N15
D08SS      Kay, Aiden                  90029888    AGBR0813200322MM 1004410 UNOV11022025   52.90S   55.10S            54.19S 3 4 2 5  2  2  9.   2950400    NN40
G08SS          Kay, Aiden                  90029888    1 2  50C   25.34   55.10                                                                P             N73
G08SS          Kay, Aiden                  90029888    1 2  50C   25.18   54.19                                                                F             N73
D08SS      Kay, Aiden                  90029888    AGBR0813200322MM 2004105 UNOV11012025 2:18.70S 2:09.96S          2:09.43S 2 2 1 2  5  4  7.   4950400    NN21
G08SS          Kay, Aiden                  90029888    1 4  50C   28.10   59.97 1:34.24 2:09.96                                                P             N35
G08SS          Kay, Aiden                  90029888    1 4  50C   27.54   59.79 1:33.64 2:09.43                                                F             N35
D08SS      Kringelis, Rojus            90001238    AGBR1015200718MM  503103 UNOV11012025   28.40S   29.49S            29.30S 7 5 3 6  4  5  6.   5950300    NN03
D390001238                                                                                                                                                   N48
D08SS      Kringelis, Rojus            90001238    AGBR1015200718MM 2003113 UNOV11012025 2:18.79S 2:22.60S          2:21.16S 2 4 1 3  3  4  7.   4950300    NN63
G08SS          Kringelis, Rojus            90001238    1 4  50C   31.91 1:08.32 1:45.94 2:22.60                                                P             N08
G08SS          Kringelis, Rojus            90001238    1 4  50C   31.87 1:07.87 1:44.10 2:21.16                                                F             N97
D08SS      Kringelis, Rojus            90001238    AGBR1015200718MM 2005406 UNOV11022025 2:09.60S 2:15.12S                   3 5 0 0 10           9505      NN22
G08SS          Kringelis, Rojus            90001238    1 4  50C   28.28 1:04.40 1:42.89 2:15.12                                                P             N08
D08SS      Kringelis, Rojus            90001238    AGBR1015200718MM 1003408 UNOV11022025 1:02.80S 1:04.93S          1:03.42S 2 4 2 6  4  3  8.   3950300    NN63
G08SS          Kringelis, Rojus            90001238    1 2  50C   30.79 1:04.93                                                                P             N56
G08SS          Kringelis, Rojus            90001238    1 2  50C   29.89 1:03.42                                                                F             N56
D08SS      Kringelis, Rojus            90001238    AGBR1015200718MM  501412 UNOV11022025   25.10S      NSS                   6 9 0 0  0           9501      NN51
D08SS      Letham, Daniel              90029870    AGBR0210201114MM 1004530 UNOV11022025 1:08.91S 1:09.47S                   1 1     13           9504      NN90
D390029870                                                                                                                                                   N58
G08SS          Letham, Daniel              90029870    1 2  50C   31.08 1:09.47                                                                P             N55
D08SS      Letham, Daniel              90029870    AGBR0210201114MM 4001101 UNOV11012025 4:25.50S 4:31.01S                   2 7 0 0 27           9501      NN01
G08SS          Letham, Daniel              90029870    1 8  50C   29.72 1:02.24 1:35.91 2:10.81 2:45.69 3:20.88 3:56.06 4:31.01                P             N89
D08SS      Letham, Daniel              90029870    AGBR0210201114MM 1002107 UNOV11012025 1:06.04S 1:04.52S                   1 6 0 0 25           9502      NN01
G08SS          Letham, Daniel              90029870    1 2  50C   31.43 1:04.52                                                                P             N45
D08SS      Letham, Daniel              90029870    AGBR0210201114MM  502404 UNOV11022025   30.60S   30.10S                   2 5 0 0 35           9502      NN40
D08SS      Letham, Daniel              90029870    AGBR0210201114MM 8001502 UNOV11022025 9:13.70S                   9:10.48S     2 7    13       59501      NN11
G08SS          Letham, Daniel              90029870    116  50C   30.27 1:03.13 1:37.09 2:11.03 2:45.53 3:20.64 3:55.46 4:30.36 5:05.52 5:40.74F             N21
G08SS          Letham, Daniel              90029870    216  50C 6:16.18 6:51.42 7:26.75 8:01.96 8:36.87 9:10.48                                F             N98
D08SS      Letham, Daniel              90029870    AGBR0210201114MM 1004410 UNOV11022025 1:08.91S 1:09.47S                   5 1 0 0 50           9504      NN11
G08SS          Letham, Daniel              90029870    1 2  50C   31.08 1:09.47                                                                P             N55
D08SS      Lyden, Brody                90020158    AGBR0829201015MM 1001109 UNOV11012025   58.20S   58.46S                   7 7 0 0 51           9501      NN10
D390020158                                                                                                                                                   N48
G08SS          Lyden, Brody                90020158    1 2  50C   28.84   58.46                                                                P             N74
D08SS      Lyden, Brody                90020158    AGBR0829201015MM 2001522 UNOV11022025 2:08.00S 2:05.94S                   2 5      4           9501      NN20
G08SS          Lyden, Brody                90020158    1 4  50C   29.11 1:00.40 1:32.74 2:05.94                                                P             N36
D08SS      Lyden, Brody                90020158    AGBR0829201015MM 2004105 UNOV11012025 2:28.50S 2:27.88S                   4 0 0 0 25           9504      NN60
G08SS          Lyden, Brody                90020158    1 4  50C   31.59 1:07.64 1:46.08 2:27.88                                                P             N46
D08SS      Lyden, Brody                90020158    AGBR0829201015MM  504111 UNOV11012025   28.30S   28.90S                   1 3 0 0 40           9504      NN00
D08SS      Lyden, Brody                90020158    AGBR0829201015MM 1004410 UNOV11022025 1:03.40S 1:04.39S                   1 2 0 0 37           9504      NN50
G08SS          Lyden, Brody                90020158    1 2  50C   29.60 1:04.39                                                                P             N94
D08SS      Lyden, Brody                90020158    AGBR0829201015MM  501412 UNOV11022025   26.10S   26.69S                   2 4 0 0 49           9501      NN00
D08SS      Lyden, Brody                90020158    AGBR0829201015MM 2001402 UNOV11022025 2:08.00S 2:05.94S                   6 5 0 0 36           9501      NN50
G08SS          Lyden, Brody                90020158    1 4  50C   29.11 1:00.40 1:32.74 2:05.94                                                P             N36
D08SS      Macleod, Amy                90002255    AGBR0925200619FF 2005106 UNOV11012025 2:25.19S 2:27.34S          2:25.82S 3 3 1 0  9  7  4.   7950500    NN91
D390002255                                                                                                                                                   N48
G08SS          Macleod, Amy                90002255    1 4  50C   31.21 1:10.33 1:51.21 2:27.34                                                P             N06
G08SS          Macleod, Amy                90002255    1 4  50C   31.82 1:10.46 1:51.24 2:25.82                                                F             N06
D08SS      Macleod, Amy                90002255    AGBR0925200619FF 1003108 UNOV11012025 1:12.10S 1:12.88S          1:12.22S 2 4 2 5  2  2  9.   2950300    NN71
G08SS          Macleod, Amy                90002255    1 2  50C   34.22 1:12.88                                                                P             N74
G08SS          Macleod, Amy                90002255    1 2  50C   34.05 1:12.22                                                                F             N64
D08SS      Macleod, Amy                90002255    AGBR0925200619FF  503403 UNOV11022025   32.80S   33.46S            33.24S 6 4 2 5  2  2  9.   2950300    NN01
D08SS      Macleod, Amy                90002255    AGBR0925200619FF 2003413 UNOV11022025 2:40.90S 2:39.44S          2:38.05S 3 5 1 5  2  2  9.   2950300    NN81
G08SS          Macleod, Amy                90002255    1 4  50C   35.79 1:16.25 1:57.77 2:39.44                                                P             N26
G08SS          Macleod, Amy                90002255    1 4  50C   34.83 1:14.86 1:56.49 2:38.05                                                F             N26
D08SS      Mainwaring, Melissa         1260385     AGBR0324200619FF  502104 UNOV11012025   27.97S   28.39S            28.09S 5 4 2 4  1  1 10.   1950200    NN93
D31260385       Millie                                                                                                                                       N50
D08SS      Mainwaring, Melissa         1260385     AGBR0324200619FF  501112 UNOV11012025   26.70S   26.73S            26.90S 6 3 2 7  6  7  4.   7950100    NN83
D08SS      Mainwaring, Melissa         1260385     AGBR0324200619FF 1002407 UNOV11022025 1:01.02S 1:01.94S          1:00.60S 3 4 2 4  1  1 10.   1950200    NN44
G08SS          Mainwaring, Melissa         1260385     1 2  50C   29.85 1:01.94                                                                P             N57
G08SS          Mainwaring, Melissa         1260385     1 2  50C   29.38 1:00.60                                                                F             N47
D08SS      Mainwaring, Melissa         1260385     AGBR0324200619FF 1001409 UNOV11022025   57.76S   59.40S            59.59S 2 5 2 8  9  7  4.   7950100    NN14
G08SS          Mainwaring, Melissa         1260385     1 2  50C   28.66   59.40                                                                P             N37
G08SS          Mainwaring, Melissa         1260385     1 2  50C   28.37   59.59                                                                F             N37
D08SS      Mainwaring, Melissa         1260385     AGBR0324200619FF  504411 UNOV11022025   28.38S   29.50S            29.19S 7 3 2 9 10  8  3.   8950400    NN04
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF 2002114 UNOV11012025 2:43.18S 2:40.50S                   5 1 0 0 39           9502      NN11
D390024035                                                                                                                                                   N48
G08SS          McGovern, Lucy              90024035    1 4  50C   37.82 1:18.86 2:00.49 2:40.50                                                P             N07
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF 2005106 UNOV11012025 2:41.39S 2:39.49S                   5 5 0 0 33           9505      NN21
G08SS          McGovern, Lucy              90024035    1 4  50C   33.82 1:14.93 2:03.32 2:39.49                                                P             N07
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF 1004110 UNOV11012025 1:09.40S 1:12.50S                   1 3 0 0 34           9504      NN01
G08SS          McGovern, Lucy              90024035    1 2  50C   33.24 1:12.50                                                                P             N55
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF 2004405 UNOV11022025 2:39.60S 2:47.76S                   3 1 0 0 24           9504      NN21
G08SS          McGovern, Lucy              90024035    1 4  50C   36.64 1:18.85 2:03.47 2:47.76                                                P             N17
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF  504411 UNOV11022025   30.60S   32.66S                   4 0 0 0 52           9504      NN50
D08SS      McGovern, Lucy              90024035    AGBR0429201015FF 4005501 UNOV11022025 5:50.90S                   5:37.01S     1 4    26       19505      NN11
G08SS          McGovern, Lucy              90024035    1 8  50C   35.26 1:16.71 2:00.01 2:42.77 3:31.29 4:20.25 4:59.89 5:37.01                F             N99
D08SS      McKinnon, Ruairi            895627      AGBR0915200421MM 1001109 UNOV11012025   48.74S   49.64S            50.11S 4 4 2 4  1  1 10.   1950100    NN72
D3895627                                                                                                                                                     N38
G08SS          McKinnon, Ruairi            895627      1 2  50C   23.64   49.64                                                                P             N06
G08SS          McKinnon, Ruairi            895627      1 2  50C   23.72   50.11                                                                F             N85
D08SS      McKinnon, Ruairi            895627      AGBR0915200421MM  504111 UNOV11012025   24.20S   25.47S            26.29S 3 4 2 2  5  7  4.   7950400    NN52
D08SS      McKinnon, Ruairi            895627      AGBR0915200421MM 2001402 UNOV11022025 1:48.21S 1:52.01S          1:50.20S 4 4 1 5  2  2  9.   2950100    NN23
G08SS          McKinnon, Ruairi            895627      1 4  50C   26.87   55.88 1:23.88 1:52.01                                                P             N57
G08SS          McKinnon, Ruairi            895627      1 4  50C   25.75   53.29 1:21.05 1:50.20                                                F             N37
D08SS      McKinnon, Ruairi            895627      AGBR0915200421MM  501412 UNOV11022025   22.10S   23.16S            22.74S 6 4 2 4  1  1 10.   1950100    NN52
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 1001529 UNOV11022025 1:03.90S 1:02.50S                   2 1      9           9501      NN80
D390018625                                                                                                                                                   N58
G08SS          McMillan, Abbie             90018625    1 2  50C   30.47 1:02.50                                                                P             N55
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 2005106 UNOV11012025 2:33.36S      NSS                   4 0 0 0  0           9505      NN80
G08SS          McMillan, Abbie             90018625    1 4  50C                                                                                P             N44
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 1004110 UNOV11012025 1:09.10S 1:09.73S          1:09.78S 1 5 1 1 23 20       09504      NN42
G08SS          McMillan, Abbie             90018625    1 2  50C   32.77 1:09.73                                                                P             N65
G08SS          McMillan, Abbie             90018625    1 2  50C   33.20 1:09.78                                                                F             N55
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 2002114 UNOV11012025 2:30.21S 2:30.65S                   3 7 0 0 17           9502      NN11
G08SS          McMillan, Abbie             90018625    1 4  50C   35.81 1:14.27 1:53.18 2:30.65                                                P             N07
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 2004405 UNOV11022025 2:37.50S 2:36.93S                   2 7 0 0 15           9504      NN21
G08SS          McMillan, Abbie             90018625    1 4  50C   34.51 1:15.39 1:55.22 2:36.93                                                P             N17
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF  504411 UNOV11022025   31.50S   31.91S                   2 4 0 0 39           9504      NN60
D08SS      McMillan, Abbie             90018625    AGBR0311200916FF 1001409 UNOV11022025 1:03.90S 1:02.50S                   6 1 0 0 36           9501      NN11
G08SS          McMillan, Abbie             90018625    1 2  50C   30.47 1:02.50                                                                P             N55
D08SS      Miles, Robson               1119332     AGBR0411200520MM  503103 UNOV11012025   28.90S   29.17S            28.96S 5 5 3 5  2  3  8.   3950300    NN61
D31119332                                                                                                                                                    N38
D08SS      Miles, Robson               1119332     AGBR0411200520MM 2003113 UNOV11012025 2:24.08S 2:27.23S          2:25.94S 4 6 1 0 11  7  4.   7950300    NN42
G08SS          Miles, Robson               1119332     1 4  50C   32.50 1:09.50 1:48.32 2:27.23                                                P             N66
G08SS          Miles, Robson               1119332     1 4  50C   32.78 1:09.69 1:47.10 2:25.94                                                F             N66
D08SS      Miles, Robson               1119332     AGBR0411200520MM 1003408 UNOV11022025 1:03.52S 1:04.19S          1:04.22S 4 5 2 3  3  4  7.   4950300    NN22
G08SS          Miles, Robson               1119332     1 2  50C   29.40 1:04.19                                                                P             N25
G08SS          Miles, Robson               1119332     1 2  50C   29.91 1:04.22                                                                F             N15
D08SS      Milne, Lula                 90028232    AGBR0128201114FF 1003108 UNOV11012025 1:17.27S 1:18.99S          1:16.65S 2 2 1 2 15 14       49503      NN31
D390028232                                                                                                                                                   N48
G08SS          Milne, Lula                 90028232    1 2  50C   37.19 1:18.99                                                                P             N54
G08SS          Milne, Lula                 90028232    1 2  50C   36.28 1:16.65                                                                F             N44
D08SS      Milne, Lula                 90028232    AGBR0128201114FF 1004110 UNOV11012025 1:08.40S 1:09.86S          1:07.91S 4 0 1 8 24 14       49504      NN31
G08SS          Milne, Lula                 90028232    1 2  50C   33.24 1:09.86                                                                P             N44
G08SS          Milne, Lula                 90028232    1 2  50C   31.67 1:07.91                                                                F             N44
D08SS      Milne, Lula                 90028232    AGBR0128201114FF 2004405 UNOV11022025 2:31.60S 2:30.29S          2:29.31S 4 2 1 8  8  8  3.   8950400    NN51
G08SS          Milne, Lula                 90028232    1 4  50C   32.75 1:10.24 1:49.85 2:30.29                                                P             N95
G08SS          Milne, Lula                 90028232    1 4  50C   32.60 1:10.04 1:49.41 2:29.31                                                F             N75
D08SS      Milne, Lula                 90028232    AGBR0128201114FF 2003413 UNOV11022025 2:50.20S 2:48.95S                   2 7 0 0 13           9503      NN00
G08SS          Milne, Lula                 90028232    1 4  50C   38.29 1:21.36 2:04.86 2:48.95                                                P             N95
D08SS      Milne, Lula                 90028232    AGBR0128201114FF 4005501 UNOV11022025 5:26.73S                   5:19.18S     4 0    11       39505      NN99
G08SS          Milne, Lula                 90028232    1 8  50C   33.25 1:11.09 1:51.65 2:32.55 3:18.19 4:04.24 4:41.93 5:19.18                F             N78
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 2001522 UNOV11022025 2:06.60S 2:03.86S                   3 4      2           9501      NN70
D390014309                                                                                                                                                   N48
G08SS          Mossman, Kyle               90014309    1 4  50C   27.42   59.15 1:31.94 2:03.86                                                P             N66
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM  503103 UNOV11012025   32.40S   32.49S            32.52S 4 3 1 6 25 25       59503      NN51
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 1002107 UNOV11012025 1:01.72S 1:02.27S          1:02.00S 3 6 1 5 13 12       29502      NN22
G08SS          Mossman, Kyle               90014309    1 2  50C   29.37 1:02.27                                                                P             N35
G08SS          Mossman, Kyle               90014309    1 2  50C   29.95 1:02.00                                                                F             N25
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM  504111 UNOV11012025   27.20S   28.15S                   2 5 0 0 33           9504      NN40
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 4005201 UNOV11012025 4:55.49S                   5:00.26S     4 7    24       79505      NN01
G08SS          Mossman, Kyle               90014309    1 8  50C   31.18 1:08.32 1:46.99 2:25.31 3:08.26 3:53.34 4:27.87 5:00.26                F             N79
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 2005406 UNOV11022025 2:18.10S 2:20.59S                   3 7 0 0 25           9505      NN01
G08SS          Mossman, Kyle               90014309    1 4  50C   29.23 1:06.59 1:48.81 2:20.59                                                P             N86
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 1004410 UNOV11022025 1:02.40S 1:02.61S          1:02.31S 1 4 1 2 28 16       69504      NN22
G08SS          Mossman, Kyle               90014309    1 2  50C   29.08 1:02.61                                                                P             N35
G08SS          Mossman, Kyle               90014309    1 2  50C   28.56 1:02.31                                                                F             N25
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 2002414 UNOV11022025 2:15.60S 2:14.62S          2:16.47S 2 6 1 9 10  9  2.   9950200    NN62
G08SS          Mossman, Kyle               90014309    1 4  50C   31.19 1:06.06 1:41.07 2:14.62                                                P             N76
G08SS          Mossman, Kyle               90014309    1 4  50C   30.76 1:05.36 1:41.30 2:16.47                                                F             N76
D08SS      Mossman, Kyle               90014309    AGBR0417200916MM 2001402 UNOV11022025 2:06.60S 2:03.86S                   7 4 0 0 29           9501      NN01
G08SS          Mossman, Kyle               90014309    1 4  50C   27.42   59.15 1:31.94 2:03.86                                                P             N66
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 4001101 UNOV11012025 4:25.30S 4:28.18S                   2 2 0 0 23           9501      NN50
D390010429                                                                                                                                                   N48
G08SS          Murphy, Cole                90010429    1 8  50C   28.92 1:01.59 1:34.61 2:08.72 2:43.59 3:18.55 3:53.76 4:28.18                P             N49
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 2004105 UNOV11012025 2:18.94S 2:22.16S                   4 7 0 0 16           9504      NN60
G08SS          Murphy, Cole                90010429    1 4  50C   29.82 1:06.17 1:43.25 2:22.16                                                P             N46
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 1002107 UNOV11012025 1:05.60S 1:05.73S                   3 9 0 0 34           9502      NN60
G08SS          Murphy, Cole                90010429    1 2  50C   31.13 1:05.73                                                                P             N94
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 4005201 UNOV11012025 5:06.10S                   5:01.53S     3 8    25       69505      NN50
G08SS          Murphy, Cole                90010429    1 8  50C   31.16 1:06.75 1:44.00 2:21.79 3:06.31 3:52.06 4:27.20 5:01.53                F             N19
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 2001402 UNOV11022025 2:04.70S 2:03.83S                   1 3 0 0 28           9501      NN50
G08SS          Murphy, Cole                90010429    1 4  50C   28.62 1:00.15 1:32.34 2:03.83                                                P             N36
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 2005406 UNOV11022025 2:21.70S 2:19.69S                   1 4 0 0 23           9505      NN60
G08SS          Murphy, Cole                90010429    1 4  50C   30.02 1:04.76 1:47.72 2:19.69                                                P             N46
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 1004410 UNOV11022025 1:03.80S 1:03.68S                   1 7 0 0 33  0       09504      NN70
G08SS          Murphy, Cole                90010429    1 2  50C   30.37 1:03.68                                                                P             N94
D08SS      Murphy, Cole                90010429    AGBR0305200916MM 8001502 UNOV11022025 9:28.39S                   9:13.94S     1 4    14       19501      NN60
G08SS          Murphy, Cole                90010429    116  50C   30.82 1:05.21 1:40.05 2:15.38 2:50.30 3:25.48 4:00.57 4:35.53 5:10.91 5:46.92F             N70
G08SS          Murphy, Cole                90010429    216  50C 6:23.00 6:57.97 7:33.17 8:08.40 8:42.89 9:13.94                                F             N38
D08SS      Ren, Gina                   90006316    AGBR0722200916FF 2001102 UNOV11012025 2:14.20S 2:20.57S                   4 0 0 0 41           9501      NN09
D390006316                                                                                                                                                   N48
G08SS          Ren, Gina                   90006316    1 4  50C   31.36 1:06.47 1:43.09 2:20.57                                                P             N05
D08SS      Ren, Gina                   90006316    AGBR0722200916FF  501112 UNOV11012025   27.40S   28.37S            28.25S 6 7 1 7 19 15       59501      NN89
D08SS      Ren, Gina                   90006316    AGBR0722200916FF 1001409 UNOV11022025 1:00.80S 1:02.40S                   2 9 0 0 35           9501      NN19
G08SS          Ren, Gina                   90006316    1 2  50C   29.91 1:02.40                                                                P             N53
D08SS      Ren, Gina                   90006316    AGBR0722200916FF  504411 UNOV11022025   29.80S   31.21S            30.92S 6 0 1 0 27 18       89504      NN79
D08SS      Ren, Heidi                  1287013     AGBR0705200718FF  502104 UNOV11012025   28.48S   29.04S            28.81S 4 4 2 3  3  2  9.   2950200    NN20
D31287013                                                                                                                                                    N38
D08SS      Ren, Heidi                  1287013     AGBR0705200718FF 2002114 UNOV11012025 2:14.06S 2:21.85S          2:21.37S 4 4 1 3  3  4  7.   4950200    NN90
G08SS          Ren, Heidi                  1287013     1 4  50C   31.52 1:07.01 1:45.26 2:21.85                                                P             N25
G08SS          Ren, Heidi                  1287013     1 4  50C   33.58 1:09.33 1:45.62 2:21.37                                                F             N25
D08SS      Ren, Heidi                  1287013     AGBR0705200718FF 1002407 UNOV11022025 1:00.92S 1:02.67S          1:01.75S 4 4 2 5  2  2  9.   2950200    NN90
G08SS          Ren, Heidi                  1287013     1 2  50C   29.88 1:02.67                                                                P             N93
G08SS          Ren, Heidi                  1287013     1 2  50C   29.81 1:01.75                                                                F             N83
D08SS      Ren, Heidi                  1287013     AGBR0705200718FF  504411 UNOV11022025   28.60S   29.30S            28.59S 7 6 2 8  8  5  5.   5950450    NN30
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 2001102 UNOV11012025 2:10.70S 2:13.75S                   4 7 0 0 16           9501      NN39
D390014614                                                                                                                                                   N48
G08SS          Ross, Ava                   90014614    1 4  50C   29.64 1:02.79 1:38.14 2:13.75                                                P             N25
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 1003108 UNOV11012025 1:16.36S 1:17.03S          1:15.84S 4 6 2 1  7  8  3.   8950300    NN90
G08SS          Ross, Ava                   90014614    1 2  50C   36.27 1:17.03                                                                P             N73
G08SS          Ross, Ava                   90014614    1 2  50C   35.86 1:15.84                                                                F             N73
D08SS      Ross, Ava                   90014614    AGBR0927200916FF  501112 UNOV11012025   28.70S   28.67S                   4 2 0 0 26           9501      NN88
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 8001202 UNOV11012025 9:36.00S                   9:22.64S     3 7     3  8.   3950100    NN69
G08SS          Ross, Ava                   90014614    116  50C   31.06 1:05.91 1:40.85 2:16.19 2:51.73 3:27.49 4:03.32 4:38.78 5:14.57 5:50.42F             N69
G08SS          Ross, Ava                   90014614    216  50C 6:26.18 7:02.02 7:37.88 8:13.33 8:48.92 9:22.64                                F             N17
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 4001401 UNOV11022025 4:30.84S 4:33.08S          4:37.47S 4 5 1 7  6  7  4.   7950100    NN90
G08SS          Ross, Ava                   90014614    1 8  50C   30.22 1:04.17 1:38.08 2:12.20 2:46.68 3:22.53 3:58.46 4:33.08                P             N08
G08SS          Ross, Ava                   90014614    1 8  50C   30.52 1:04.02 1:38.76 2:14.12 2:49.74 3:25.62 4:02.19 4:37.47                F             N08
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 1001409 UNOV11022025   59.96S 1:01.37S          1:02.48S 4 8 1 1 24 20       09501      NN40
G08SS          Ross, Ava                   90014614    1 2  50C   29.37 1:01.37                                                                P             N73
G08SS          Ross, Ava                   90014614    1 2  50C   29.82 1:02.48                                                                F             N73
D08SS      Ross, Ava                   90014614    AGBR0927200916FF 2003413 UNOV11022025 2:42.44S 2:42.00S          2:43.29S 4 6 1 6  4  8  3.   8950300    NN80
G08SS          Ross, Ava                   90014614    1 4  50C   37.63 1:17.95 2:00.09 2:42.00                                                P             N15
G08SS          Ross, Ava                   90014614    1 4  50C   37.35 1:19.18 2:01.38 2:43.29                                                F             N15
D08SS      Ross, Gregor                90002955    AGBR0424200817MM  503103 UNOV11012025   30.20S      DQS                   6 2 0 0  0           9503      NN99
D390002955                                                                                                                                                   N48
D08SS      Ross, Gregor                90002955    AGBR0424200817MM 2003113 UNOV11012025 2:22.29S 2:26.47S          2:23.33S 4 3 1 8  8  5  6.   5950300    NN22
G08SS          Ross, Gregor                90002955    1 4  50C   32.35 1:09.37 1:47.36 2:26.47                                                P             N56
G08SS          Ross, Gregor                90002955    1 4  50C   31.98 1:08.69 1:45.71 2:23.33                                                F             N46
D08SS      Ross, Gregor                90002955    AGBR0424200817MM 4005201 UNOV11012025 4:31.06S                   4:38.34S     5 3     3  8.   3950500    NN90
G08SS          Ross, Gregor                90002955    1 8  50C   28.40 1:01.74 1:38.61 2:14.89 2:52.90 3:32.03 4:05.74 4:38.34                F             N39
D08SS      Ross, Gregor                90002955    AGBR0424200817MM 2005406 UNOV11022025 2:07.48S 2:09.83S          2:10.91S 3 4 1 2  5  7  4.   7950500    NN22
G08SS          Ross, Gregor                90002955    1 4  50C   27.67 1:01.33 1:38.27 2:09.83                                                P             N56
G08SS          Ross, Gregor                90002955    1 4  50C   27.90 1:01.33 1:38.29 2:10.91                                                F             N46
D08SS      Ross, Gregor                90002955    AGBR0424200817MM 1003408 UNOV11022025 1:06.40S 1:06.93S          1:07.68S 2 3 2 1  7 10  1.   0950300    NN22
G08SS          Ross, Gregor                90002955    1 2  50C   31.50 1:06.93                                                                P             N05
G08SS          Ross, Gregor                90002955    1 2  50C   31.43 1:07.68                                                                F             N94
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 1001109 UNOV11012025   58.80S   58.19S                   7 8 0 0 49           9501      NN60
D390029566      Sam                                                                                                                                          N59
G08SS          Rough, Samuel               90029566    1 2  50C   28.85   58.19                                                                P             N25
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 4001101 UNOV11012025 4:22.00S 4:18.17S          4:16.04S 3 9 1 9 10  8  3.   8950100    NN52
G08SS          Rough, Samuel               90029566    1 8  50C   29.22 1:00.89 1:32.66 2:04.95 2:37.57 3:10.84 3:44.89 4:18.17                P             N89
G08SS          Rough, Samuel               90029566    1 8  50C   28.64 1:00.25 1:32.44 2:04.28 2:37.08 3:10.40 3:43.58 4:16.04                F             N69
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 2004105 UNOV11012025 2:22.50S 2:20.33S                   3 1 0 0 13           9504      NN80
G08SS          Rough, Samuel               90029566    1 4  50C   31.40 1:07.09 1:43.48 2:20.33                                                P             N76
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 4005201 UNOV11012025 5:03.70S                   4:53.37S     3 7    16       29505      NN90
G08SS          Rough, Samuel               90029566    1 8  50C   30.86 1:05.77 1:43.46 2:19.71 3:04.32 3:48.71 4:21.99 4:53.37                F             N89
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 2001402 UNOV11022025 2:02.60S 2:02.78S                   2 8 0 0 26           9501      NN90
G08SS          Rough, Samuel               90029566    1 4  50C   28.51   59.58 1:31.84 2:02.78                                                P             N66
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 1004410 UNOV11022025 1:03.90S 1:03.24S          1:03.23S 1 1 1 1 30 18       89504      NN12
G08SS          Rough, Samuel               90029566    1 2  50C   29.83 1:03.24                                                                P             N35
G08SS          Rough, Samuel               90029566    1 2  50C   30.40 1:03.23                                                                F             N25
D08SS      Rough, Samuel               90029566    AGBR0220201114MM 2002414 UNOV11022025 2:27.40S 2:19.38S                   1 7 0 0 18           9502      NN01
G08SS          Rough, Samuel               90029566    1 4  50C   33.11 1:09.29 1:44.66 2:19.38                                                P             N86
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 2001102 UNOV11012025 2:12.54S 2:18.41S                   3 1 0 0 35           9501      NN99
D390025476                                                                                                                                                   N58
G08SS          Rowell, Ami                 90025476    1 4  50C   31.43 1:06.53 1:42.69 2:18.41                                                P             N95
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 2005106 UNOV11012025 2:28.97S 2:35.06S                   2 2 0 0 25           9505      NN10
G08SS          Rowell, Ami                 90025476    1 4  50C   31.76 1:10.09 1:58.69 2:35.06                                                P             N06
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 1004110 UNOV11012025 1:06.56S 1:08.43S          1:06.69S 2 7 1 5 15 12       29504      NN31
G08SS          Rowell, Ami                 90025476    1 2  50C   31.97 1:08.43                                                                P             N54
G08SS          Rowell, Ami                 90025476    1 2  50C   30.82 1:06.69                                                                F             N44
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 2002114 UNOV11012025 2:28.52S 2:31.38S                   4 2 0 0 18           9502      NN00
G08SS          Rowell, Ami                 90025476    1 4  50C   35.43 1:13.29 1:52.54 2:31.38                                                P             N95
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 2004405 UNOV11022025 2:25.63S 2:28.86S          2:26.97S 4 3 1 1  7  7  4.   7950400    NN61
G08SS          Rowell, Ami                 90025476    1 4  50C   32.86 1:10.52 1:49.54 2:28.86                                                P             N06
G08SS          Rowell, Ami                 90025476    1 4  50C   32.38 1:10.02 1:48.85 2:26.97                                                F             N95
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF  504411 UNOV11022025   29.60S   30.40S            29.73S 7 8 1 6 18 12       29504      NN60
D08SS      Rowell, Ami                 90025476    AGBR0301201015FF 4005501 UNOV11022025 5:14.39S                   5:21.35S     5 8    12       99505      NN00
G08SS          Rowell, Ami                 90025476    1 8  50C   32.70 1:11.76 1:52.74 2:32.88 3:21.05 4:09.46 4:46.02 5:21.35                F             N88
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 2004105 UNOV11012025 2:06.40S 2:05.93S          2:04.68S 2 4 1 5  2  2  9.   2950400    NN63
D390039531                                                                                                                                                   N48
G08SS          Sisnett, Nikolai            90039531    1 4  50C   27.32   59.89 1:33.98 2:05.93                                                P             N97
G08SS          Sisnett, Nikolai            90039531    1 4  50C   28.00   59.53 1:32.65 2:04.68                                                F             N77
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 1001109 UNOV11012025   52.20S   51.29S            51.38S 4 6 2 6  4  6  5.   6950100    NN03
G08SS          Sisnett, Nikolai            90039531    1 2  50C   24.71   51.29                                                                P             N36
G08SS          Sisnett, Nikolai            90039531    1 2  50C   24.82   51.38                                                                F             N26
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 4005201 UNOV11012025 4:38.30S                   4:42.12S     5 2     8  3.   7950500    NN32
G08SS          Sisnett, Nikolai            90039531    1 8  50C   29.87 1:04.57 1:42.68 2:19.90 2:59.50 3:40.71 4:12.19 4:42.12                F             N90
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 2001402 UNOV11022025 1:54.74S 1:55.35S          1:53.36S 2 5 1 2  6  4  7.   4950100    NN63
G08SS          Sisnett, Nikolai            90039531    1 4  50C   28.07   55.35 1:24.47 1:55.35                                                P             N87
G08SS          Sisnett, Nikolai            90039531    1 4  50C   25.93   53.86 1:23.47 1:53.36                                                F             N77
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 2005406 UNOV11022025 2:09.80S 2:09.15S          2:07.61S 2 5 1 3  3  2  9.   2950500    NN73
G08SS          Sisnett, Nikolai            90039531    1 4  50C   26.35   57.11 1:37.84 2:09.15                                                P             N87
G08SS          Sisnett, Nikolai            90039531    1 4  50C   26.89   58.00 1:37.43 2:07.61                                                F             N77
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 1004410 UNOV11022025   55.00S   55.31S            54.85S 4 5 2 3  3  3  8.   3950400    NN92
G08SS          Sisnett, Nikolai            90039531    1 2  50C   25.50   55.31                                                                P             N36
G08SS          Sisnett, Nikolai            90039531    1 2  50C   25.80   54.85                                                                F             N36
D08SS      Sisnett, Nikolai            90039531    AGBR0326201015MM 2002414 UNOV11022025 2:02.93S 2:02.76S          2:00.93S 3 4 1 5  2  2  9.   2950200    NN63
G08SS          Sisnett, Nikolai            90039531    1 4  50C   29.37   58.72 1:29.92 2:02.76                                                P             N87
G08SS          Sisnett, Nikolai            90039531    1 4  50C   28.40   58.34 1:29.23 2:00.93                                                F             N77
D08SS      Smith, Kayla                90037468    AGBR0313201015FF 2005106 UNOV11012025 2:32.70S 2:29.38S                   3 8 0 0 14           9505      NN50
D390037468                                                                                                                                                   N58
G08SS          Smith, Kayla                90037468    1 4  50C   32.13 1:11.92 1:54.12 2:29.38                                                P             N36
D08SS      Smith, Kayla                90037468    AGBR0313201015FF 1003108 UNOV11012025 1:15.10S 1:14.53S          1:15.23S 2 5 2 2  5  6  5.   6950300    NN81
G08SS          Smith, Kayla                90037468    1 2  50C   35.51 1:14.53                                                                P             N94
G08SS          Smith, Kayla                90037468    1 2  50C   35.45 1:15.23                                                                F             N84
D08SS      Smith, Kayla                90037468    AGBR0313201015FF  503403 UNOV11022025   33.80S   35.00S            34.96S 7 3 2 9 10  9  2.   9950300    NN31
D08SS      Smith, Kayla                90037468    AGBR0313201015FF 2003413 UNOV11022025 2:40.60S 2:42.19S          2:41.97S 4 5 1 7  6  5  6.   5950300    NN02
G08SS          Smith, Kayla                90037468    1 4  50C   36.42 1:17.04 1:58.87 2:42.19                                                P             N46
G08SS          Smith, Kayla                90037468    1 4  50C   36.46 1:17.87 1:58.86 2:41.97                                                F             N46
D08SS      Tkachenko, Anna             90038268    AGBR1120200817FF  502104 UNOV11012025   31.00S   32.45S                   3 7 0 0 23           9502      NN80
D390038268                                                                                                                                                   N58
D08SS      Tkachenko, Anna             90038268    AGBR1120200817FF 2002114 UNOV11012025 2:30.90S 2:41.17S                   2 7 0 0 40           9502      NN41
G08SS          Tkachenko, Anna             90038268    1 4  50C   36.38 1:17.36 1:59.34 2:41.17                                                P             N47
D08SS      Tkachenko, Anna             90038268    AGBR1120200817FF  503403 UNOV11022025   37.40S   38.19S                   4 7 0 0 38           9503      NN01
D08SS      Tkachenko, Anna             90038268    AGBR1120200817FF 1002407 UNOV11022025 1:07.49S 1:11.81S                   3 2 0 0 26           9502      NN51
G08SS          Tkachenko, Anna             90038268    1 2  50C   34.47 1:11.81                                                                P             N95
D08SS      Tsang, Finlay               90023763    AGBR0201200718MM  503103 UNOV11012025   28.50S   29.84S            29.28S 6 5 3 2  5  4  7.   4950300    NN71
D390023763                                                                                                                                                   N48
D08SS      Tsang, Finlay               90023763    AGBR0201200718MM 1001109 UNOV11012025   51.50S   51.58S            51.10S 3 3 2 7  6  5  6.   5950100    NN61
G08SS          Tsang, Finlay               90023763    1 2  50C   24.88   51.58                                                                P             N15
G08SS          Tsang, Finlay               90023763    1 2  50C   24.59   51.10                                                                F             N94
D08SS      Tsang, Finlay               90023763    AGBR0201200718MM  502404 UNOV11022025   27.50S   26.36S            25.78S 6 6 2 2  5  3  7.   3950250    NN71
D08SS      Tsang, Finlay               90023763    AGBR0201200718MM  501412 UNOV11022025   23.00S   23.56S            23.55S 6 5 2 3  3  4  7.   4950100    NN61
C18          NDDXDelting Dolphinsasc           Delting         Lorraine Gifford      North mainland leisureBrae, Shetland        ZE2 9QJ   GBR               N57
D08        Okroj, Julian               90023038    AGBR0301201114MM 2004105 UNOV11012025 2:17.54S 2:15.47S                   4 6 0 0 10           9504      NN30
D390023038                                                                                                                                                   N48
G08            Okroj, Julian               90023038    1 4  50C   27.60 1:01.40 1:37.71 2:15.47                                                P             N16
D08        Okroj, Julian               90023038    AGBR0301201114MM 1001109 UNOV11012025   55.96S   54.47S            53.71S 1 1 1 5 17 11       19501      NN01
G08            Okroj, Julian               90023038    1 2  50C   26.68   54.47                                                                P             N64
G08            Okroj, Julian               90023038    1 2  50C   26.11   53.71                                                                F             N44
D08        Okroj, Julian               90023038    AGBR0301201114MM 4005201 UNOV11012025 4:51.06S                   4:45.76S     4 3    10  1.   3950500    NN60
G08            Okroj, Julian               90023038    1 8  50C   28.93 1:03.26 1:39.63 2:15.56 2:57.82 3:42.21 4:14.98 4:45.76                F             N29
D08        Okroj, Julian               90023038    AGBR0301201114MM  502404 UNOV11022025   28.70S   28.25S            28.14S 6 8 1 3 16 15       59502      NN90
D08        Okroj, Julian               90023038    AGBR0301201114MM 2002414 UNOV11022025 2:11.12S 2:08.77S          2:08.78S 3 3 1 7  6  6  5.   6950200    NN91
G08            Okroj, Julian               90023038    1 4  50C   29.37 1:02.10 1:35.50 2:08.77                                                P             N26
G08            Okroj, Julian               90023038    1 4  50C   29.28 1:01.95 1:35.68 2:08.78                                                F             N26
D08        Okroj, Julian               90023038    AGBR0301201114MM 8001502 UNOV11022025 8:48.01S                   8:47.81S     3 1     6  5.   5950100    NN60
G08            Okroj, Julian               90023038    116  50C   28.27 1:00.56 1:33.73 2:07.25 2:41.14 3:14.53 3:48.31 4:21.79 4:55.74 5:29.64F             N60
G08            Okroj, Julian               90023038    216  50C 6:03.11 6:37.00 7:11.02 7:45.13 8:17.03 8:47.81                                F             N97
C18          NDNXDeveron Asc                   Deveron         Nicola Gregor         !4 Stuart Street      Banff                 AB45 1FY                    N96
D08        Dow, Sarah                  90029374    A   0621201015FF 2005106 UNOV11012025 2:42.87S 2:37.02S                   6 2 0 0 29           9505      NN58
D390029374                                                                                                                                                   N58
G08            Dow, Sarah                  90029374    1 4  50C   34.90 1:15.94 2:00.34 2:37.02                                                P             N94
D08        Dow, Sarah                  90029374    A   0621201015FF 1003108 UNOV11012025 1:20.28S 1:20.69S          1:21.40S 2 8 1 0 23 20       09503      NN69
G08            Dow, Sarah                  90029374    1 2  50C   37.86 1:20.69                                                                P             N63
G08            Dow, Sarah                  90029374    1 2  50C   38.06 1:21.40                                                                F             N43
D08        Dow, Sarah                  90029374    A   0621201015FF  501112 UNOV11012025   29.44S   29.62S                   2 3 0 0 48           9501      NN97
D08        Dow, Sarah                  90029374    A   0621201015FF  503403 UNOV11022025   35.06S   36.75S                   7 1 0 0 28           9503      NN97
D08        Dow, Sarah                  90029374    A   0621201015FF 2003413 UNOV11022025 2:54.17S 2:53.00S                   3 0 0 0 23           9503      NN48
G08            Dow, Sarah                  90029374    1 4  50C   39.12 1:22.56 2:07.84 2:53.00                                                P             N94
D08        Dow, Sarah                  90029374    A   0621201015FF 4005501 UNOV11022025 5:42.31S                   5:34.03S     2 7    24       29505      NN38
G08            Dow, Sarah                  90029374    1 8  50C   36.43 1:18.81 2:03.45 2:46.53 3:32.10 4:18.30 4:57.51 5:34.03                F             N87
D08        Dow, Sarah                  90029374    A   0621201015FF 1001529 UNOV11022025 1:05.35S 1:04.88S                   1 3     24           9501      NN28
G08            Dow, Sarah                  90029374    1 2  50C   30.71 1:04.88                                                                P             N53
D08        Dow, Sarah                  90029374    A   0621201015FF 2002114 UNOV11012025 2:43.37S 2:37.57S                   5 8 0 0 30           9502      NN48
G08            Dow, Sarah                  90029374    1 4  50C   36.86 1:17.06 1:57.90 2:37.57                                                P             N15
D08        Dow, Sarah                  90029374    A   0621201015FF 1001409 UNOV11022025 1:05.35S 1:04.88S                   5 3 0 0 56           9501      NN48
G08            Dow, Sarah                  90029374    1 2  50C   30.71 1:04.88                                                                P             N53
D08        Duncan, Harry               90024621    A   1215200916MM  503103 UNOV11012025   32.57S   32.67S            33.23S 4 1 2 6 28 16       69503      NN30
D390024621                                                                                                                                                   N48
D08        Duncan, Harry               90024621    A   1215200916MM 2001522 UNOV11022025 2:07.81S 2:07.94S                   3 5      6           9501      NN59
G08            Duncan, Harry               90024621    1 4  50C   28.50 1:00.26 1:33.93 2:07.94                                                P             N16
D08        Duncan, Harry               90024621    A   1215200916MM 2003113 UNOV11012025 2:47.54S 2:46.96S                   8 3 0 0 46           9503      NN89
G08            Duncan, Harry               90024621    1 4  50C   36.76 1:20.15 2:04.22 2:46.96                                                P             N16
D08        Duncan, Harry               90024621    A   1215200916MM 1001109 UNOV11012025   55.69S   55.28S            56.29S 1 6 1 6 21 16       69501      NN40
G08            Duncan, Harry               90024621    1 2  50C   26.48   55.28                                                                P             N54
G08            Duncan, Harry               90024621    1 2  50C   26.77   56.29                                                                F             N54
D08        Duncan, Harry               90024621    A   1215200916MM  504111 UNOV11012025   28.68S   29.43S                   1 1 0 0 42           9504      NN29
D08        Duncan, Harry               90024621    A   1215200916MM 1003408 UNOV11022025 1:13.50S 1:14.61S                   1 6 0 0 41           9503      NN69
G08            Duncan, Harry               90024621    1 2  50C   34.71 1:14.61                                                                P             N64
D08        Duncan, Harry               90024621    A   1215200916MM  501412 UNOV11022025   25.57S   25.38S            25.46S 3 3 1 2 21 17       79501      NN30
D08        Duncan, Harry               90024621    A   1215200916MM 2001402 UNOV11022025 2:07.81S 2:07.94S                   7 5 0 0 43           9501      NN79
G08            Duncan, Harry               90024621    1 4  50C   28.50 1:00.26 1:33.93 2:07.94                                                P             N16
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 1004530 UNOV11022025 1:06.44S 1:06.16S                   1 6      5           9504      NN62
D390041986                                                                                                                                                   N58
G08            Girbita, Bogdan-Gabriel     90041986    1 2  50C   30.75 1:06.16                                                                P             N87
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM  503103 UNOV11012025   34.36S   34.14S                   2 5 0 0 49           9503      NN32
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 2004105 UNOV11012025 2:35.58S 2:30.78S                   1 6 0 0 29           9504      NN92
G08            Girbita, Bogdan-Gabriel     90041986    1 4  50C   32.31 1:09.34 1:49.07 2:30.78                                                P             N39
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM  502404 UNOV11022025   31.95S   31.72S                   1 2 0 0 55           9502      NN32
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 2003113 UNOV11012025 2:46.53S 2:42.45S                   7 5 0 0 35           9503      NN92
G08            Girbita, Bogdan-Gabriel     90041986    1 4  50C   36.02 1:17.29 1:59.26 2:42.45                                                P             N39
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 1003528 UNOV11022025 1:17.69S 1:14.89S                   3 2      9           9503      NN72
G08            Girbita, Bogdan-Gabriel     90041986    1 2  50C   35.20 1:14.89                                                                P             N97
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 1003408 UNOV11022025 1:17.69S 1:14.89S                   7 2 0 0 44           9503      NN03
G08            Girbita, Bogdan-Gabriel     90041986    1 2  50C   35.20 1:14.89                                                                P             N97
D08        Girbita, Bogdan-Gabriel     90041986    A   0527201015MM 1004410 UNOV11022025 1:06.44S 1:06.16S                   5 6 0 0 42           9504      NN82
G08            Girbita, Bogdan-Gabriel     90041986    1 2  50C   30.75 1:06.16                                                                P             N87
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 2002534 UNOV11022025 2:29.25S 2:28.99S                   2 4      4           9502      NN92
D390010699                                                                                                                                                   N58
G08            Wiseman, Keiran Bradley     90010699    1 4  50C   34.98 1:12.62 1:51.39 2:28.99                                                P             N69
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 2004105 UNOV11012025 2:22.75S 2:24.01S                   2 1 0 0 21           9504      NN03
G08            Wiseman, Keiran Bradley     90010699    1 4  50C   30.98 1:07.19 1:44.92 2:24.01                                                P             N59
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 4005201 UNOV11012025 5:14.53S                   5:15.68S     2 7    36       79505      NN13
G08            Wiseman, Keiran Bradley     90010699    1 8  50C   31.30 1:09.34 1:50.79 2:30.38 3:17.41 4:03.99 4:41.02 5:15.68                F             N32
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM  502404 UNOV11022025   32.40S   31.93S                   1 0 0 0 57           9502      NN52
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 1004410 UNOV11022025 1:04.09S 1:05.30S                   1 8 0 0 39           9504      NN03
G08            Wiseman, Keiran Bradley     90010699    1 2  50C   30.26 1:05.30                                                                P             N08
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 2005526 UNOV11022025 2:33.75S 2:27.59S                   1 0     13           9505      NN92
G08            Wiseman, Keiran Bradley     90010699    1 4  50C   31.46 1:09.39 1:53.34 2:27.59                                                P             N59
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 1002107 UNOV11012025 1:10.01S 1:11.34S                   6 7 0 0 63           9502      NN03
G08            Wiseman, Keiran Bradley     90010699    1 2  50C   34.40 1:11.34                                                                P             N08
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 2005406 UNOV11022025 2:33.75S 2:27.59S                   5 0 0 0 51           9505      NN13
G08            Wiseman, Keiran Bradley     90010699    1 4  50C   31.46 1:09.39 1:53.34 2:27.59                                                P             N59
D08        Wiseman, Keiran Bradley     90010699    A   0621200916MM 2002414 UNOV11022025 2:29.25S 2:28.99S                   6 4 0 0 40           9502      NN13
G08            Wiseman, Keiran Bradley     90010699    1 4  50C   34.98 1:12.62 1:51.39 2:28.99                                                P             N69
C18SS      SSMDCXDundee City Aquatics          Dun City Aqu    ---                                         -----               AKDD1 1AA                     N71
D08SS      Graham, Tori                90013357    AGBR0912200916FF 2004405 UNOV11022025 3:01.19S 3:04.30S                   1 2 0 0 35           9504      NN40
D390013357      Tori                                                                                                                                         N99
G08SS          Graham, Tori                90013357    1 4  50C   38.21 1:23.95 2:14.75 3:04.30                                                P             N26
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 1003528 UNOV11022025 1:17.38S 1:21.40S                   3 6     33           9503      NN72
D390034067      Lyle                                                                                                                                         N99
G08SS          Livingstone, Lyle R         90034067    1 2  50C   38.10 1:21.40                                                                P             N27
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 2005526 UNOV11022025 2:27.49S 2:29.59S                   3 2     19           9505      NN92
G08SS          Livingstone, Lyle R         90034067    1 4  50C   32.05 1:11.88 1:55.40 2:29.59                                                P             N78
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 2001522 UNOV11022025 2:10.93S 2:13.47S                   1 6     16           9501      NN72
G08SS          Livingstone, Lyle R         90034067    1 4  50C   29.40                 2:13.47                                                P             N27
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 2001402 UNOV11022025 2:10.93S 2:13.47S                   5 6 0 0 54           9501      NN92
G08SS          Livingstone, Lyle R         90034067    1 4  50C   29.40                 2:13.47                                                P             N27
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 2005406 UNOV11022025 2:27.49S 2:29.59S                   7 2 0 0 57           9505      NN13
G08SS          Livingstone, Lyle R         90034067    1 4  50C   32.05 1:11.88 1:55.40 2:29.59                                                P             N78
D08SS      Livingstone, Lyle R         90034067    AGBR0821200916MM 1003408 UNOV11022025 1:17.38S 1:21.40S                   7 6 0 0 69           9503      NN03
G08SS          Livingstone, Lyle R         90034067    1 2  50C   38.10 1:21.40                                                                P             N27
D08SS      McGhee, Emily C             90002932    AGBR1128200322FF 1003108 UNOV11012025 1:09.30S 1:10.00S          1:09.20S 4 4 2 4  1  1 10.   1950300    NN12
D390002932                                                                                                                                                   N48
G08SS          McGhee, Emily C             90002932    1 2  50C   32.93 1:10.00                                                                P             N05
G08SS          McGhee, Emily C             90002932    1 2  50C   33.06 1:09.20                                                                F             N05
D08SS      McGhee, Emily C             90002932    AGBR1128200322FF  503403 UNOV11022025   31.90S   32.99S            32.84S 7 4 2 4  1  1 10.   1950300    NN51
D08SS      McGhee, Emily C             90002932    AGBR1128200322FF 2003413 UNOV11022025 2:29.86S 2:34.38S          2:31.25S 4 4 1 4  1  1 10.   1950300    NN22
G08SS          McGhee, Emily C             90002932    1 4  50C   34.94 1:13.94 1:53.95 2:34.38                                                P             N66
G08SS          McGhee, Emily C             90002932    1 4  50C   34.82 1:13.18 1:52.72 2:31.25                                                F             N56
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 1003108 UNOV11012025 1:25.50S 1:26.30S                   6 5 0 0 45           9503      NN22
D390046042      Katie                                                                                                                                        N20
G08SS          McLaughlan, Katie L         90046042    1 2  50C   40.72 1:26.30                                                                P             N66
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 1001529 UNOV11022025 1:05.07S 1:05.88S                   2 9     30           9501      NN12
G08SS          McLaughlan, Katie L         90046042    1 2  50C   31.11 1:05.88                                                                P             N76
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 2005106 UNOV11012025 2:44.12S 2:41.81S                   5 2 0 0 42           9505      NN22
G08SS          McLaughlan, Katie L         90046042    1 4  50C   35.91 1:18.19 2:06.45 2:41.81                                                P             N28
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 2003533 UNOV11022025 3:07.84S 3:04.01S                   2 1      8           9503      NN02
G08SS          McLaughlan, Katie L         90046042    1 4  50C   40.92 1:28.77 2:17.59 3:04.01                                                P             N28
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF  502104 UNOV11012025   33.99S   35.47S                   2 9 0 0 42           9502      NN81
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF  501112 UNOV11012025   29.40S   29.67S                   2 4 0 0 50           9501      NN71
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF  503403 UNOV11022025   38.19S   38.55S                   3 9 0 0 44           9503      NN81
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 4005501 UNOV11022025 5:45.47S                   5:42.27S     2 8    31       79505      NN32
G08SS          McLaughlan, Katie L         90046042    1 8  50C   35.71 1:19.00 2:02.93 2:46.74 3:36.10 4:26.71 5:05.32 5:42.27                F             N01
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 1001409 UNOV11022025 1:05.07S 1:05.88S                   6 9 0 0 63           9501      NN32
G08SS          McLaughlan, Katie L         90046042    1 2  50C   31.11 1:05.88                                                                P             N76
D08SS      McLaughlan, Katie L         90046042    AGBR1116201114FF 2003413 UNOV11022025 3:07.84S 3:04.01S                   6 1 0 0 44           9503      NN22
G08SS          McLaughlan, Katie L         90046042    1 4  50C   40.92 1:28.77 2:17.59 3:04.01                                                P             N28
D08SS      Phillips, Robbie A          90020004    AGBR0113201015MM 1002107 UNOV11012025 1:13.00S 1:12.05S                   5 6 0 0 66           9502      NN02
D390020004                                                                                                                                                   N48
G08SS          Phillips, Robbie A          90020004    1 2  50C   34.12 1:12.05                                                                P             N46
D08SS      Pirie, Lucy                 90019541    AGBR0403201213FF 2004525 UNOV11022025 3:09.53S 3:04.51S                   1 3      3           9504      NN89
D390019541                                                                                                                                                   N48
G08SS          Pirie, Lucy                 90019541    1 4  50C   38.54 1:24.88 2:14.48 3:04.51                                                P             N06
D08SS      Pirie, Lucy                 90019541    AGBR0403201213FF 2004405 UNOV11022025 3:09.53S 3:04.51S                   5 3 0 0 36           9504      NN10
G08SS          Pirie, Lucy                 90019541    1 4  50C   38.54 1:24.88 2:14.48 3:04.51                                                P             N06
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 2005526 UNOV11022025 2:32.25S 2:34.06S                   2 8     25           9505      NN60
D390042008      Lyall                                                                                                                                        N30
G08SS          Smith, Lyall D              90042008    1 4  50C   32.10 1:14.84 1:59.19 2:34.06                                                P             N56
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 1004530 UNOV11022025 1:06.09S 1:07.33S                   2 3      7           9504      NN50
G08SS          Smith, Lyall D              90042008    1 2  50C   30.97 1:07.33                                                                P             N15
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 2001522 UNOV11022025 2:10.94S 2:09.77S                   3 2     12           9501      NN60
G08SS          Smith, Lyall D              90042008    1 4  50C   29.26 1:02.00 1:35.60 2:09.77                                                P             N56
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 2001402 UNOV11022025 2:10.94S 2:09.77S                   7 2 0 0 50           9501      NN80
G08SS          Smith, Lyall D              90042008    1 4  50C   29.26 1:02.00 1:35.60 2:09.77                                                P             N56
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 2005406 UNOV11022025 2:32.25S 2:34.06S                   6 8 0 0 63           9505      NN80
G08SS          Smith, Lyall D              90042008    1 4  50C   32.10 1:14.84 1:59.19 2:34.06                                                P             N56
D08SS      Smith, Lyall D              90042008    AGBR0506200916MM 1004410 UNOV11022025 1:06.09S 1:07.33S                   6 3 0 0 44           9504      NN70
G08SS          Smith, Lyall D              90042008    1 2  50C   30.97 1:07.33                                                                P             N15
D08SS      Williamson, Dara S          90038931    AGBR0329200916FF 1003108 UNOV11012025 1:22.10S 1:23.06S                   1 5 0 0 35           9503      NN22
D390038931      Dara                                                                                                                                         N89
G08SS          Williamson, Dara S          90038931    1 2  50C   39.14 1:23.06                                                                P             N66
D08SS      Williamson, Dara S          90038931    AGBR0329200916FF 4001401 UNOV11022025 5:04.90S 5:05.75S                   1 2 0 0 35           9501      NN32
G08SS          Williamson, Dara S          90038931    1 8  50C   33.53 1:10.78 1:49.61 2:29.60 3:09.38 3:49.24 4:28.34 5:05.75                P             N11
D08SS      Williamson, Dara S          90038931    AGBR0329200916FF  503403 UNOV11022025   37.60S   39.00S                   4 9 0 0 50           9503      NN81
C18          UELXEast Lothian Swim Team        East Lothian                                                                                GBR               N30
D08        Brown, Findlay              1277449     A   0603200718MM  503103 UNOV11012025   32.10S   32.95S                   5 9 0 0 34           9503      NN59
D31277449                                                                                                                                                    N48
D08        Brown, Findlay              1277449     A   0603200718MM 1002107 UNOV11012025 1:02.86S 1:01.86S                   3 7 0 0 12           9502      NN10
G08            Brown, Findlay              1277449     1 2  50C   29.95 1:01.86                                                                P             N15
D08        Brown, Findlay              1277449     A   0603200718MM 2003113 UNOV11012025 2:36.19S 2:35.37S                   4 0 0 0 17           9503      NN10
G08            Brown, Findlay              1277449     1 4  50C   33.52 1:13.26 1:53.87 2:35.37                                                P             N56
D08        Brown, Findlay              1277449     A   0603200718MM  502404 UNOV11022025   29.60S   28.89S                   3 4 0 0 23           9502      NN69
D08        Brown, Findlay              1277449     A   0603200718MM 2005406 UNOV11022025 2:18.70S 2:19.09S                   4 1 0 0 21           9505      NN10
G08            Brown, Findlay              1277449     1 4  50C   30.48 1:05.79 1:46.33 2:19.09                                                P             N66
D08        Brown, Findlay              1277449     A   0603200718MM 2002414 UNOV11022025 2:17.18S 2:14.84S                   4 2 0 0 11           9502      NN10
G08            Brown, Findlay              1277449     1 4  50C   30.41 1:04.40 1:39.71 2:14.84                                                P             N56
D08        Budgen, Archie              90021496    A   0626201015MM 2005526 UNOV11022025 2:28.81S 2:25.39S                   1 2      6           9505      NN79
D390021496                                                                                                                                                   N58
G08            Budgen, Archie              90021496    1 4  50C   30.56 1:09.21 1:53.37 2:25.39                                                P             N36
D08        Budgen, Archie              90021496    A   0626201015MM 1001109 UNOV11012025   58.80S   57.55S                   6 8 0 0 45           9501      NN59
G08            Budgen, Archie              90021496    1 2  50C   27.84   57.55                                                                P             N74
D08        Budgen, Archie              90021496    A   0626201015MM 4001101 UNOV11012025 4:42.20S 4:32.03S                   1 9 0 0 29           9501      NN89
G08            Budgen, Archie              90021496    1 8  50C   29.98 1:03.82 1:38.77 2:14.04 2:49.10 3:24.42 3:59.01 4:32.03                P             N39
D08        Budgen, Archie              90021496    A   0626201015MM 2002414 UNOV11022025 2:28.39S 2:24.71S                   1 0 0 0 33           9502      NN99
G08            Budgen, Archie              90021496    1 4  50C   33.58 1:10.19 1:47.80 2:24.71                                                P             N36
D08        Budgen, Archie              90021496    A   0626201015MM 2005406 UNOV11022025 2:28.81S 2:25.39S                   5 2 0 0 43           9505      NN00
G08            Budgen, Archie              90021496    1 4  50C   30.56 1:09.21 1:53.37 2:25.39                                                P             N36
D08        Davis, Abby                 1154804     A   0925200322FF  501112 UNOV11012025   28.40S   29.18S                   5 6 0 0 36           9501      NN18
D31154804                                                                                                                                                    N38
D08        Fearnside, Boyd             90020407    A   0610201015MM 1001109 UNOV11012025   58.20S   57.33S                   5 2 0 0 41           9501      NN89
D390020407                                                                                                                                                   N48
G08            Fearnside, Boyd             90020407    1 2  50C   27.57   57.33                                                                P             N15
D08        Fearnside, Boyd             90020407    A   0610201015MM 1003528 UNOV11022025 1:15.92S 1:14.63S                   5 3      8           9503      NN10
G08            Fearnside, Boyd             90020407    1 2  50C   35.23 1:14.63                                                                P             N35
D08        Fearnside, Boyd             90020407    A   0610201015MM  503103 UNOV11012025   34.50S   34.30S                   2 6 0 0 53           9503      NN79
D08        Fearnside, Boyd             90020407    A   0610201015MM 2002414 UNOV11022025 2:24.30S 2:23.66S                   1 4 0 0 30           9502      NN20
G08            Fearnside, Boyd             90020407    1 4  50C   33.04 1:09.18 1:46.75 2:23.66                                                P             N86
D08        Fearnside, Boyd             90020407    A   0610201015MM 2001522 UNOV11022025 2:09.60S 2:09.35S                   2 3     11           9501      NN10
G08            Fearnside, Boyd             90020407    1 4  50C   28.83 1:01.27 1:35.50 2:09.35                                                P             N86
D08        Fearnside, Boyd             90020407    A   0610201015MM 2001402 UNOV11022025 2:09.60S 2:09.35S                   6 3 0 0 49           9501      NN30
G08            Fearnside, Boyd             90020407    1 4  50C   28.83 1:01.27 1:35.50 2:09.35                                                P             N86
D08        Fearnside, Boyd             90020407    A   0610201015MM 1003408 UNOV11022025 1:15.92S 1:14.63S                   9 3 0 0 42           9503      NN30
G08            Fearnside, Boyd             90020407    1 2  50C   35.23 1:14.63                                                                P             N35
D08        Finlay, Alice               1297320     A   0226200817FF  502104 UNOV11012025   31.70S   32.43S                   5 8 0 0 22           9502      NN88
D31297320                                                                                                                                                    N38
D08        Finlay, Alice               1297320     A   0226200817FF 1004110 UNOV11012025 1:09.98S 1:14.19S                   1 2 0 0 41           9504      NN49
G08            Finlay, Alice               1297320     1 2  50C   33.19 1:14.19                                                                P             N44
D08        Finlay, Alice               1297320     A   0226200817FF  501112 UNOV11012025   29.10S   30.65S                   3 6 0 0 62           9501      NN88
D08        Finlay, Alice               1297320     A   0226200817FF  504411 UNOV11022025   30.90S   32.06S                   3 2 0 0 41           9504      NN88
D08        Hall, Lucy                  90015789    A   0622200916FF 2001102 UNOV11012025 2:10.30S 2:08.49S          2:07.03S 3 2 1 7  6  6  5.   6950100    NN99
D390015789                                                                                                                                                   N58
G08            Hall, Lucy                  90015789    1 4  50C   29.83 1:02.32 1:35.53 2:08.49                                                P             N05
G08            Hall, Lucy                  90015789    1 4  50C   29.55 1:01.81 1:34.53 2:07.03                                                F             N94
D08        Hall, Lucy                  90015789    A   0622200916FF 8001202 UNOV11012025 9:20.30S                   9:14.42S     3 5     2  9.   2950100    NN78
G08            Hall, Lucy                  90015789    116  50C   30.58 1:04.76 1:39.17 2:13.89 2:48.57 3:23.49 3:58.81 4:34.13 5:09.45 5:44.93F             N69
G08            Hall, Lucy                  90015789    216  50C 6:20.13 6:55.26 7:30.44 8:05.57 8:40.58 9:14.42                                F             N96
D08        Hall, Lucy                  90015789    A   0622200916FF 4001401 UNOV11022025 4:31.50S 4:31.28S          4:29.47S 4 3 1 3  3  4  7.   4950100    NN00
G08            Hall, Lucy                  90015789    1 8  50C   30.20 1:03.70 1:37.95 2:12.57 2:47.32 3:22.23 3:57.09 4:31.28                P             N97
G08            Hall, Lucy                  90015789    1 8  50C   29.60 1:02.23 1:36.00 2:10.51 2:45.78 3:21.29 3:56.54 4:29.47                F             N97
D08        Hall, Lucy                  90015789    A   0622200916FF 1001409 UNOV11022025 1:00.20S 1:00.73S          1:00.37S 2 8 1 6 16 14       49501      NN79
G08            Hall, Lucy                  90015789    1 2  50C   29.26 1:00.73                                                                P             N63
G08            Hall, Lucy                  90015789    1 2  50C   29.14 1:00.37                                                                F             N53
D08        Hall, Lucy                  90015789    A   0622200916FF  504411 UNOV11022025   30.30S   31.01S            31.13S 4 2 1 1 24 19       99504      NN09
D08        Kariuki, Veronika           90033326    A   1227201114FF 2005106 UNOV11012025 2:40.06S 2:41.80S                   1 0 0 0 41           9505      NN11
D390033326                                                                                                                                                   N48
G08            Kariuki, Veronika           90033326    1 4  50C   35.09 1:18.67 2:03.95 2:41.80                                                P             N87
D08        Kariuki, Veronika           90033326    A   1227201114FF 1003108 UNOV11012025 1:17.80S 1:19.64S          1:16.61S 3 1 1 7 19 13       39503      NN52
G08            Kariuki, Veronika           90033326    1 2  50C   37.13 1:19.64                                                                P             N36
G08            Kariuki, Veronika           90033326    1 2  50C   36.41 1:16.61                                                                F             N26
D08        Kariuki, Veronika           90033326    A   1227201114FF  503403 UNOV11022025   35.30S   36.03S            34.89S 7 8 1 6 16 13       39503      NN81
D08        Kariuki, Veronika           90033326    A   1227201114FF 2003413 UNOV11022025 2:51.90S 2:52.27S                   2 8 0 0 22           9503      NN21
G08            Kariuki, Veronika           90033326    1 4  50C   38.68 1:21.96 2:08.04 2:52.27                                                P             N87
D08        Kariuki, Veronika           90033326    A   1227201114FF 1001529 UNOV11022025 1:05.47S 1:05.09S                   1 6     26           9501      NN01
G08            Kariuki, Veronika           90033326    1 2  50C   31.18 1:05.09                                                                P             N36
D08        Kariuki, Veronika           90033326    A   1227201114FF 1001409 UNOV11022025 1:05.47S 1:05.09S                   5 6 0 0 58           9501      NN21
G08            Kariuki, Veronika           90033326    1 2  50C   31.18 1:05.09                                                                P             N36
D08        Kenny, Morven               90019126    A   1215201015FF  501112 UNOV11012025   29.90S   29.38S                   1 4 0 0 42           9501      NN29
D390019126                                                                                                                                                   N48
D08        Kenny, Morven               90019126    A   1215201015FF 4005501 UNOV11022025 5:43.52S                   5:39.12S     2 1    27       49505      NN79
G08            Kenny, Morven               90019126    1 8  50C   34.53 1:16.60 2:00.28 2:42.77 3:34.44 4:26.12 5:03.81 5:39.12                F             N19
D08        Kenny, Morven               90019126    A   1215201015FF 2001102 UNOV11012025 2:19.89S 2:17.51S                   5 3 0 0 31           9501      NN79
G08            Kenny, Morven               90019126    1 4  50C   30.74 1:05.39 1:41.80 2:17.51                                                P             N36
D08        Kenny, Morven               90019126    A   1215201015FF 1001529 UNOV11022025 1:03.10S 1:03.33S                   3 2     13           9501      NN59
G08            Kenny, Morven               90019126    1 2  50C   30.35 1:03.33                                                                P             N84
D08        Kenny, Morven               90019126    A   1215201015FF 2005106 UNOV11012025 2:40.49S 2:45.33S                   5 4 0 0 49           9505      NN89
G08            Kenny, Morven               90019126    1 4  50C   34.54 1:18.25 2:09.20 2:45.33                                                P             N36
D08        Kenny, Morven               90019126    A   1215201015FF 1001409 UNOV11022025 1:03.10S 1:03.33S                   7 2 0 0 42           9501      NN79
G08            Kenny, Morven               90019126    1 2  50C   30.35 1:03.33                                                                P             N84
D08        Krawiec, Zara               1288448     A   0526200916FF 2005106 UNOV11012025 2:17.10S 2:22.00S          2:17.51S 4 4 1 4  1  1 10.   1950500    NN01
D31288448                                                                                                                                                    N48
G08            Krawiec, Zara               1288448     1 4  50C   30.34 1:05.72 1:47.93 2:22.00                                                P             N06
G08            Krawiec, Zara               1288448     1 4  50C   30.56 1:06.30 1:46.88 2:17.51                                                F             N06
D08        Krawiec, Zara               1288448     A   0526200916FF 2002114 UNOV11012025 2:16.62S 2:19.58S          2:16.95S 3 4 1 4  1  1 10.   1950200    NN11
G08            Krawiec, Zara               1288448     1 4  50C   32.70 1:08.01 1:43.96 2:19.58                                                P             N16
G08            Krawiec, Zara               1288448     1 4  50C   32.82 1:08.32 1:43.20 2:16.95                                                F             N06
D08        Krawiec, Zara               1288448     A   0526200916FF 1001409 UNOV11022025   56.20S   57.59S            56.34S 3 4 2 4  1  1 10.   1950100    NN40
G08            Krawiec, Zara               1288448     1 2  50C   27.96   57.59                                                                P             N54
G08            Krawiec, Zara               1288448     1 2  50C   27.42   56.34                                                                F             N34
D08        Krawiec, Zara               1288448     A   0526200916FF 2003413 UNOV11022025 2:38.66S 2:42.06S          2:38.11S 2 4 1 2  5  3  8.   3950300    NN01
G08            Krawiec, Zara               1288448     1 4  50C   36.10 1:17.63 1:59.77 2:42.06                                                P             N16
G08            Krawiec, Zara               1288448     1 4  50C   37.62 1:18.02 1:58.79 2:38.11                                                F             N06
D08        Lawson, Anna                90019303    A   0916200916FF  502104 UNOV11012025   31.12S   31.78S            31.73S 4 1 1 7 19 16       69502      NN89
D390019303                                                                                                                                                   N48
D08        Lawson, Anna                90019303    A   0916200916FF  501112 UNOV11012025   26.40S   27.43S            27.79S 6 5 2 9 11 10  1.   0950100    NN10
D08        Lawson, Anna                90019303    A   0916200916FF  503403 UNOV11022025   35.49S   36.38S            36.64S 5 8 1 1 20 20       09503      NN89
D08        Lawson, Anna                90019303    A   0916200916FF  504411 UNOV11022025   30.30S   31.18S            31.60S 4 6 1 8 26 20       09504      NN79
D08        Lawson, Anna                90019303    A   0916200916FF 2003413 UNOV11022025 2:55.93S      NSS                   2 9 0 0  0           9503      NN09
G08            Lawson, Anna                90019303    1 4  50C                                                                                P             N13
D08        Lothian, Lewis              90006334    A   0330200916MM 1001109 UNOV11012025   56.10S   55.87S            57.49S 7 4 1 9 28 18       89501      NN90
D390006334                                                                                                                                                   N48
G08            Lothian, Lewis              90006334    1 2  50C   26.77   55.87                                                                P             N05
G08            Lothian, Lewis              90006334    1 2  50C   27.49   57.49                                                                F             N94
D08        Lothian, Lewis              90006334    A   0330200916MM  503103 UNOV11012025   31.30S   32.51S            32.32S 7 0 2 4 26 13       39503      NN60
D08        Lothian, Lewis              90006334    A   0330200916MM 2003113 UNOV11012025 2:29.46S 2:33.30S                   3 2 0 0 16           9503      NN10
G08            Lothian, Lewis              90006334    1 4  50C   33.30 1:12.29 1:52.58 2:33.30                                                P             N56
D08        Lothian, Lewis              90006334    A   0330200916MM 2005406 UNOV11022025 2:16.30S 2:15.65S          2:16.82S 2 6 1 0 11 10  1.   0950500    NN71
G08            Lothian, Lewis              90006334    1 4  50C   30.54 1:05.89 1:44.82 2:15.65                                                P             N66
G08            Lothian, Lewis              90006334    1 4  50C   29.62 1:06.47 1:45.78 2:16.82                                                F             N66
D08        Lothian, Lewis              90006334    A   0330200916MM 1003408 UNOV11022025 1:09.20S 1:10.34S          1:09.86S 2 2 1 3 18 14       49503      NN41
G08            Lothian, Lewis              90006334    1 2  50C   33.03 1:10.34                                                                P             N05
G08            Lothian, Lewis              90006334    1 2  50C   32.83 1:09.86                                                                F             N15
D08        Lothian, Lewis              90006334    A   0330200916MM  501412 UNOV11022025   25.40S   25.33S            25.40S 3 5 1 3 19 16       69501      NN60
D08        Marshall, Carly             90026614    A   0526201015FF 1004110 UNOV11012025 1:17.00S 1:20.46S                   6 7 0 0 52           9504      NN30
D390026614                                                                                                                                                   N48
G08            Marshall, Carly             90026614    1 2  50C   37.34 1:20.46                                                                P             N45
D08        Marshall, Carly             90026614    A   0526201015FF 1003108 UNOV11012025 1:22.90S      DQS                   1 2 0 0  0           9503      NN99
G08            Marshall, Carly             90026614    1 2  50C   40.19 1:26.11                                                                P             N45
D08        Marshall, Carly             90026614    A   0526201015FF  503403 UNOV11022025   38.00S   38.95S                   3 7 0 0 49           9503      NN99
D08        Marshall, Carly             90026614    A   0526201015FF 2003413 UNOV11022025 2:56.17S 3:02.41S                   1 4 0 0 42           9503      NN30
G08            Marshall, Carly             90026614    1 4  50C   40.40 1:26.91 2:14.99 3:02.41                                                P             N96
D08        McLean, Jonathan            90007361    A   0619200916MM 1004530 UNOV11022025 1:04.40S 1:03.45S                   2 4      1           9504      NN30
D390007361                                                                                                                                                   N48
G08            McLean, Jonathan            90007361    1 2  50C   29.58 1:03.45                                                                P             N65
D08        McLean, Jonathan            90007361    A   0619200916MM 4001101 UNOV11012025 4:36.59S 4:30.07S                   1 1 0 0 25           9501      NN60
G08            McLean, Jonathan            90007361    1 8  50C   28.50 1:00.70 1:34.22 2:08.96 2:44.31 3:20.40 3:56.22 4:30.07                P             N89
D08        McLean, Jonathan            90007361    A   0619200916MM 1002107 UNOV11012025 1:05.40S 1:05.26S                   2 0 0 0 32           9502      NN50
G08            McLean, Jonathan            90007361    1 2  50C   31.26 1:05.26                                                                P             N55
D08        McLean, Jonathan            90007361    A   0619200916MM 2001402 UNOV11022025 2:05.59S 2:04.17S                   1 8 0 0 31           9501      NN60
G08            McLean, Jonathan            90007361    1 4  50C   28.14   59.21 1:32.14 2:04.17                                                P             N76
D08        McLean, Jonathan            90007361    A   0619200916MM  502404 UNOV11022025   29.80S   30.28S                   3 6 0 0 37           9502      NN10
D08        McLean, Jonathan            90007361    A   0619200916MM 1004410 UNOV11022025 1:04.40S 1:03.45S          1:03.30S 6 4 1 0 31 19       99504      NN81
G08            McLean, Jonathan            90007361    1 2  50C   29.58 1:03.45                                                                P             N65
G08            McLean, Jonathan            90007361    1 2  50C   29.88 1:03.30                                                                F             N55
D08        Nolan, Kate                 90011417    A   0611200916FF 2001102 UNOV11012025 2:10.20S 2:14.14S                   4 2 0 0 18           9501      NN68
D390011417                                                                                                                                                   N48
G08            Nolan, Kate                 90011417    1 4  50C   29.76 1:03.13 1:38.04 2:14.14                                                P             N25
D08        Nolan, Kate                 90011417    A   0611200916FF 2002114 UNOV11012025 2:33.20S 2:36.28S                   4 0 0 0 25           9502      NN78
G08            Nolan, Kate                 90011417    1 4  50C   35.95 1:14.99 1:55.55 2:36.28                                                P             N45
D08        Nolan, Kate                 90011417    A   0611200916FF 8001202 UNOV11012025 9:33.20S                   9:37.11S     3 3     5  6.   5950100    NN09
G08            Nolan, Kate                 90011417    116  50C   31.81 1:06.42 1:41.73 2:17.77 2:54.05 3:30.15 4:06.94 4:44.19 5:21.59 5:58.67F             N89
G08            Nolan, Kate                 90011417    216  50C 6:36.03 7:13.16 7:49.71 8:26.51 9:02.18 9:37.11                                F             N17
D08        Nolan, Kate                 90011417    A   0611200916FF 4001401 UNOV11022025 4:33.90S 4:43.65S          4:44.09S 4 6 1 0  9  9  2.   9950100    NN30
G08            Nolan, Kate                 90011417    1 8  50C   30.82 1:04.84 1:39.94 2:15.99 2:52.40 3:29.32 4:06.67 4:43.65                P             N38
G08            Nolan, Kate                 90011417    1 8  50C   30.84 1:04.67 1:40.14 2:15.99 2:52.42 3:29.75 4:07.61 4:44.09                F             N28
D08        Potter, Chloe               90025579    A   1216201015FF 1003108 UNOV11012025 1:21.50S 1:22.48S                   2 9 0 0 31           9503      NN79
D390025579                                                                                                                                                   N58
G08            Potter, Chloe               90025579    1 2  50C   38.39 1:22.48                                                                P             N84
D08        Potter, Chloe               90025579    A   1216201015FF  503403 UNOV11022025   35.90S      NSS                   5 0 0 0  0           9503      NN19
D08        Potter, Chloe               90025579    A   1216201015FF 2003413 UNOV11022025 3:00.80S      NSS                   1 9 0 0  0           9503      NN49
G08            Potter, Chloe               90025579    1 4  50C                                                                                P             N63
D08        Prest, Alexander            90015123    A   0803201015MM 2003113 UNOV11012025 2:49.98S 2:51.41S                   6 7 0 0 54           9503      NN90
D390015123                                                                                                                                                   N48
G08            Prest, Alexander            90015123    1 4  50C   39.08 1:21.66 2:07.00 2:51.41                                                P             N37
D08        Prest, Alexander            90015123    A   0803201015MM 1003528 UNOV11022025 1:21.24S 1:20.18S                   3 9     26           9503      NN70
G08            Prest, Alexander            90015123    1 2  50C   37.62 1:20.18                                                                P             N85
D08        Prest, Alexander            90015123    A   0803201015MM 2002534 UNOV11022025 2:37.33S 2:31.03S                   1 2      6           9502      NN50
G08            Prest, Alexander            90015123    1 4  50C   33.86 1:11.97 1:51.14 2:31.03                                                P             N37
D08        Prest, Alexander            90015123    A   0803201015MM 1002107 UNOV11012025 1:10.99S 1:08.48S                   6 8 0 0 49           9502      NN90
G08            Prest, Alexander            90015123    1 2  50C   32.94 1:08.48                                                                P             N95
D08        Prest, Alexander            90015123    A   0803201015MM 1003408 UNOV11022025 1:21.24S 1:20.18S                   7 9 0 0 62           9503      NN80
G08            Prest, Alexander            90015123    1 2  50C   37.62 1:20.18                                                                P             N85
D08        Prest, Alexander            90015123    A   0803201015MM 2002414 UNOV11022025 2:37.33S 2:31.03S                   5 2 0 0 44           9502      NN80
G08            Prest, Alexander            90015123    1 4  50C   33.86 1:11.97 1:51.14 2:31.03                                                P             N37
D08        Taylor, Alex                1293402     A   0703200817MM 1001109 UNOV11012025   55.60S   56.15S                   1 4 0 0 30           9501      NN88
D31293402                                                                                                                                                    N38
G08            Taylor, Alex                1293402     1 2  50C   26.46   56.15                                                                P             N14
D08        Taylor, Alex                1293402     A   0703200817MM  504111 UNOV11012025   26.00S   26.96S                   3 7 0 0 13           9504      NN78
D08        Taylor, Alex                1293402     A   0703200817MM 1004410 UNOV11022025   59.90S 1:00.56S                   3 7 0 0 13           9504      NN19
G08            Taylor, Alex                1293402     1 2  50C   27.94 1:00.56                                                                P             N34
D08        Taylor, Alex                1293402     A   0703200817MM  501412 UNOV11022025   24.30S   24.47S            24.39S 4 2 2 9 10  9  2.   9950100    NN10
D08        Taylor, Alex                1293402     A   0703200817MM  501412SUNOV11022025   24.47S            23.94S              1 5     1       1  01      NN68
D08        Warner, Liam                90005553    A   0109200916MM 2001522 UNOV11022025 2:12.30S 2:08.05S                   1 2      8           9501      NN09
D390005553                                                                                                                                                   N48
G08            Warner, Liam                90005553    1 4  50C   29.18 1:02.09 1:35.80 2:08.05                                                P             N75
D08        Warner, Liam                90005553    A   0109200916MM  503103 UNOV11012025   32.90S   32.82S            32.81S 3 4 2 2 33 14       49503      NN89
D08        Warner, Liam                90005553    A   0109200916MM 2003113 UNOV11012025 2:36.70S 2:36.48S                   3 0 0 0 23           9503      NN39
G08            Warner, Liam                90005553    1 4  50C   33.50 1:13.15 1:54.78 2:36.48                                                P             N85
D08        Warner, Liam                90005553    A   0109200916MM 1003408 UNOV11022025 1:13.49S 1:11.62S          1:11.84S 1 3 1 2 22 16       69503      NN60
G08            Warner, Liam                90005553    1 2  50C   33.25 1:11.62                                                                P             N24
G08            Warner, Liam                90005553    1 2  50C   33.15 1:11.84                                                                F             N24
D08        Warner, Liam                90005553    A   0109200916MM 2001402 UNOV11022025 2:12.30S 2:08.05S                   5 2 0 0 45           9501      NN29
G08            Warner, Liam                90005553    1 4  50C   29.18 1:02.09 1:35.80 2:08.05                                                P             N75
D08        Whetton, Isla P             90011951    A   0328200916FF  502104 UNOV11012025   30.04S   31.34S            30.77S 3 6 1 3 14 12       29502      NN40
D390011951                                                                                                                                                   N48
D08        Whetton, Isla P             90011951    A   0328200916FF 2002114 UNOV11012025 2:23.01S      NSS                   3 5 0 0  0           9502      NN69
G08            Whetton, Isla P             90011951    1 4  50C                                                                                P             N83
D08        Whetton, Isla P             90011951    A   0328200916FF 4001401 UNOV11022025 4:51.98S      NSS                   2 6 0 0  0           9501      NN79
G08            Whetton, Isla P             90011951    1 8  50C                                                                                P             N93
D08        Whetton, Isla P             90011951    A   0328200916FF 1002407 UNOV11022025 1:05.59S 1:07.41S          1:06.00S 4 6 2 9 10  8  2.   8950250    NN61
G08            Whetton, Isla P             90011951    1 2  50C   32.73 1:07.41                                                                P             N05
G08            Whetton, Isla P             90011951    1 2  50C   32.31 1:06.00                                                                F             N94
D08        Whetton, Isla P             90011951    A   0328200916FF  504411 UNOV11022025   29.60S   31.30S                   6 8 0 0 30           9504      NN59
D08        Winters, Ross               90026369    A   0220201114MM 1001109 UNOV11012025   57.90S   56.21S                   6 6 0 0 31           9501      NN59
D390026369                                                                                                                                                   N58
G08            Winters, Ross               90026369    1 2  50C   27.39   56.21                                                                P             N84
D08        Winters, Ross               90026369    A   0220201114MM 4001101 UNOV11012025 4:34.30S 4:26.10S                   1 5 0 0 20           9501      NN89
G08            Winters, Ross               90026369    1 8  50C   29.72 1:02.68 1:36.33 2:10.21 2:44.54 3:19.11 3:53.36 4:26.10                P             N39
D08        Winters, Ross               90026369    A   0220201114MM 1002107 UNOV11012025 1:06.00S 1:03.94S          1:03.65S 1 3 1 8 22 16       69502      NN21
G08            Winters, Ross               90026369    1 2  50C   31.16 1:03.94                                                                P             N05
G08            Winters, Ross               90026369    1 2  50C   30.43 1:03.65                                                                F             N94
D08        Winters, Ross               90026369    A   0220201114MM 2005406 UNOV11022025 2:23.08S 2:23.68S                   1 1 0 0 38           9505      NN00
G08            Winters, Ross               90026369    1 4  50C   30.71 1:07.28 1:50.76 2:23.68                                                P             N56
D08        Winters, Ross               90026369    A   0220201114MM 2002414 UNOV11022025 2:21.26S 2:19.84S                   3 8 0 0 20           9502      NN00
G08            Winters, Ross               90026369    1 4  50C   32.29 1:08.03 1:44.64 2:19.84                                                P             N56
E08        A  UELX  X 2006301 UNOV  011012025 1:47.74S                   1:44.58S     1 4     5                                                1N13001  X    N15
F08              UELXATaylor, Alex                1293402        0703200817M  1             1293402                                                          N45
G08            Taylor, Alex                1293402     1 4  50C   24.19                                                                        F             N53
F08              UELXALothian, Lewis              90006334       0330200916M  2             90006334                                                         N46
G08            Lothian, Lewis              90006334    1 4  50C   48.94                                                                        F             N44
F08              UELXALawson, Anna                90019303       0916200916F  3             90019303                                                         N55
G08            Lawson, Anna                90019303    1 4  50C 1:16.55                                                                        F             N73
F08              UELXAKrawiec, Zara               1288448        0526200916F  4             1288448                                                          N85
G08            Krawiec, Zara               1288448     1 4  50C 1:44.58                                                                        F             N14
E08        B  UELX  X 2006301 UNOV  011012025 1:48.40S                   1:49.33S     1 3    12                                                2N13001  X    N25
F08              UELXBMcLean, Jonathan            90007361       0619200916M  1             90007361                                                         N86
G08            McLean, Jonathan            90007361    1 4  50C   26.37                                                                        F             N84
F08              UELXBBrown, Findlay              1277449        0603200718M  2             1277449                                                          N36
G08            Brown, Findlay              1277449     1 4  50C   52.95                                                                        F             N34
F08              UELXBNolan, Kate                 90011417       0611200916F  3             90011417                                                         N05
G08            Nolan, Kate                 90011417    1 4  50C 1:21.48                                                                        F             N33
F08              UELXBHall, Lucy                  90015789       0622200916F  4             90015789                                                         N94
G08            Hall, Lucy                  90015789    1 4  50C 1:49.33                                                                        F             N03
E08        A  UELX  X 2007601 UNOV  011022025 2:00.27S                   1:56.86S     1 4     6                                                1N13005  X    N25
F08              UELXAWhetton, Isla P             90011951       0328200916F  1             90011951                                                         N36
G08            Whetton, Isla P             90011951    1 4  50C   31.50                                                                        F             N24
F08              UELXALothian, Lewis              90006334       0330200916M  2             90006334                                                         N46
G08            Lothian, Lewis              90006334    1 4  50C 1:02.82                                                                        F             N64
F08              UELXATaylor, Alex                1293402        0703200817M  3             1293402                                                          N45
G08            Taylor, Alex                1293402     1 4  50C 1:29.05                                                                        F             N73
F08              UELXALawson, Anna                90019303       0916200916F  4             90019303                                                         N55
G08            Lawson, Anna                90019303    1 4  50C 1:56.86                                                                        F             N83
E08        B  UELX  X 2007601 UNOV  011022025 2:00.80S                   2:04.04S     1 5    10                                                2N13005  X    N15
F08              UELXBMcLean, Jonathan            90007361       0619200916M  1             90007361                                                         N86
G08            McLean, Jonathan            90007361    1 4  50C   31.11                                                                        F             N74
F08              UELXBBrown, Findlay              1277449        0603200718M  2             1277449                                                          N36
G08            Brown, Findlay              1277449     1 4  50C 1:03.02                                                                        F             N54
F08              UELXBHall, Lucy                  90015789       0622200916F  3             90015789                                                         N94
G08            Hall, Lucy                  90015789    1 4  50C 1:35.09                                                                        F             N03
F08              UELXBNolan, Kate                 90011417       0611200916F  4             90011417                                                         N05
G08            Nolan, Kate                 90011417    1 4  50C 2:04.04                                                                        F             N23
C18          EEUXEdinburgh University          Edinburgh Un    46 Pleasance          Edinburgh             Edinburgh             EH8 9TJ                     N41
D08        Harris, Chloe               954462      A   0514200520FF  502104 UNOV11012025   29.75S   30.32S            29.92S 3 5 2 8  8  6  5.   6950200    NN20
D3954462        Chloe                                                                                                                                        N00
D08        Harris, Chloe               954462      A   0514200520FF 1004110 UNOV11012025 1:01.43S 1:03.64S          1:01.93S 2 4 2 3  3  3  8.   3950400    NN80
G08            Harris, Chloe               954462      1 2  50C   29.70 1:03.64                                                                P             N54
G08            Harris, Chloe               954462      1 2  50C   29.11 1:01.93                                                                F             N44
D08        Harris, Chloe               954462      A   0514200520FF  501112 UNOV11012025   27.94S   27.37S            26.89S 6 0 2 8  8  6  5.   6950100    NN20
D08        Harris, Chloe               954462      A   0514200520FF 1001409 UNOV11022025 1:01.43S   57.84S            56.65S 1 3 2 5  2  2  9.   2950100    NN40
G08            Harris, Chloe               954462      1 2  50C   27.65   57.84                                                                P             N34
G08            Harris, Chloe               954462      1 2  50C   27.54   56.65                                                                F             N24
D08        Harris, Chloe               954462      A   0514200520FF  504411 UNOV11022025   27.94S   28.43S            28.19S 6 5 2 6  4  4  7.   4950400    NN20
D08        Peebles, Calum              1190530     A   0521200619MM  503103 UNOV11012025   31.10S   31.62S                   6 1 0 0 21           9503      NN29
D31190530       Calum                                                                                                                                        N10
D08        Peebles, Calum              1190530     A   0521200619MM 1002107 UNOV11012025   56.11S   57.87S            57.07S 2 4 2 6  4  3  8.   3950200    NN70
G08            Peebles, Calum              1190530     1 2  50C   28.29   57.87                                                                P             N74
G08            Peebles, Calum              1190530     1 2  50C   27.46   57.07                                                                F             N64
D08        Peebles, Calum              1190530     A   0521200619MM  502404 UNOV11022025   26.46S   26.77S            27.02S 6 3 2 1  7  8  3.   8950200    NN60
D08        Peebles, Calum              1190530     A   0521200619MM 2002414 UNOV11022025 2:05.58S 2:07.86S          2:05.96S 4 5 1 2  5  4  7.   4950200    NN41
G08            Peebles, Calum              1190530     1 4  50C   29.53 1:03.11 1:35.27 2:07.86                                                P             N36
G08            Peebles, Calum              1190530     1 4  50C   28.84 1:00.08 1:32.55 2:05.96                                                F             N26
D08        Wood, Isabelle              1077980     A   0624200520FF 2001102 UNOV11012025 2:02.60S 2:10.56S          2:10.45S 4 4 1 9 10 10  1.   0950100    NN31
D31077980       Isabelle                                                                                                                                     N21
G08            Wood, Isabelle              1077980     1 4  50C   29.75 1:02.33 1:36.27 2:10.56                                                P             N46
G08            Wood, Isabelle              1077980     1 4  50C   29.64 1:02.84 1:36.35 2:10.45                                                F             N36
D08        Wood, Isabelle              1077980     A   0624200520FF  501112 UNOV11012025   27.33S   28.74S                   7 7 0 0 27           9501      NN49
D08        Yuda, Faith                 1309555     A   1125200421FF  502104 UNOV11012025   29.02S   29.63S            29.12S 5 5 2 6  4  4  7.   4950200    NN49
D31309555       Faith                                                                                                                                        N10
D08        Yuda, Faith                 1309555     A   1125200421FF 1004110 UNOV11012025 1:02.12S 1:03.01S          1:01.30S 4 5 2 5  2  2  9.   2950400    NN99
G08            Yuda, Faith                 1309555     1 2  50C   29.64 1:03.01                                                                P             N73
G08            Yuda, Faith                 1309555     1 2  50C   29.09 1:01.30                                                                F             N73
D08        Yuda, Faith                 1309555     A   1125200421FF 1001409 UNOV11022025   59.35S   58.86S                   3 2 0 0  7           9501      NN28
G08            Yuda, Faith                 1309555     1 2  50C   28.11   58.86                                                                P             N63
D08        Yuda, Faith                 1309555     A   1125200421FF  504411 UNOV11022025   27.46S   27.67S            27.36S 6 4 2 5  2  2  9.   2950400    NN59
C18          NENXElgin Asc                     Elgin                                                                                       GBR               N83
D08        Brown, Rowan                1290464     A   0917200718MM 1002107 UNOV11012025 1:02.06S 1:03.30S                   4 2 0 0 17           9502      NN39
D31290464                                                                                                                                                    N38
G08            Brown, Rowan                1290464     1 2  50C   29.73 1:03.30                                                                P             N34
D08        Brown, Rowan                1290464     A   0917200718MM 1001109 UNOV11012025   55.67S 1:00.73S                   1 3 0 0 58           9501      NN29
G08            Brown, Rowan                1290464     1 2  50C   27.88 1:00.73                                                                P             N44
D08        Brown, Rowan                1290464     A   0917200718MM  504111 UNOV11012025   25.11S   27.15S                   3 3 0 0 18           9504      NN88
D08        Brown, Rowan                1290464     A   0917200718MM  502404 UNOV11022025   28.12S   28.48S                   5 2 0 0 19           9502      NN98
D08        Brown, Rowan                1290464     A   0917200718MM 1004410 UNOV11022025 1:02.12S 1:06.08S                   3 9 0 0 41           9504      NN39
G08            Brown, Rowan                1290464     1 2  50C   30.30 1:06.08                                                                P             N34
D08        Brown, Rowan                1290464     A   0917200718MM  501412 UNOV11022025   24.88S   26.01S                   4 1 0 0 35           9501      NN98
D08        Clarke, Oliver              90033165    A   0619201015MM 1003528 UNOV11022025 1:20.67S 1:14.47S                   4 9      7           9503      NN99
D390033165                                                                                                                                                   N48
G08            Clarke, Oliver              90033165    1 2  50C   34.53 1:14.47                                                                P             N05
D08        Clarke, Oliver              90033165    A   0619201015MM 2003113 UNOV11012025 2:47.61S 2:48.23S                   7 3 0 0 48           9503      NN10
G08            Clarke, Oliver              90033165    1 4  50C   36.42 1:18.80 2:04.17 2:48.23                                                P             N56
D08        Clarke, Oliver              90033165    A   0619201015MM  503103 UNOV11012025   33.79S   33.84S                   3 0 0 0 45           9503      NN59
D08        Clarke, Oliver              90033165    A   0619201015MM 1003408 UNOV11022025 1:20.67S 1:14.47S                   8 9 0 0 40           9503      NN10
G08            Clarke, Oliver              90033165    1 2  50C   34.53 1:14.47                                                                P             N05
D08        Mitchell, Abbi              90037738    A   0416200916FF  502104 UNOV11012025   32.25S   32.83S                   3 8 0 0 28           9502      NN39
D390037738                                                                                                                                                   N58
D08        Mitchell, Abbi              90037738    A   0416200916FF 2005106 UNOV11012025 2:32.92S 2:32.08S                   2 8 0 0 17           9505      NN99
G08            Mitchell, Abbi              90037738    1 4  50C   33.18 1:12.33 1:55.93 2:32.08                                                P             N36
D08        Mitchell, Abbi              90037738    A   0416200916FF 1003108 UNOV11012025 1:17.41S 1:17.57S          1:16.48S 3 7 1 4 11 12       29503      NN21
G08            Mitchell, Abbi              90037738    1 2  50C   38.36 1:17.57                                                                P             N05
G08            Mitchell, Abbi              90037738    1 2  50C   35.97 1:16.48                                                                F             N94
D08        Mitchell, Abbi              90037738    A   0416200916FF  503403 UNOV11022025   34.66S   34.96S            35.11S 5 2 2 0  9 10  1.   0950300    NN70
D08        Mitchell, Abbi              90037738    A   0416200916FF  504411 UNOV11022025   31.00S   31.45S                   3 7 0 0 32           9504      NN39
D08        Mitchell, Abbi              90037738    A   0416200916FF 2003413 UNOV11022025 2:46.33S 2:44.93S          2:46.41S 3 2 1 9 11 10  1.   0950300    NN51
G08            Mitchell, Abbi              90037738    1 4  50C   39.24 1:22.42 2:03.49 2:44.93                                                P             N46
G08            Mitchell, Abbi              90037738    1 4  50C   38.54 1:21.00 2:04.05 2:46.41                                                F             N26
D08        Mitchell, Abbi              90037738    A   0416200916FF 4005501 UNOV11022025 5:30.04S                   5:22.44S     3 7    13       19505      NN89
G08            Mitchell, Abbi              90037738    1 8  50C   35.57 1:18.46 2:00.26 2:40.73 3:25.95 4:10.24 4:47.79 5:22.44                F             N39
D08        Mitchell, Abbi              90037738    A   0416200916FF  502104SUNOV11012025   32.83S            32.52S              1 4     2       2  02      NN19
D08        Powell, Grace               90001636    A   0506200916FF 2001102 UNOV11012025 2:20.66S 2:23.88S                   5 6 0 0 49           9501      NN69
D390001636                                                                                                                                                   N48
G08            Powell, Grace               90001636    1 4  50C   33.70 1:10.40 1:48.37 2:23.88                                                P             N16
D08        Powell, Grace               90001636    A   0506200916FF 8001202 UNOV11012025 9:55.26S                  10:03.66S     2 8    22       99501      NN79
G08            Powell, Grace               90001636    116  50C   33.92 1:10.46 1:48.20 2:26.35 3:04.90 3:43.08 4:21.30 4:59.64 5:37.91 6:16.39F             N50
G08            Powell, Grace               90001636    216  50C 6:54.88 7:33.04 8:10.94 8:49.38 9:27.9210:03.66                                F             N18
D08        Powell, Grace               90001636    A   0506200916FF 4001401 UNOV11022025 4:52.51S 4:59.29S                   2 2 0 0 29           9501      NN69
G08            Powell, Grace               90001636    1 8  50C   34.24 1:11.08 1:48.93 2:27.33 3:05.20 3:43.61 4:22.28 4:59.29                P             N09
D08        Powell, Grace               90001636    A   0506200916FF 4005501 UNOV11022025 5:37.31S                   5:47.98S     2 3    35       09505      NN69
G08            Powell, Grace               90001636    1 8  50C   36.59 1:19.31 2:05.10 2:49.63 3:38.90 4:30.08 5:10.17 5:47.98                F             N09
D08        Powell, Grace               90001636    A   0506200916FF 2005106 UNOV11012025 2:40.16S 2:44.44S                   6 4 0 0 48           9505      NN69
G08            Powell, Grace               90001636    1 4  50C   35.26 1:18.45 2:05.67 2:44.44                                                P             N16
D08        Powell, Jessica             1200434     A   0508200718FF 2005106 UNOV11012025 2:33.50S 2:41.16S                   3 0 0 0 39           9505      NN30
D31200434                                                                                                                                                    N38
G08            Powell, Jessica             1200434     1 4  50C   35.57 1:15.85 2:02.44 2:41.16                                                P             N86
D08        Powell, Jessica             1200434     A   0508200718FF 1003108 UNOV11012025 1:21.01S 1:24.57S                   3 0 0 0 42           9503      NN20
G08            Powell, Jessica             1200434     1 2  50C   40.75 1:24.57                                                                P             N35
D08        Powell, Jessica             1200434     A   0508200718FF 8001202 UNOV11012025 9:41.67S                  10:27.52S     2 4    25       09501      NN30
G08            Powell, Jessica             1200434     116  50C   33.60 1:10.95 1:48.80 2:26.95 3:05.71 3:45.33 4:24.94 5:05.03 5:45.14 6:25.36F             N21
G08            Powell, Jessica             1200434     216  50C 7:05.62 7:45.98 8:26.54 9:07.43 9:48.0410:27.52                                F             N88
D08        Powell, Jessica             1200434     A   0508200718FF 4001401 UNOV11022025 4:47.15S 5:01.16S                   3 9 0 0 30           9501      NN30
G08            Powell, Jessica             1200434     1 8  50C   33.76 1:10.47 1:47.76 2:25.61 3:03.83 3:42.86 4:22.15 5:01.16                P             N79
D08        Powell, Jessica             1200434     A   0508200718FF 2003413 UNOV11022025 2:50.65S 2:58.45S                   3 1 0 0 34           9503      NN30
G08            Powell, Jessica             1200434     1 4  50C   40.35 1:24.94 2:11.58 2:58.45                                                P             N86
D08        Powell, Jessica             1200434     A   0508200718FF 4005501 UNOV11022025 5:24.02S                   5:39.95S     4 1    30       79505      NN30
G08            Powell, Jessica             1200434     1 8  50C   35.72 1:19.09 2:02.66 2:45.34 3:32.79 4:20.36 5:00.73 5:39.95                F             N79
D08        Ross, Euan                  90019546    A   0723201015MM 4001101 UNOV11012025 5:02.42S 4:59.58S                   6 1 0 0 48           9501      NN78
D390019546                                                                                                                                                   N58
G08            Ross, Euan                  90019546    1 8  50C   31.45 1:07.36 1:45.40 2:24.08 3:03.06 3:41.60 4:20.79 4:59.58                P             N08
D08        Ross, Euan                  90019546    A   0723201015MM 1003528 UNOV11022025 1:19.75S 1:21.44S                   3 1     34           9503      NN58
G08            Ross, Euan                  90019546    1 2  50C   37.30 1:21.44                                                                P             N63
D08        Ross, Euan                  90019546    A   0723201015MM 2003113 UNOV11012025 2:48.97S 3:03.28S                   6 6 0 0 66           9503      NN78
G08            Ross, Euan                  90019546    1 4  50C   39.80 1:28.14 2:16.57 3:03.28                                                P             N15
D08        Ross, Euan                  90019546    A   0723201015MM 1003408 UNOV11022025 1:19.75S 1:21.44S                   7 1 0 0 70           9503      NN78
G08            Ross, Euan                  90019546    1 2  50C   37.30 1:21.44                                                                P             N63
E08        A  NENX  X 2006301 UNOV  011012025 1:51.06S                   1:55.60S     1 7    17                                                7N13001  X    N25
F08              NENXARoss, Euan                  90019546       0723201015M  1             90019546                                                         N94
G08            Ross, Euan                  90019546    1 4  50C   28.20                                                                        F             N92
F08              NENXAMitchell, Abbi              90037738       0416200916F  2             90037738                                                         N26
G08            Mitchell, Abbi              90037738    1 4  50C   58.39                                                                        F             N24
F08              NENXAPowell, Jessica             1200434        0508200718F  3             1200434                                                          N46
G08            Powell, Jessica             1200434     1 4  50C 1:29.14                                                                        F             N84
F08              NENXABrown, Rowan                1290464        0917200718M  4             1290464                                                          N65
G08            Brown, Rowan                1290464     1 4  50C 1:55.60                                                                        F             N83
C18          EFSXFins Csc                      Fins                                                                                        GBR               N23
D08        Mackay, Kristin             1199699     A   1114200817FF 8001202 UNOV11012025 9:34.28S                   9:31.37S     3 2     4  7.   4950100    NN70
D31199699                                                                                                                                                    N48
G08            Mackay, Kristin             1199699     116  50C   31.44 1:06.06 1:41.84 2:17.88 2:53.89 3:29.84 4:06.03 4:42.02 5:18.40 5:54.64F             N41
G08            Mackay, Kristin             1199699     216  50C 6:30.90 7:07.04 7:43.42 8:19.69 8:55.70 9:31.37                                F             N98
D08        Mackay, Kristin             1199699     A   1114200817FF 4005501 UNOV11022025 5:17.88S                   5:18.70S     5 9     8  3.   8950500    NN80
G08            Mackay, Kristin             1199699     1 8  50C   33.80 1:14.46 1:55.07 2:35.32 3:20.56 4:06.67 4:43.21 5:18.70                F             N89
C18SS      SSMFRXForfar Swimming Club          Forfar          Forfar Community Campu                      Forfar              ANDD8 3TG                     N99
D08SS      Wood, Ella                  1309766     AGBR0328200718FF 1004110 UNOV11012025 1:06.72S      NSS                   4 1 0 0  0           9504      NN29
D31309766                                                                                                                                                    N48
G08SS          Wood, Ella                  1309766     1 2  50C                                                                                P             N72
D08SS      Wood, Ella                  1309766     AGBR0328200718FF  501112 UNOV11012025   29.91S      NSS                   1 5 0 0  0           9501      NN98
D08SS      Wood, Ella                  1309766     AGBR0328200718FF  503403 UNOV11022025   34.71S      NSS                   7 7 0 0  0           9503      NN09
D08SS      Wood, Ella                  1309766     AGBR0328200718FF  504411 UNOV11022025   30.20S      NSS                   4 5 0 0  0           9504      NN98
C18          NGHXGarioch Amateur Swimming Club Garioch         Murray Gow            27 Dirdhu Court       Nethy Bridge          PH25 3EG  GBR               N34
D08        Denny, Ellen                90009970    A   0411200817FF 1001529 UNOV11022025 1:02.70S 1:01.25S                   4 3      1           9501      NN98
D390009970                                                                                                                                                   N58
G08            Denny, Ellen                90009970    1 2  50C   29.62 1:01.25                                                                P             N34
D08        Denny, Ellen                90009970    A   0411200817FF 2001102 UNOV11012025 2:14.25S 2:18.07S                   3 0 0 0 33           9501      NN19
G08            Denny, Ellen                90009970    1 4  50C   31.93 1:07.43 1:43.34 2:18.07                                                P             N75
D08        Denny, Ellen                90009970    A   0411200817FF  502104 UNOV11012025   32.88S   34.40S                   5 9 0 0 36           9502      NN78
D08        Denny, Ellen                90009970    A   0411200817FF 2005106 UNOV11012025 2:26.71S 2:34.10S                   4 2 0 0 22           9505      NN29
G08            Denny, Ellen                90009970    1 4  50C   33.02 1:12.11 1:58.15 2:34.10                                                P             N65
D08        Denny, Ellen                90009970    A   0411200817FF 1003108 UNOV11012025 1:18.94S 1:22.97S                   3 8 0 0 34           9503      NN39
G08            Denny, Ellen                90009970    1 2  50C   39.91 1:22.97                                                                P             N44
D08        Denny, Ellen                90009970    A   0411200817FF 1004110 UNOV11012025 1:05.30S 1:08.78S                   4 2 0 0 17           9504      NN29
G08            Denny, Ellen                90009970    1 2  50C   31.83 1:08.78                                                                P             N34
D08        Denny, Ellen                90009970    A   0411200817FF  501112 UNOV11012025   28.30S   29.53S                   5 4 0 0 44           9501      NN78
D08        Denny, Ellen                90009970    A   0411200817FF 2002114 UNOV11012025 2:31.21S 2:36.18S                   3 1 0 0 24           9502      NN29
G08            Denny, Ellen                90009970    1 4  50C   36.91 1:16.11 1:56.09 2:36.18                                                P             N85
D08        Denny, Ellen                90009970    A   0411200817FF 8001202 UNOV11012025 9:59.30S                   9:58.93S     2 9    19       89501      NN39
G08            Denny, Ellen                90009970    116  50C   32.83 1:09.55 1:47.10 2:25.01 3:03.21 3:41.72 4:19.99 4:58.41 5:36.98 6:15.22F             N20
G08            Denny, Ellen                90009970    216  50C 6:52.89 7:30.49 8:08.11 8:45.46 9:23.03 9:58.93                                F             N77
D08        Denny, Ellen                90009970    A   0411200817FF 4001401 UNOV11022025 4:48.50S 4:46.52S                   2 5 0 0 13           9501      NN29
G08            Denny, Ellen                90009970    1 8  50C   31.77 1:07.36 1:43.72 2:20.44 2:57.12 3:33.79 4:10.44 4:46.52                P             N78
D08        Denny, Ellen                90009970    A   0411200817FF  503403 UNOV11022025   36.98S   38.67S                   4 3 0 0 46           9503      NN88
D08        Denny, Ellen                90009970    A   0411200817FF 2004405 UNOV11022025 2:24.16S 2:27.71S          2:24.94S 4 5 1 7  6  6  5.   6950400    NN80
G08            Denny, Ellen                90009970    1 4  50C   32.10 1:09.17 1:47.80 2:27.71                                                P             N75
G08            Denny, Ellen                90009970    1 4  50C   31.95 1:08.62 1:47.03 2:24.94                                                F             N75
D08        Denny, Ellen                90009970    A   0411200817FF 1002407 UNOV11022025 1:11.00S 1:14.71S                   3 0 0 0 38           9502      NN19
G08            Denny, Ellen                90009970    1 2  50C   36.42 1:14.71                                                                P             N34
D08        Denny, Ellen                90009970    A   0411200817FF  504411 UNOV11022025   29.30S   31.12S                   6 7 0 0 25           9504      NN78
D08        Denny, Ellen                90009970    A   0411200817FF 2003413 UNOV11022025 2:49.89S 2:57.46S                   3 7 0 0 32           9503      NN49
G08            Denny, Ellen                90009970    1 4  50C   41.19 1:25.15 2:11.01 2:57.46                                                P             N75
D08        Denny, Ellen                90009970    A   0411200817FF 4005501 UNOV11022025 5:10.33S                   5:16.93S     5 7     6  5.   6950500    NN59
G08            Denny, Ellen                90009970    1 8  50C   32.78 1:11.25 1:52.19 2:33.19 3:19.45 4:05.93 4:42.21 5:16.93                F             N78
D08        Denny, Ellen                90009970    A   0411200817FF 1001409 UNOV11022025 1:02.70S 1:01.25S                   8 3 0 0 22           9501      NN29
G08            Denny, Ellen                90009970    1 2  50C   29.62 1:01.25                                                                P             N34
D08        Gow, Innes                  1291399     A   0227200817MM 4001101 UNOV11012025 4:20.30S 4:22.16S                   3 0 0 0 15           9501      NN48
D31291399                                                                                                                                                    N48
G08            Gow, Innes                  1291399     1 8  50C   29.65 1:02.11 1:35.31 2:08.65 2:42.10 3:15.68 3:49.18 4:22.16                P             N97
D08        Gow, Innes                  1291399     A   0227200817MM  503103 UNOV11012025   34.10S   33.62S                   2 4 0 0 42           9503      NN97
D08        Gow, Innes                  1291399     A   0227200817MM 2004105 UNOV11012025 2:14.40S 2:18.53S          2:17.50S 3 3 1 9 11 10  1.   0950400    NN10
G08            Gow, Innes                  1291399     1 4  50C   30.76 1:05.64 1:42.57 2:18.53                                                P             N05
G08            Gow, Innes                  1291399     1 4  50C   31.89 1:06.46 1:42.49 2:17.50                                                F             N05
D08        Gow, Innes                  1291399     A   0227200817MM  504111 UNOV11012025   28.80S   29.97S                   1 8 0 0 43           9504      NN18
D08        Gow, Innes                  1291399     A   0227200817MM 2003113 UNOV11012025 2:40.25S 2:40.83S                   2 9 0 0 31           9503      NN58
G08            Gow, Innes                  1291399     1 4  50C   35.69 1:16.49 1:59.59 2:40.83                                                P             N15
D08        Gow, Innes                  1291399     A   0227200817MM 4005201 UNOV11012025 4:42.29S                   4:53.66S     5 7    17       09505      NN68
G08            Gow, Innes                  1291399     1 8  50C   31.06 1:06.97 1:46.14 2:24.13 3:06.08 3:48.81 4:21.80 4:53.66                F             N97
D08        Gow, Innes                  1291399     A   0227200817MM 2001402 UNOV11022025 2:02.81S 2:06.83S                   2 0 0 0 42           9501      NN58
G08            Gow, Innes                  1291399     1 4  50C   29.97 1:02.00 1:34.60 2:06.83                                                P             N05
D08        Gow, Innes                  1291399     A   0227200817MM  502404 UNOV11022025   31.37S   31.13S                   1 4 0 0 47           9502      NN08
D08        Gow, Innes                  1291399     A   0227200817MM 2005406 UNOV11022025 2:18.80S 2:18.81S                   3 1 0 0 18           9505      NN68
G08            Gow, Innes                  1291399     1 4  50C   30.55 1:06.85 1:47.03 2:18.81                                                P             N05
D08        Gow, Innes                  1291399     A   0227200817MM 1003408 UNOV11022025 1:14.10S 1:13.19S                   1 1 0 0 31           9503      NN58
G08            Gow, Innes                  1291399     1 2  50C   34.62 1:13.19                                                                P             N53
D08        Gow, Innes                  1291399     A   0227200817MM 2002414 UNOV11022025 2:20.04S 2:20.70S                   3 1 0 0 22           9502      NN48
G08            Gow, Innes                  1291399     1 4  50C   33.65 1:08.95 1:45.95 2:20.70                                                P             N05
D08        Gow, Innes                  1291399     A   0227200817MM 8001502 UNOV11022025 8:46.17S                   8:43.40S     3 2     5  6.   4950100    NN88
G08            Gow, Innes                  1291399     116  50C   29.20 1:01.83 1:34.78 2:07.77 2:41.42 3:14.57 3:47.58 4:21.04 4:54.26 5:27.31F             N49
G08            Gow, Innes                  1291399     216  50C 6:00.31 6:33.72 7:06.83 7:40.49 8:12.79 8:43.40                                F             N86
D08        Gow, Innes                  1291399     A   0227200817MM 1002107 UNOV11012025 1:07.08S 1:08.12S                   6 5 0 0 48           9502      NN58
G08            Gow, Innes                  1291399     1 2  50C   33.45 1:08.12                                                                P             N53
D08        Hay, Jamie                  90013989    A   1014200817MM 2003113 UNOV11012025 2:45.54S 2:42.49S                   8 5 0 0 36           9503      NN58
D390013989                                                                                                                                                   N58
G08            Hay, Jamie                  90013989    1 4  50C   37.76 1:19.12 2:01.07 2:42.49                                                P             N94
D08        Hay, Jamie                  90013989    A   1014200817MM 4001101 UNOV11012025 4:34.43S 4:38.17S                   1 3 0 0 32           9501      NN48
G08            Hay, Jamie                  90013989    1 8  50C   29.76 1:02.91 1:37.43 2:12.91 2:48.94 3:25.19 4:01.91 4:38.17                P             N97
D08        Hay, Jamie                  90013989    A   1014200817MM 2004105 UNOV11012025 2:14.40S 2:23.99S                   2 3 0 0 20           9504      NN48
G08            Hay, Jamie                  90013989    1 4  50C   31.08 1:06.96 1:45.25 2:23.99                                                P             N05
D08        Hay, Jamie                  90013989    A   1014200817MM  504111 UNOV11012025   28.30S   29.19S                   1 4 0 0 41           9504      NN97
D08        Hay, Jamie                  90013989    A   1014200817MM 4005201 UNOV11012025 4:59.37S                   5:03.98S     4 9    27       89505      NN68
G08            Hay, Jamie                  90013989    1 8  50C   31.28 1:07.83 1:48.11 2:26.17 3:09.73 3:53.95 4:29.36 5:03.98                F             N97
D08        Hay, Jamie                  90013989    A   1014200817MM  502404 UNOV11022025   29.00S   29.20S                   5 8 0 0 25           9502      NN97
D08        Hay, Jamie                  90013989    A   1014200817MM 2005406 UNOV11022025 2:22.08S 2:23.18S                   1 3 0 0 37           9505      NN58
G08            Hay, Jamie                  90013989    1 4  50C   30.59 1:07.64 1:50.29 2:23.18                                                P             N94
D08        Hay, Jamie                  90013989    A   1014200817MM 1004410 UNOV11022025 1:00.30S 1:03.91S                   3 1 0 0 35           9504      NN48
G08            Hay, Jamie                  90013989    1 2  50C   29.33 1:03.91                                                                P             N43
D08        Hay, Jamie                  90013989    A   1014200817MM 2002414 UNOV11022025 2:25.28S 2:21.19S                   1 3 0 0 23           9502      NN48
G08            Hay, Jamie                  90013989    1 4  50C   32.80 1:09.10 1:45.25 2:21.19                                                P             N84
D08        Hay, Jamie                  90013989    A   1014200817MM 8001502 UNOV11022025 9:27.59S                   9:38.44S     2 9    20       09501      NN58
G08            Hay, Jamie                  90013989    116  50C   32.52 1:07.55 1:43.49 2:19.91 2:56.07 3:33.02 4:09.76 4:46.90 5:24.09 6:00.82F             N49
G08            Hay, Jamie                  90013989    216  50C 6:37.92 7:14.99 7:51.67 8:27.82 9:03.77 9:38.44                                F             N07
D08        Hay, Jamie                  90013989    A   1014200817MM 1002107 UNOV11012025 1:06.60S 1:03.71S                   8 4 0 0 20           9502      NN48
G08            Hay, Jamie                  90013989    1 2  50C   30.40 1:03.71                                                                P             N43
D08        Kelly, Max                  90024760    A   0423201015MM 1003528 UNOV11022025 1:17.44S 1:20.87S                   4 2     29           9503      NN48
D390024760                                                                                                                                                   N48
G08            Kelly, Max                  90024760    1 2  50C   37.67 1:20.87                                                                P             N63
D08        Kelly, Max                  90024760    A   0423201015MM 1004530 UNOV11022025 1:07.56S 1:08.76S                   2 7      9           9504      NN38
G08            Kelly, Max                  90024760    1 2  50C   31.72 1:08.76                                                                P             N63
D08        Kelly, Max                  90024760    A   0423201015MM 2003113 UNOV11012025 2:51.80S 2:52.58S                   6 8 0 0 56           9503      NN68
G08            Kelly, Max                  90024760    1 4  50C   39.32 1:24.22 2:09.23 2:52.58                                                P             N05
D08        Kelly, Max                  90024760    A   0423201015MM 2004105 UNOV11012025 2:53.87S 2:30.28S                   5 2 0 0 28           9504      NN68
G08            Kelly, Max                  90024760    1 4  50C   32.05 1:09.12 1:49.30 2:30.28                                                P             N94
D08        Kelly, Max                  90024760    A   0423201015MM 2001522 UNOV11022025 2:13.92S 2:15.66S                   1 7     17           9501      NN48
G08            Kelly, Max                  90024760    1 4  50C   30.40 1:04.54 1:40.16 2:15.66                                                P             N94
D08        Kelly, Max                  90024760    A   0423201015MM  503103 UNOV11012025   34.74S   36.19S                   2 1 0 0 62           9503      NN08
D08        Kelly, Max                  90024760    A   0423201015MM 1002107 UNOV11012025 1:06.41S 1:06.73S                   1 8 0 0 38           9502      NN58
G08            Kelly, Max                  90024760    1 2  50C   32.33 1:06.73                                                                P             N53
D08        Kelly, Max                  90024760    A   0423201015MM 4001101 UNOV11012025 4:49.95S 4:47.26S                   5 4 0 0 39           9501      NN68
G08            Kelly, Max                  90024760    1 8  50C   33.15 1:10.62 1:47.42 2:24.54 3:00.87 3:36.26 4:11.61 4:47.26                P             N97
D08        Kelly, Max                  90024760    A   0423201015MM 2005526 UNOV11022025 2:25.70S 2:29.45S                   1 5     18           9505      NN48
G08            Kelly, Max                  90024760    1 4  50C   31.75 1:09.53 1:55.03 2:29.45                                                P             N05
D08        Kelly, Max                  90024760    A   0423201015MM 4005201 UNOV11012025 5:19.40S                   5:19.70S     2 9    39       89505      NN68
G08            Kelly, Max                  90024760    1 8  50C   32.57 1:11.55 1:52.42 2:33.13 3:20.32 4:08.25 4:44.12 5:19.70                F             N87
D08        Kelly, Max                  90024760    A   0423201015MM  502404 UNOV11022025   30.26S   30.35S                   3 8 0 0 38           9502      NN08
D08        Kelly, Max                  90024760    A   0423201015MM 2002414 UNOV11022025 2:23.75S 2:25.12S                   2 9 0 0 34           9502      NN58
G08            Kelly, Max                  90024760    1 4  50C   32.90 1:10.26 1:48.52 2:25.12                                                P             N05
D08        Kelly, Max                  90024760    A   0423201015MM 8001502 UNOV11022025 9:59.30S                   9:59.08S     1 7    22       49501      NN68
G08            Kelly, Max                  90024760    116  50C   32.89 1:09.53 1:47.38 2:25.85 3:04.34 3:42.48 4:21.03 4:59.85 5:38.59 6:17.52F             N69
G08            Kelly, Max                  90024760    216  50C 6:55.81 7:33.12 8:11.17 8:46.69 9:24.60 9:59.08                                F             N07
D08        Kelly, Max                  90024760    A   0423201015MM 2001402 UNOV11022025 2:13.92S 2:15.66S                   5 7 0 0 55           9501      NN68
G08            Kelly, Max                  90024760    1 4  50C   30.40 1:04.54 1:40.16 2:15.66                                                P             N94
D08        Kelly, Max                  90024760    A   0423201015MM 2005406 UNOV11022025 2:25.70S 2:29.45S                   5 5 0 0 56           9505      NN68
G08            Kelly, Max                  90024760    1 4  50C   31.75 1:09.53 1:55.03 2:29.45                                                P             N05
D08        Kelly, Max                  90024760    A   0423201015MM 1003408 UNOV11022025 1:17.44S 1:20.87S                   8 2 0 0 65           9503      NN68
G08            Kelly, Max                  90024760    1 2  50C   37.67 1:20.87                                                                P             N63
D08        Kelly, Max                  90024760    A   0423201015MM 1004410 UNOV11022025 1:07.56S 1:08.76S                   6 7 0 0 46           9504      NN68
G08            Kelly, Max                  90024760    1 2  50C   31.72 1:08.76                                                                P             N63
D08        Macpherson, Austin          90022368    A   0102201015MM 1004530 UNOV11022025 1:09.68S 1:12.35S                   2 0     15           9504      NN51
D390022368                                                                                                                                                   N48
G08            Macpherson, Austin          90022368    1 2  50C   32.77 1:12.35                                                                P             N76
D08        Macpherson, Austin          90022368    A   0102201015MM 1003528 UNOV11022025 1:14.50S 1:15.27S                   3 4     10           9503      NN51
G08            Macpherson, Austin          90022368    1 2  50C   34.95 1:15.27                                                                P             N86
D08        Macpherson, Austin          90022368    A   0102201015MM 4001101 UNOV11012025 4:17.00S 4:18.69S                   4 7 0 0 12           9501      NN71
G08            Macpherson, Austin          90022368    1 8  50C   28.95 1:01.17 1:34.69 2:08.42 2:40.91 3:13.66 3:46.26 4:18.69                P             N21
D08        Macpherson, Austin          90022368    A   0102201015MM  503103 UNOV11012025   32.90S   33.45S                   3 5 0 0 40           9503      NN11
D08        Macpherson, Austin          90022368    A   0102201015MM 2004105 UNOV11012025 2:34.52S 2:36.70S                   1 3 0 0 37           9504      NN71
G08            Macpherson, Austin          90022368    1 4  50C   32.24 1:12.72 1:56.04 2:36.70                                                P             N28
D08        Macpherson, Austin          90022368    A   0102201015MM 1002107 UNOV11012025 1:02.00S 1:05.14S                   2 6 0 0 28           9502      NN61
G08            Macpherson, Austin          90022368    1 2  50C   31.24 1:05.14                                                                P             N76
D08        Macpherson, Austin          90022368    A   0102201015MM 1001109 UNOV11012025   54.00S   56.14S                   4 7 0 0 29           9501      NN21
G08            Macpherson, Austin          90022368    1 2  50C   26.78   56.14                                                                P             N66
D08        Macpherson, Austin          90022368    A   0102201015MM 2003113 UNOV11012025 2:34.90S 2:44.29S                   2 1 0 0 43           9503      NN71
G08            Macpherson, Austin          90022368    1 4  50C   35.90 1:18.42 2:00.98 2:44.29                                                P             N28
D08        Macpherson, Austin          90022368    A   0102201015MM 4005201 UNOV11012025 4:55.30S                   4:59.93S     4 6    23       69505      NN71
G08            Macpherson, Austin          90022368    1 8  50C   34.16 1:13.56 1:49.70 2:26.85 3:11.91 3:54.58 4:27.88 4:59.93                F             N31
D08        Macpherson, Austin          90022368    A   0102201015MM 2001402 UNOV11022025 1:58.80S 2:00.02S                   4 7 0 0 15           9501      NN61
G08            Macpherson, Austin          90022368    1 4  50C   27.87   58.67 1:29.39 2:00.02                                                P             N08
D08        Macpherson, Austin          90022368    A   0102201015MM  502404 UNOV11022025   29.66S   29.68S            29.37S 3 5 1 8 28 18       89502      NN42
D08        Macpherson, Austin          90022368    A   0102201015MM 2005406 UNOV11022025 2:16.40S 2:21.93S                   3 2 0 0 30           9505      NN71
G08            Macpherson, Austin          90022368    1 4  50C   31.46 1:05.74 1:49.39 2:21.93                                                P             N28
D08        Macpherson, Austin          90022368    A   0102201015MM  501412 UNOV11022025   24.50S   25.92S                   5 7 0 0 31           9501      NN11
D08        Macpherson, Austin          90022368    A   0102201015MM 2002414 UNOV11022025 2:14.70S 2:18.24S                   4 6 0 0 15           9502      NN71
G08            Macpherson, Austin          90022368    1 4  50C   31.99 1:07.53 1:43.53 2:18.24                                                P             N28
D08        Macpherson, Austin          90022368    A   0102201015MM 8001502 UNOV11022025 9:08.10S                   9:07.93S     2 2    12       49501      NN71
G08            Macpherson, Austin          90022368    116  50C   30.40 1:04.58 1:39.17 2:14.56 2:49.67 3:25.07 4:00.71 4:34.14 5:08.85 5:43.25F             N62
G08            Macpherson, Austin          90022368    216  50C 6:18.52 6:53.45 7:26.48 8:01.25 8:36.12 9:07.93                                F             N10
D08        Macpherson, Austin          90022368    A   0102201015MM 1003408 UNOV11022025 1:14.50S 1:15.27S                   7 4 0 0 45           9503      NN71
G08            Macpherson, Austin          90022368    1 2  50C   34.95 1:15.27                                                                P             N86
D08        Macpherson, Austin          90022368    A   0102201015MM 1004410 UNOV11022025 1:09.68S 1:12.35S                   6 0 0 0 52           9504      NN71
G08            Macpherson, Austin          90022368    1 2  50C   32.77 1:12.35                                                                P             N76
D08        McLaughlin, Erin            90003278    A   0413200916FF 1003108 UNOV11012025 1:26.10S 1:30.78S                   5 3 0 0 50           9503      NN50
D390003278                                                                                                                                                   N48
G08            McLaughlin, Erin            90003278    1 2  50C   42.71 1:30.78                                                                P             N65
D08        McLaughlin, Erin            90003278    A   0413200916FF 2003533 UNOV11022025 3:04.97S 3:10.08S                   1 6     13           9503      NN40
G08            McLaughlin, Erin            90003278    1 4  50C   44.10 1:31.78 2:22.36 3:10.08                                                P             N07
D08        McLaughlin, Erin            90003278    A   0413200916FF 2005106 UNOV11012025 2:39.25S 2:40.33S                   1 2 0 0 36           9505      NN60
G08            McLaughlin, Erin            90003278    1 4  50C   34.13 1:15.83 2:03.93 2:40.33                                                P             N07
D08        McLaughlin, Erin            90003278    A   0413200916FF  501112 UNOV11012025   29.00S   30.14S                   4 0 0 0 58           9501      NN00
D08        McLaughlin, Erin            90003278    A   0413200916FF 8001202 UNOV1101202510:21.93S                  10:57.25S     1 1    26       79501      NN70
G08            McLaughlin, Erin            90003278    116  50C   35.13 1:15.04 1:55.48 2:36.86 3:18.27 4:00.45 4:42.18 5:24.16 6:05.83 6:47.42F             N61
G08            McLaughlin, Erin            90003278    216  50C 7:29.96 8:11.79 8:52.91 9:34.5210:16.2910:57.25                                F             N29
D08        McLaughlin, Erin            90003278    A   0413200916FF 4001401 UNOV11022025 5:00.82S 5:02.67S                   1 5 0 0 32           9501      NN50
G08            McLaughlin, Erin            90003278    1 8  50C   33.46 1:10.54 1:48.81 2:27.66 3:07.30 3:47.39 4:26.56 5:02.67                P             N10
D08        McLaughlin, Erin            90003278    A   0413200916FF  503403 UNOV11022025   39.35S   41.72S                   2 0 0 0 59           9503      NN10
D08        McLaughlin, Erin            90003278    A   0413200916FF 2004405 UNOV11022025 2:48.56S 2:54.89S                   3 9 0 0 30           9504      NN70
G08            McLaughlin, Erin            90003278    1 4  50C   37.28 1:21.87 2:08.46 2:54.89                                                P             N27
D08        McLaughlin, Erin            90003278    A   0413200916FF 4005501 UNOV11022025 5:34.50S                   5:44.38S     3 9    32       79505      NN60
G08            McLaughlin, Erin            90003278    1 8  50C   36.73 1:20.80 2:05.04 2:48.15 3:36.30 4:25.80 5:04.86 5:44.38                F             N00
D08        McLaughlin, Erin            90003278    A   0413200916FF 2001102 UNOV11012025 2:21.80S 2:28.72S                   6 2 0 0 51           9501      NN50
G08            McLaughlin, Erin            90003278    1 4  50C   32.75 1:09.29 1:48.61 2:28.72                                                P             N27
D08        McLaughlin, Erin            90003278    A   0413200916FF 1004110 UNOV11012025 1:16.23S 1:23.64S                   7 2 0 0 57           9504      NN60
G08            McLaughlin, Erin            90003278    1 2  50C   39.12 1:23.64                                                                P             N65
D08        McLaughlin, Erin            90003278    A   0413200916FF 2003413 UNOV11022025 3:04.97S 3:10.08S                   5 6 0 0 49           9503      NN60
G08            McLaughlin, Erin            90003278    1 4  50C   44.10 1:31.78 2:22.36 3:10.08                                                P             N07
D08        McLean, Abigail R           90013999    A   0725201015FF 1004110 UNOV11012025 1:13.90S 1:13.11S                   5 3 0 0 37           9504      NN20
D390013999                                                                                                                                                   N58
G08            McLean, Abigail R           90013999    1 2  50C   33.51 1:13.11                                                                P             N35
D08        McLean, Abigail R           90013999    A   0725201015FF 2002114 UNOV11012025 2:42.95S 2:45.36S                   5 7 0 0 44           9502      NN30
G08            McLean, Abigail R           90013999    1 4  50C   37.41 1:18.71 2:02.23 2:45.36                                                P             N86
D08        Mitchell, Lucy              90020607    A   0316201015FF 2005106 UNOV11012025 2:45.40S 2:44.24S                   6 8 0 0 47           9505      NN10
D390020607                                                                                                                                                   N48
G08            Mitchell, Lucy              90020607    1 4  50C   35.59 1:16.73 2:06.19 2:44.24                                                P             N66
D08        Mitchell, Lucy              90020607    A   0316201015FF 4001401 UNOV11022025 5:05.95S 5:02.40S                   1 8 0 0 31           9501      NN00
G08            Mitchell, Lucy              90020607    1 8  50C   33.57 1:10.31 1:47.54 2:26.30 3:05.58 3:44.87 4:24.37 5:02.40                P             N59
D08        Mitchell, Lucy              90020607    A   0316201015FF 2004405 UNOV11022025 2:53.00S 2:50.62S                   1 4 0 0 27           9504      NN00
G08            Mitchell, Lucy              90020607    1 4  50C   37.18 1:21.04 2:07.36 2:50.62                                                P             N56
D08        Mitchell, Lucy              90020607    A   0316201015FF 4005501 UNOV11022025 5:47.53S                   5:44.53S     2 0    33       89505      NN00
G08            Mitchell, Lucy              90020607    1 8  50C   37.21 1:22.47 2:04.87 2:48.01 3:38.14 4:27.38 5:06.65 5:44.53                F             N59
D08        Pritchard, Hayden           90018258    A   0407200718MM  503103 UNOV11012025   31.29S   32.69S                   6 8 0 0 29           9503      NN80
D390018258                                                                                                                                                   N58
D08        Pritchard, Hayden           90018258    A   0407200718MM 1001109 UNOV11012025   55.50S   57.35S                   2 9 0 0 42           9501      NN80
G08            Pritchard, Hayden           90018258    1 2  50C   27.21   57.35                                                                P             N06
D08        Pritchard, Hayden           90018258    A   0407200718MM  504111 UNOV11012025   26.20S   27.44S                   5 1 0 0 23           9504      NN70
D08        Pritchard, Hayden           90018258    A   0407200718MM 1003408 UNOV11022025 1:09.82S 1:17.14S                   4 1 0 0 48           9503      NN31
G08            Pritchard, Hayden           90018258    1 2  50C   35.46 1:17.14                                                                P             N26
D08        Pritchard, Hayden           90018258    A   0407200718MM 1004410 UNOV11022025 1:00.40S 1:02.39S                   2 1 0 0 26           9504      NN11
G08            Pritchard, Hayden           90018258    1 2  50C   28.67 1:02.39                                                                P             N26
D08        Pritchard, Hayden           90018258    A   0407200718MM  501412 UNOV11022025   24.46S   25.20S                   6 7 0 0 17           9501      NN70
D08        Pritchard, Willow R         90033092    A   0419201213FF 2004405 UNOV11022025 2:58.60S 3:00.85S                   1 6 0 0 34           9504      NN61
D390033092                                                                                                                                                   N48
G08            Pritchard, Willow R         90033092    1 4  50C   38.99 1:23.79 2:12.23 3:00.85                                                P             N18
D08        Rae, Katy                   90026777    A   0419201114FF 1001529 UNOV11022025 1:03.68S 1:06.29S                   4 7     31           9501      NN97
D390026777                                                                                                                                                   N58
G08            Rae, Katy                   90026777    1 2  50C   31.06 1:06.29                                                                P             N13
D08        Rae, Katy                   90026777    A   0419201114FF 2001102 UNOV11012025 2:18.60S 2:15.40S                   6 3 0 0 22           9501      NN08
G08            Rae, Katy                   90026777    1 4  50C   31.67 1:06.30 1:40.93 2:15.40                                                P             N64
D08        Rae, Katy                   90026777    A   0419201114FF 2005106 UNOV11012025 2:35.30S 2:37.16S                   2 9 0 0 30           9505      NN18
G08            Rae, Katy                   90026777    1 4  50C   33.25 1:12.80 2:00.39 2:37.16                                                P             N64
D08        Rae, Katy                   90026777    A   0419201114FF 1004110 UNOV11012025 1:08.90S 1:12.13S                   3 9 0 0 33           9504      NN08
G08            Rae, Katy                   90026777    1 2  50C   33.78 1:12.13                                                                P             N13
D08        Rae, Katy                   90026777    A   0419201114FF  501112 UNOV11012025   29.26S   30.14S                   3 0 0 0 58           9501      NN57
D08        Rae, Katy                   90026777    A   0419201114FF 2002114 UNOV11012025 2:38.41S 2:36.75S                   1 6 0 0 27           9502      NN18
G08            Rae, Katy                   90026777    1 4  50C   37.82 1:18.63 1:59.13 2:36.75                                                P             N74
D08        Rae, Katy                   90026777    A   0419201114FF 8001202 UNOV1101202510:07.88S                  10:11.91S     1 3    23       59501      NN28
G08            Rae, Katy                   90026777    116  50C   33.59 1:11.22 1:49.92 2:28.21 3:08.16 3:47.18 4:25.70 5:04.86 5:43.23 6:22.34F             N19
G08            Rae, Katy                   90026777    216  50C 7:01.00 7:39.13 8:17.30 8:55.97 9:34.3610:11.91                                F             N56
D08        Rae, Katy                   90026777    A   0419201114FF 4001401 UNOV11022025 4:55.20S 4:51.54S                   2 8 0 0 22           9501      NN18
G08            Rae, Katy                   90026777    1 8  50C   32.13 1:07.81 1:44.85 2:22.11 2:59.58 3:37.08 4:14.90 4:51.54                P             N67
D08        Rae, Katy                   90026777    A   0419201114FF  503403 UNOV11022025   39.20S   39.87S                   2 8 0 0 56           9503      NN67
D08        Rae, Katy                   90026777    A   0419201114FF 2004405 UNOV11022025 2:32.80S 2:36.17S                   4 7 0 0 13           9504      NN18
G08            Rae, Katy                   90026777    1 4  50C   34.07 1:12.98 1:54.04 2:36.17                                                P             N64
D08        Rae, Katy                   90026777    A   0419201114FF  504411 UNOV11022025   32.47S   32.54S                   1 3 0 0 51           9504      NN57
D08        Rae, Katy                   90026777    A   0419201114FF 2003413 UNOV11022025 2:59.91S 2:59.58S                   1 1 0 0 39           9503      NN28
G08            Rae, Katy                   90026777    1 4  50C   41.04 1:29.06 2:15.42 2:59.58                                                P             N64
D08        Rae, Katy                   90026777    A   0419201114FF 4005501 UNOV11022025 5:21.00S                   5:25.12S     4 6    18       69505      NN08
G08            Rae, Katy                   90026777    1 8  50C   34.41 1:15.09 1:58.19 2:39.67 3:27.00 4:14.76 4:50.73 5:25.12                F             N57
D08        Rae, Katy                   90026777    A   0419201114FF 1003108 UNOV11012025 1:27.03S 1:23.86S                   5 2 0 0 40           9503      NN18
G08            Rae, Katy                   90026777    1 2  50C   39.94 1:23.86                                                                P             N23
D08        Rae, Katy                   90026777    A   0419201114FF 1001409 UNOV11022025 1:03.68S 1:06.29S                   8 7 0 0 65           9501      NN28
G08            Rae, Katy                   90026777    1 2  50C   31.06 1:06.29                                                                P             N13
D08        Reid, Fergus                90009972    A   0826200916MM 2001522 UNOV11022025 2:09.70S 2:07.99S                   1 3      7           9501      NN29
D390009972                                                                                                                                                   N58
G08            Reid, Fergus                90009972    1 4  50C   28.97 1:01.47 1:35.01 2:07.99                                                P             N85
D08        Reid, Fergus                90009972    A   0826200916MM 1004530 UNOV11022025 1:08.79S 1:06.36S                   2 1      6           9504      NN19
G08            Reid, Fergus                90009972    1 2  50C   30.65 1:06.36                                                                P             N34
D08        Reid, Fergus                90009972    A   0826200916MM 4001101 UNOV11012025 4:31.30S 4:31.19S                   1 4 0 0 28           9501      NN39
G08            Reid, Fergus                90009972    1 8  50C   29.39 1:02.58 1:36.48 2:11.00 2:45.96 3:21.18 3:56.24 4:31.19                P             N78
D08        Reid, Fergus                90009972    A   0826200916MM  503103 UNOV11012025   34.40S   33.02S                   2 3 0 0 37           9503      NN88
D08        Reid, Fergus                90009972    A   0826200916MM 2004105 UNOV11012025 2:31.80S 2:35.82S                   2 0 0 0 36           9504      NN49
G08            Reid, Fergus                90009972    1 4  50C   34.19 1:13.69 1:54.42 2:35.82                                                P             N85
D08        Reid, Fergus                90009972    A   0826200916MM 1002107 UNOV11012025 1:06.20S 1:05.22S                   1 2 0 0 30           9502      NN29
G08            Reid, Fergus                90009972    1 2  50C   31.39 1:05.22                                                                P             N34
D08        Reid, Fergus                90009972    A   0826200916MM 2003113 UNOV11012025 2:35.92S 2:38.56S                   3 8 0 0 27           9503      NN49
G08            Reid, Fergus                90009972    1 4  50C   35.27 1:14.83 1:56.17 2:38.56                                                P             N85
D08        Reid, Fergus                90009972    A   0826200916MM 4005201 UNOV11012025 5:00.84S                   4:56.06S     3 5    20       59505      NN39
G08            Reid, Fergus                90009972    1 8  50C   31.07 1:07.39 1:45.22 2:23.99 3:04.48 3:47.79 4:22.37 4:56.06                F             N78
D08        Reid, Fergus                90009972    A   0826200916MM  502404 UNOV11022025   31.89S   30.44S                   1 6 0 0 40           9502      NN88
D08        Reid, Fergus                90009972    A   0826200916MM 2005406 UNOV11022025 2:21.40S 2:20.97S                   3 9 0 0 27           9505      NN49
G08            Reid, Fergus                90009972    1 4  50C   30.44 1:06.24 1:48.10 2:20.97                                                P             N75
D08        Reid, Fergus                90009972    A   0826200916MM 1003408 UNOV11022025 1:13.50S 1:12.72S          1:12.14S 1 2 1 9 29 18       89503      NN70
G08            Reid, Fergus                90009972    1 2  50C   34.57 1:12.72                                                                P             N34
G08            Reid, Fergus                90009972    1 2  50C   33.91 1:12.14                                                                F             N24
D08        Reid, Fergus                90009972    A   0826200916MM 2002414 UNOV11022025 2:19.93S 2:19.65S                   4 1 0 0 19           9502      NN49
G08            Reid, Fergus                90009972    1 4  50C   32.60 1:07.29 1:43.24 2:19.65                                                P             N85
D08        Reid, Fergus                90009972    A   0826200916MM 8001502 UNOV11022025 9:15.27S                   9:20.42S     2 1    18       89501      NN49
G08            Reid, Fergus                90009972    116  50C   30.73 1:04.78 1:39.28 2:14.64 2:50.15 3:25.44 4:00.81 4:35.75 5:10.71 5:45.93F             N20
G08            Reid, Fergus                90009972    216  50C 6:21.25 6:56.99 7:32.97 8:09.12 8:44.85 9:20.42                                F             N77
D08        Reid, Fergus                90009972    A   0826200916MM 2001402 UNOV11022025 2:09.70S 2:07.99S                   5 3 0 0 44           9501      NN49
G08            Reid, Fergus                90009972    1 4  50C   28.97 1:01.47 1:35.01 2:07.99                                                P             N85
D08        Reid, Fergus                90009972    A   0826200916MM 1004410 UNOV11022025 1:08.79S 1:06.36S                   6 1 0 0 43           9504      NN49
G08            Reid, Fergus                90009972    1 2  50C   30.65 1:06.36                                                                P             N34
D08        Searle, Millie              90024751    A   0224201114FF 1004110 UNOV11012025 1:07.30S 1:11.80S                   2 1 0 0 31           9504      NN89
D390024751                                                                                                                                                   N48
G08            Searle, Millie              90024751    1 2  50C   33.34 1:11.80                                                                P             N94
D08        Searle, Millie              90024751    A   0224201114FF  501112 UNOV11012025   27.67S   28.96S                   6 1 0 0 33           9501      NN49
D08        Searle, Millie              90024751    A   0224201114FF 2002114 UNOV11012025 2:21.90S 2:25.36S          2:26.69S 4 5 1 0  9 10  1.   0950200    NN41
G08            Searle, Millie              90024751    1 4  50C   33.66 1:10.57 1:48.28 2:25.36                                                P             N56
G08            Searle, Millie              90024751    1 4  50C   33.70 1:10.81 1:48.88 2:26.69                                                F             N56
D08        Searle, Millie              90024751    A   0224201114FF 8001202 UNOV11012025 9:40.30S                   9:42.00S     3 9     8  3.   7950100    NN10
G08            Searle, Millie              90024751    116  50C   32.86 1:09.08 1:45.68 2:22.30 2:59.50 3:36.56 4:13.44 4:50.64 5:27.45 6:04.48F             N01
G08            Searle, Millie              90024751    216  50C 6:41.20 7:18.01 7:54.59 8:31.14 9:07.72 9:42.00                                F             N28
D08        Searle, Millie              90024751    A   0224201114FF 4001401 UNOV11022025 4:40.94S 4:48.46S                   3 7 0 0 15           9501      NN99
G08            Searle, Millie              90024751    1 8  50C   32.38 1:08.39 1:45.18 2:22.20 2:58.77 3:35.90 4:12.67 4:48.46                P             N59
D08        Searle, Millie              90024751    A   0224201114FF  503403 UNOV11022025   33.70S   34.95S            34.51S 5 5 2 8  8  7  4.   7950300    NN70
D08        Searle, Millie              90024751    A   0224201114FF 2004405 UNOV11022025 2:28.10S 2:35.30S                   2 3 0 0 12           9504      NN89
G08            Searle, Millie              90024751    1 4  50C   33.36 1:12.74 1:54.02 2:35.30                                                P             N46
D08        Searle, Millie              90024751    A   0224201114FF 1002407 UNOV11022025 1:07.60S 1:09.52S          1:09.00S 4 7 1 7 18 16       69502      NN21
G08            Searle, Millie              90024751    1 2  50C   33.81 1:09.52                                                                P             N05
G08            Searle, Millie              90024751    1 2  50C   33.78 1:09.00                                                                F             N94
D08        Searle, Millie              90024751    A   0224201114FF 1001409 UNOV11022025 1:01.70S 1:04.16S                   1 8 0 0 46           9501      NN89
G08            Searle, Millie              90024751    1 2  50C   30.98 1:04.16                                                                P             N05
D08        Searle, Millie              90024751    A   0224201114FF  504411 UNOV11022025   30.18S   32.45S                   4 4 0 0 48           9504      NN49
D08        Searle, Millie              90024751    A   0224201114FF 2003413 UNOV11022025 2:37.50S 2:43.13S          2:42.35S 3 4 1 8  8  6  5.   6950300    NN41
G08            Searle, Millie              90024751    1 4  50C   36.32 1:17.82 2:00.64 2:43.13                                                P             N46
G08            Searle, Millie              90024751    1 4  50C   36.25 1:17.82 2:00.27 2:42.35                                                F             N46
D08        Searle, Millie              90024751    A   0224201114FF 4005501 UNOV11022025 5:00.90S                   5:06.95S     5 4     4  7.   4950500    NN10
G08            Searle, Millie              90024751    1 8  50C   32.73 1:12.19 1:51.37 2:29.69 3:13.21 3:57.08 4:33.17 5:06.95                F             N49
D08        Searle, Millie              90024751    A   0224201114FF 2001102 UNOV11012025 2:13.60S 2:15.51S                   3 8 0 0 24           9501      NN89
G08            Searle, Millie              90024751    1 4  50C   31.30 1:05.83 1:40.85 2:15.51                                                P             N46
D08        Searle, Millie              90024751    A   0224201114FF  502104 UNOV11012025   31.02S   31.34S            32.06S 5 1 1 5 14 17       79502      NN30
D08        Searle, Millie              90024751    A   0224201114FF 2005106 UNOV11012025 2:19.80S 2:24.09S          2:23.22S 2 4 1 2  5  4  7.   4950500    NN41
G08            Searle, Millie              90024751    1 4  50C   31.83 1:08.80 1:49.53 2:24.09                                                P             N56
G08            Searle, Millie              90024751    1 4  50C   32.21 1:08.95 1:49.45 2:23.22                                                F             N46
D08        Searle, Millie              90024751    A   0224201114FF 1003108 UNOV11012025 1:11.70S 1:14.30S          1:13.50S 3 4 2 6  4  3  8.   3950300    NN31
G08            Searle, Millie              90024751    1 2  50C   35.41 1:14.30                                                                P             N94
G08            Searle, Millie              90024751    1 2  50C   36.04 1:13.50                                                                F             N94
D08        Simpson, Phoebe             90022431    A   0223201114FF 2002114 UNOV11012025 2:41.96S 2:47.46S                   5 4 0 0 45           9502      NN40
D390022431                                                                                                                                                   N48
G08            Simpson, Phoebe             90022431    1 4  50C   37.98 1:21.60 2:05.57 2:47.46                                                P             N07
D08        Simpson, Phoebe             90022431    A   0223201114FF 2001102 UNOV11012025 2:20.10S 2:27.62S                   6 6 0 0 50           9501      NN30
G08            Simpson, Phoebe             90022431    1 4  50C   33.46 1:11.80 1:50.11 2:27.62                                                P             N96
D08        Simpson, Phoebe             90022431    A   0223201114FF 2005106 UNOV11012025 2:41.28S 2:43.61S                   6 5 0 0 46           9505      NN40
G08            Simpson, Phoebe             90022431    1 4  50C   34.79 1:18.51 2:07.41 2:43.61                                                P             N96
D08        Simpson, Phoebe             90022431    A   0223201114FF 1004110 UNOV11012025 1:09.10S 1:10.35S          1:09.04S 1 4 1 0 26 19       99504      NN61
G08            Simpson, Phoebe             90022431    1 2  50C   32.60 1:10.35                                                                P             N45
G08            Simpson, Phoebe             90022431    1 2  50C   32.44 1:09.04                                                                F             N45
D08        Simpson, Phoebe             90022431    A   0223201114FF  501112 UNOV11012025   29.70S   30.27S                   2 1 0 0 61           9501      NN89
D08        Simpson, Phoebe             90022431    A   0223201114FF 8001202 UNOV1101202510:10.40S                  10:00.18S     1 6    20       39501      NN30
G08            Simpson, Phoebe             90022431    116  50C   33.77 1:10.63 1:47.36 2:24.51 3:02.64 3:40.45 4:18.28 4:56.09 5:34.15 6:12.02F             N31
G08            Simpson, Phoebe             90022431    216  50C 6:50.27 7:28.67 8:06.70 8:45.41 9:24.5310:00.18                                F             N98
D08        Simpson, Phoebe             90022431    A   0223201114FF 4001401 UNOV11022025 4:55.97S 5:04.26S                   2 0 0 0 33           9501      NN40
G08            Simpson, Phoebe             90022431    1 8  50C   32.90 1:10.49 1:49.50 2:28.89 3:08.36 3:47.23 4:26.29 5:04.26                P             N00
D08        Simpson, Phoebe             90022431    A   0223201114FF 2004405 UNOV11022025 2:40.20S 2:41.20S                   2 8 0 0 19           9504      NN30
G08            Simpson, Phoebe             90022431    1 4  50C   34.59 1:16.05 1:59.50 2:41.20                                                P             N96
D08        Simpson, Phoebe             90022431    A   0223201114FF  504411 UNOV11022025   31.23S   32.03S                   3 8 0 0 40           9504      NN89
D08        Simpson, Phoebe             90022431    A   0223201114FF 4005501 UNOV11022025 5:37.20S                   5:45.28S     2 5    34       99505      NN40
G08            Simpson, Phoebe             90022431    1 8  50C   37.16 1:21.45 2:05.48 2:48.21 3:38.03 4:29.52 5:07.73 5:45.28                F             N99
D08        Simpson, Phoebe             90022431    A   0223201114FF 1003108 UNOV11012025 1:27.31S 1:31.04S                   6 1 0 0 51           9503      NN30
G08            Simpson, Phoebe             90022431    1 2  50C   42.37 1:31.04                                                                P             N45
D08        Simpson, Phoebe             90022431    A   0223201114FF 1001529 UNOV11022025 1:05.10S 1:07.06S                   1 4     32           9501      NN10
G08            Simpson, Phoebe             90022431    1 2  50C   31.92 1:07.06                                                                P             N55
D08        Simpson, Phoebe             90022431    A   0223201114FF 1001409 UNOV11022025 1:05.10S 1:07.06S                   5 4 0 0 66           9501      NN30
G08            Simpson, Phoebe             90022431    1 2  50C   31.92 1:07.06                                                                P             N55
D08        Smith, Keyan                90039936    A   0911201213MM 1003528 UNOV11022025 1:24.27S 1:21.91S                   2 8     36           9503      NN39
D390039936                                                                                                                                                   N58
G08            Smith, Keyan                90039936    1 2  50C   38.70 1:21.91                                                                P             N44
D08        Smith, Keyan                90039936    A   0911201213MM 2003113 UNOV11012025 2:59.82S 2:57.62S                   5 5 0 0 62           9503      NN59
G08            Smith, Keyan                90039936    1 4  50C   40.18 1:25.58 2:12.64 2:57.62                                                P             N95
D08        Smith, Keyan                90039936    A   0911201213MM 1003408 UNOV11022025 1:24.27S 1:21.91S                   6 8 0 0 72           9503      NN49
G08            Smith, Keyan                90039936    1 2  50C   38.70 1:21.91                                                                P             N44
D08        Tetlow, Blair               90023149    A   0701201114MM 2005526 UNOV11022025 2:31.50S 2:38.90S                   1 1     28           9505      NN69
D390023149                                                                                                                                                   N48
G08            Tetlow, Blair               90023149    1 4  50C   34.59 1:16.47 2:03.02 2:38.90                                                P             N26
D08        Tetlow, Blair               90023149    A   0701201114MM 1002107 UNOV11012025 1:12.28S 1:16.05S                   6 9 0 0 70           9502      NN79
G08            Tetlow, Blair               90023149    1 2  50C   36.37 1:16.05                                                                P             N74
D08        Tetlow, Blair               90023149    A   0701201114MM 2003113 UNOV11012025 2:50.72S 3:03.11S                   6 1 0 0 65           9503      NN79
G08            Tetlow, Blair               90023149    1 4  50C   43.09 1:30.08 2:17.78 3:03.11                                                P             N26
D08        Tetlow, Blair               90023149    A   0701201114MM 2004105 UNOV11012025 2:33.52S 2:34.37S                   1 5 0 0 31           9504      NN79
G08            Tetlow, Blair               90023149    1 4  50C   34.74 1:13.75 1:54.08 2:34.37                                                P             N26
D08        Tetlow, Blair               90023149    A   0701201114MM 4005201 UNOV11012025 5:20.60S                   5:16.28S     1 4    37       29505      NN79
G08            Tetlow, Blair               90023149    1 8  50C   34.65 1:14.98 1:56.37 2:36.44 3:20.21 4:05.97 4:42.09 5:16.28                F             N29
D08        Tetlow, Blair               90023149    A   0701201114MM 2002414 UNOV11022025 2:27.34S 2:29.28S                   1 2 0 0 41           9502      NN79
G08            Tetlow, Blair               90023149    1 4  50C   35.11 1:13.23 1:51.77 2:29.28                                                P             N26
D08        Tetlow, Blair               90023149    A   0701201114MM 1003528 UNOV11022025 1:24.40S 1:19.49S                   1 4     22           9503      NN69
G08            Tetlow, Blair               90023149    1 2  50C   37.93 1:19.49                                                                P             N84
D08        Tetlow, Blair               90023149    A   0701201114MM 4001101 UNOV11012025 4:51.11S 4:49.81S                   5 5 0 0 40           9501      NN79
G08            Tetlow, Blair               90023149    1 8  50C   33.45 1:10.68 1:48.01 2:25.09 3:01.70 3:38.12 4:14.98 4:49.81                P             N19
D08        Tetlow, Blair               90023149    A   0701201114MM 1003408 UNOV11022025 1:24.40S 1:19.49S                   5 4 0 0 58           9503      NN89
G08            Tetlow, Blair               90023149    1 2  50C   37.93 1:19.49                                                                P             N84
D08        Tetlow, Blair               90023149    A   0701201114MM 2005406 UNOV11022025 2:31.50S 2:38.90S                   5 1 0 0 66           9505      NN89
G08            Tetlow, Blair               90023149    1 4  50C   34.59 1:16.47 2:03.02 2:38.90                                                P             N26
D08        Tweedie, Libby              90021435    A   0705201114FF 1004110 UNOV11012025 1:12.75S 1:15.23S                   7 5 0 0 49           9504      NN99
D390021435                                                                                                                                                   N48
G08            Tweedie, Libby              90021435    1 2  50C   35.28 1:15.23                                                                P             N05
D08        Tweedie, Libby              90021435    A   0705201114FF 1003108 UNOV11012025 1:26.38S 1:23.64S                   5 6 0 0 38           9503      NN99
G08            Tweedie, Libby              90021435    1 2  50C   40.77 1:23.64                                                                P             N05
D08        Tweedie, Libby              90021435    A   0705201114FF 2005106 UNOV11012025 2:39.40S 2:36.32S                   1 1 0 0 26           9505      NN99
G08            Tweedie, Libby              90021435    1 4  50C   34.11 1:13.76 1:59.34 2:36.32                                                P             N46
D08        Tweedie, Libby              90021435    A   0705201114FF 2002114 UNOV11012025 2:40.10S 2:36.14S                   1 7 0 0 23           9502      NN89
G08            Tweedie, Libby              90021435    1 4  50C   36.83 1:16.83 1:57.10 2:36.14                                                P             N46
D08        Tweedie, Libby              90021435    A   0705201114FF 8001202 UNOV1101202510:17.20S                   9:58.44S     1 7    18       29501      NN99
G08            Tweedie, Libby              90021435    116  50C   35.39 1:12.90 1:50.98 2:28.98 3:06.86 3:45.15 4:23.60 5:01.59 5:39.62 6:17.38F             N01
G08            Tweedie, Libby              90021435    216  50C 6:55.49 7:33.40 8:10.30 8:47.20 9:23.22 9:58.44                                F             N38
D08        Tweedie, Libby              90021435    A   0705201114FF 4001401 UNOV11022025 5:05.13S 4:51.26S                   1 7 0 0 21           9501      NN89
G08            Tweedie, Libby              90021435    1 8  50C   33.66 1:10.39 1:47.09 2:24.19 3:01.39 3:38.65 4:15.82 4:51.26                P             N49
D08        Tweedie, Libby              90021435    A   0705201114FF 2004405 UNOV11022025 2:40.10S 2:40.64S                   4 8 0 0 18           9504      NN99
G08            Tweedie, Libby              90021435    1 4  50C   35.70 1:16.52 1:59.11 2:40.64                                                P             N46
D08        Tweedie, Libby              90021435    A   0705201114FF 2003413 UNOV11022025 3:00.09S 2:54.26S                   1 8 0 0 26           9503      NN99
G08            Tweedie, Libby              90021435    1 4  50C   40.63 1:25.80 2:10.79 2:54.26                                                P             N46
D08        Tweedie, Libby              90021435    A   0705201114FF 4005501 UNOV11022025 5:29.80S                   5:22.48S     3 2    14       29505      NN99
G08            Tweedie, Libby              90021435    1 8  50C   35.57 1:16.13 1:57.83 2:37.99 3:24.04 4:09.43 4:47.55 5:22.48                F             N49
D08        Tweedie, Libby              90021435    A   0705201114FF 2001102 UNOV11012025 2:23.70S 2:22.77S                   5 1 0 0 45           9501      NN89
G08            Tweedie, Libby              90021435    1 4  50C   33.42 1:10.20 1:47.42 2:22.77                                                P             N46
D08        West, Lara                  90031772    A   0208201213FF 2004525 UNOV11022025 3:09.81S 3:10.33S                   1 2      5           9504      NN28
D390031772                                                                                                                                                   N48
G08            West, Lara                  90031772    1 4  50C   38.55 1:22.73 2:14.55 3:10.33                                                P             N05
D08        West, Lara                  90031772    A   0208201213FF 2003533 UNOV11022025 3:03.18S 3:05.39S                   2 6      9           9503      NN28
G08            West, Lara                  90031772    1 4  50C   42.05 1:29.39 2:17.82 3:05.39                                                P             N05
D08        West, Lara                  90031772    A   0208201213FF 1003108 UNOV11012025 1:25.91S 1:22.68S                   6 3 0 0 32           9503      NN58
G08            West, Lara                  90031772    1 2  50C   38.07 1:22.68                                                                P             N63
D08        West, Lara                  90031772    A   0208201213FF 1001529 UNOV11022025 1:04.70S 1:04.93S                   4 9     25           9501      NN38
G08            West, Lara                  90031772    1 2  50C   31.06 1:04.93                                                                P             N53
D08        West, Lara                  90031772    A   0208201213FF  501112 UNOV11012025   29.18S   29.90S                   3 7 0 0 55           9501      NN08
D08        West, Lara                  90031772    A   0208201213FF  503403 UNOV11022025   38.41S   38.26S                   2 5 0 0 39           9503      NN08
D08        West, Lara                  90031772    A   0208201213FF 1001409 UNOV11022025 1:04.70S 1:04.93S                   8 9 0 0 57           9501      NN58
G08            West, Lara                  90031772    1 2  50C   31.06 1:04.93                                                                P             N53
D08        West, Lara                  90031772    A   0208201213FF 2004405 UNOV11022025 3:09.81S 3:10.33S                   5 2 0 0 39           9504      NN58
G08            West, Lara                  90031772    1 4  50C   38.55 1:22.73 2:14.55 3:10.33                                                P             N05
D08        West, Lara                  90031772    A   0208201213FF 2003413 UNOV11022025 3:03.18S 3:05.39S                   6 6 0 0 45           9503      NN58
G08            West, Lara                  90031772    1 4  50C   42.05 1:29.39 2:17.82 3:05.39                                                P             N05
E08        A  NGHX  X 2006301 UNOV  011012025 1:45.91S                   1:48.20S     2 8    11                                                0N13001  X    N15
F08              NGHXAPritchard, Hayden           90018258       0407200718M  1             90018258                                                         N57
G08            Pritchard, Hayden           90018258    1 4  50C   25.47                                                                        F             N55
F08              NGHXAMacpherson, Austin          90022368       0102201015M  2             90022368                                                         N97
G08            Macpherson, Austin          90022368    1 4  50C   50.78                                                                        F             N06
F08              NGHXASearle, Millie              90024751       0224201114F  3             90024751                                                         N16
G08            Searle, Millie              90024751    1 4  50C 1:19.73                                                                        F             N54
F08              NGHXADenny, Ellen                90009970       0411200817F  4             90009970                                                         N55
G08            Denny, Ellen                90009970    1 4  50C 1:48.20                                                                        F             N83
E08        B  NGHX  X 2006301 UNOV  011012025 1:48.25S                   1:52.73S     1 5    15                                                5N13001  X    N25
F08              NGHXBReid, Fergus                90009972       0826200916M  1             90009972                                                         N65
G08            Reid, Fergus                90009972    1 4  50C   26.66                                                                        F             N63
F08              NGHXBHay, Jamie                  90013989       1014200817M  2             90013989                                                         N74
G08            Hay, Jamie                  90013989    1 4  50C   53.23                                                                        F             N72
F08              NGHXBRae, Katy                   90026777       0419201114F  3             90026777                                                         N44
G08            Rae, Katy                   90026777    1 4  50C 1:23.19                                                                        F             N62
F08              NGHXBMcLaughlin, Erin            90003278       0413200916F  4             90003278                                                         N86
G08            McLaughlin, Erin            90003278    1 4  50C 1:52.73                                                                        F             N15
E08        C  NGHX  X 2006301 UNOV  011012025 1:51.41S                   1:55.38S     1 1    16                                                6N13001  X    N25
F08              NGHXCGow, Innes                  1291399        0227200817M  1             1291399                                                          N74
G08            Gow, Innes                  1291399     1 4  50C   27.84                                                                        F             N82
F08              NGHXCKelly, Max                  90024760       0423201015M  2             90024760                                                         N74
G08            Kelly, Max                  90024760    1 4  50C   54.84                                                                        F             N82
F08              NGHXCSimpson, Phoebe             90022431       0223201114F  3             90022431                                                         N66
G08            Simpson, Phoebe             90022431    1 4  50C 1:25.36                                                                        F             N94
F08              NGHXCWest, Lara                  90031772       0208201213F  4             90031772                                                         N74
G08            West, Lara                  90031772    1 4  50C 1:55.38                                                                        F             N03
E08        A  NGHX  X 2007601 UNOV  011022025 1:56.52S                   1:58.35S     2 8     9                                                8N13005  X    N25
F08              NGHXAHay, Jamie                  90013989       1014200817M  1             90013989                                                         N74
G08            Hay, Jamie                  90013989    1 4  50C   28.73                                                                        F             N72
F08              NGHXASearle, Millie              90024751       0224201114F  2             90024751                                                         N16
G08            Searle, Millie              90024751    1 4  50C 1:03.05                                                                        F             N44
F08              NGHXADenny, Ellen                90009970       0411200817F  3             90009970                                                         N55
G08            Denny, Ellen                90009970    1 4  50C 1:33.45                                                                        F             N83
F08              NGHXAPritchard, Hayden           90018258       0407200718M  4             90018258                                                         N57
G08            Pritchard, Hayden           90018258    1 4  50C 1:58.35                                                                        F             N75
E08        B  NGHX  X 2007601 UNOV  011022025 1:58.62S                   2:06.67S     2 9    12                                                9N13005  X    N35
F08              NGHXBKelly, Max                  90024760       0423201015M  1             90024760                                                         N74
G08            Kelly, Max                  90024760    1 4  50C   29.86                                                                        F             N82
F08              NGHXBMacpherson, Austin          90022368       0102201015M  2             90022368                                                         N97
G08            Macpherson, Austin          90022368    1 4  50C 1:03.05                                                                        F             N26
F08              NGHXBSimpson, Phoebe             90022431       0223201114F  3             90022431                                                         N66
G08            Simpson, Phoebe             90022431    1 4  50C 1:35.32                                                                        F             N94
F08              NGHXBRae, Katy                   90026777       0419201114F  4             90026777                                                         N44
G08            Rae, Katy                   90026777    1 4  50C 2:06.67                                                                        F             N62
E08        C  NGHX  X 2007601 UNOV  011022025 2:01.58S                   2:06.13S     1 3    11                                                3N13005  X    N15
F08              NGHXCTweedie, Libby              90021435       0705201114F  1             90021435                                                         N16
G08            Tweedie, Libby              90021435    1 4  50C   33.41                                                                        F             N24
F08              NGHXCReid, Fergus                90009972       0826200916M  2             90009972                                                         N65
G08            Reid, Fergus                90009972    1 4  50C 1:06.94                                                                        F             N83
F08              NGHXCGow, Innes                  1291399        0227200817M  3             1291399                                                          N74
G08            Gow, Innes                  1291399     1 4  50C 1:36.40                                                                        F             N03
F08              NGHXCMcLaughlin, Erin            90003278       0413200916F  4             90003278                                                         N96
G08            McLaughlin, Erin            90003278    1 4  50C 2:06.13                                                                        F             N15
C18SS      SSEHMXHeart of Midlothian Asc       Heart Of Mid    Drumbrae Leisure Centr                      Edinburgh           MIEH4 7SF                     N72
D08SS      Bedborough, Leonie          1253632     AGBR0508200916FF 1003108 UNOV11012025 1:16.56S 1:17.60S          1:17.09S 3 6 1 5 12 16       69503      NN93
D31253632                                                                                                                                                    N38
G08SS          Bedborough, Leonie          1253632     1 2  50C   37.12 1:17.60                                                                P             N96
G08SS          Bedborough, Leonie          1253632     1 2  50C   36.75 1:17.09                                                                F             N96
D08SS      Bedborough, Leonie          1253632     AGBR0508200916FF 8001202 UNOV11012025 9:54.66S                   9:49.73S     2 1    13       69501      NN62
G08SS          Bedborough, Leonie          1253632     116  50C   33.57 1:10.03 1:47.51 2:24.95 3:02.07 3:38.99 4:16.00 4:53.29 5:30.53 6:07.96F             N92
G08SS          Bedborough, Leonie          1253632     216  50C 6:45.33 7:23.06 8:00.46 8:37.62 9:14.12 9:49.73                                F             N30
D08SS      Bedborough, Leonie          1253632     AGBR0508200916FF 4001401 UNOV11022025 4:44.30S 4:49.26S                   4 0 0 0 18           9501      NN62
G08SS          Bedborough, Leonie          1253632     1 8  50C   33.97 1:10.46 1:47.02 2:23.81 3:00.25 3:37.10 4:13.67 4:49.26                P             N31
D08SS      Bedborough, Leonie          1253632     AGBR0508200916FF 2003413 UNOV11022025 2:42.50S 2:46.57S                   3 6 0 0 12           9503      NN62
G08SS          Bedborough, Leonie          1253632     1 4  50C   39.73 1:21.42 2:04.03 2:46.57                                                P             N48
D08SS      Bedborough, Leonie          1253632     AGBR0508200916FF 4005501 UNOV11022025 5:17.40S                   5:25.15S     5 0    19       09505      NN52
G08SS          Bedborough, Leonie          1253632     1 8  50C   37.69 1:20.54 2:00.97 2:41.93 3:26.55 4:11.79 4:48.74 5:25.15                F             N41
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 2001102 UNOV11012025 2:15.20S 2:17.21S                   2 0 0 0 30           9501      NN60
D390033454                                                                                                                                                   N48
G08SS          Brown, Alanya               90033454    1 4  50C   31.96 1:06.13 1:41.19 2:17.21                                                P             N66
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 2002114 UNOV11012025 2:34.00S 2:38.31S                   2 0 0 0 33           9502      NN70
G08SS          Brown, Alanya               90033454    1 4  50C   36.83 1:15.75 1:56.48 2:38.31                                                P             N76
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 8001202 UNOV1101202510:03.59S                   9:57.74S     1 5    17       19501      NN90
G08SS          Brown, Alanya               90033454    116  50C   34.07 1:10.80 1:48.20 2:25.43 3:02.66 3:40.57 4:18.39 4:56.02 5:33.94 6:11.79F             N11
G08SS          Brown, Alanya               90033454    216  50C 6:49.76 7:27.34 8:05.34 8:43.40 9:21.56 9:57.74                                F             N68
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 4001401 UNOV11022025 4:47.80S 4:48.52S                   2 4 0 0 16           9501      NN80
G08SS          Brown, Alanya               90033454    1 8  50C   32.84 1:08.17 1:44.91 2:21.74 2:58.31 3:35.33 4:12.37 4:48.52                P             N69
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 1002527 UNOV11022025 1:13.80S 1:14.45S                   1 3      4           9502      NN50
G08SS          Brown, Alanya               90033454    1 2  50C   36.00 1:14.45                                                                P             N25
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 4005501 UNOV11022025 5:39.03S                   5:35.88S     2 6    25       39505      NN80
G08SS          Brown, Alanya               90033454    1 8  50C   37.31 1:20.40 2:02.48 2:44.12 3:34.58 4:23.69 4:59.83 5:35.88                F             N69
D08SS      Brown, Alanya               90033454    AGBR0906201015FF 1002407 UNOV11022025 1:13.80S 1:14.45S                   5 3 0 0 36           9502      NN80
G08SS          Brown, Alanya               90033454    1 2  50C   36.00 1:14.45                                                                P             N25
D08SS      Mundell, Lili C             90019877    AGBR0104201015FF 2001102 UNOV11012025 2:04.60S 2:06.06S          2:03.51S 2 4 1 3  3  3  8.   3950100    NN32
D390019877      Lili                                                                                                                                         N99
G08SS          Mundell, Lili C             90019877    1 4  50C   28.06   59.90 1:33.09 2:06.06                                                P             N76
G08SS          Mundell, Lili C             90019877    1 4  50C   28.98 1:00.71 1:32.98 2:03.51                                                F             N96
D08SS      Mundell, Lili C             90019877    AGBR0104201015FF  501112 UNOV11012025   25.80S   26.27S            26.06S 7 4 2 4  1  1 10.   1950100    NN71
D08SS      Mundell, Lili C             90019877    AGBR0104201015FF 8001202 UNOV11012025 9:07.00S                   9:06.16S     3 4     1 10.   1950100    NN21
G08SS          Mundell, Lili C             90019877    116  50C   30.10 1:04.16 1:38.39 2:12.97 2:47.49 3:21.84 3:56.43 4:31.27 5:05.93 5:40.87F             N41
G08SS          Mundell, Lili C             90019877    216  50C 6:15.71 6:50.28 7:24.87 7:59.02 8:32.90 9:06.16                                F             N88
D08SS      Mundell, Lili C             90019877    AGBR0104201015FF 4001401 UNOV11022025 4:26.00S 4:27.29S          4:22.71S 4 4 1 4  1  1 10.   1950100    NN52
G08SS          Mundell, Lili C             90019877    1 8  50C   29.72 1:03.14 1:36.99 2:10.72 2:44.50 3:18.40 3:53.19 4:27.29                P             N99
G08SS          Mundell, Lili C             90019877    1 8  50C   29.01 1:01.50 1:34.76 2:08.45 2:42.57 3:17.01 3:50.70 4:22.71                F             N79
D08SS      Mundell, Lili C             90019877    AGBR0104201015FF 4005501 UNOV11022025 5:02.99S                   5:04.82S     5 3     3  8.   3950500    NN31
G08SS          Mundell, Lili C             90019877    1 8  50C   30.69 1:06.94 1:48.24 2:27.23 3:11.38 3:55.81 4:31.28 5:04.82                F             N89
D08SS      Neil, Emily                 90020812    AGBR0310200916FF 4001401 UNOV11022025 4:49.66S 4:47.90S                   2 3 0 0 14           9501      NN00
D390020812                                                                                                                                                   N48
G08SS          Neil, Emily                 90020812    1 8  50C   32.63 1:08.25 1:44.74 2:21.38 2:58.12 3:35.26 4:12.21 4:47.90                P             N88
D08SS      Neil, Emily                 90020812    AGBR0310200916FF  504411 UNOV11022025   30.50S   32.32S                   4 1 0 0 45           9504      NN49
D08SS      Neil, Emily                 90020812    AGBR0310200916FF 4005501 UNOV11022025 5:27.47S                   5:28.86S     3 4    22       59505      NN00
G08SS          Neil, Emily                 90020812    1 8  50C   34.69 1:15.28 1:56.37 2:36.12 3:25.80 4:15.18 4:52.77 5:28.86                F             N98
D08SS      Neil, Emily                 90020812    AGBR0310200916FF 2005106 UNOV11012025 2:37.70S 2:34.58S                   1 6 0 0 24           9505      NN00
G08SS          Neil, Emily                 90020812    1 4  50C   33.39 1:11.78 1:59.95 2:34.58                                                P             N06
D08SS      Neil, Emily                 90020812    AGBR0310200916FF 8001202 UNOV11012025 9:48.73S                   9:44.56S     2 3    12       59501      NN00
G08SS          Neil, Emily                 90020812    116  50C   33.15 1:09.60 1:46.33 2:23.27 3:00.36 3:37.23 4:14.24 4:51.25 5:28.13 6:05.41F             N20
G08SS          Neil, Emily                 90020812    216  50C 6:42.55 7:19.54 7:56.56 8:33.44 9:10.27 9:44.56                                F             N87
D08SS      Neil, Emily                 90020812    AGBR0310200916FF 2001102 UNOV11012025 2:17.20S 2:18.73S                   6 4 0 0 37           9501      NN99
G08SS          Neil, Emily                 90020812    1 4  50C   32.94 1:08.10 1:43.70 2:18.73                                                P             N85
D08SS      Oldham, Darragh             90032389    AGBR1123200916MM 4001101 UNOV11012025 4:18.60S 4:24.08S                   4 1 0 0 17           9501      NN51
D390032389                                                                                                                                                   N58
G08SS          Oldham, Darragh             90032389    1 8  50C   28.15   59.60 1:32.82 2:06.68 2:40.94 3:15.23 3:50.16 4:24.08                P             N00
D08SS      Oldham, Darragh             90032389    AGBR1123200916MM 4005201 UNOV11012025 5:10.73S                   5:04.83S     2 4    28       49505      NN51
G08SS          Oldham, Darragh             90032389    1 8  50C   30.41 1:06.25 1:48.60 2:29.11 3:13.58 3:58.43 4:33.11 5:04.83                F             N10
D08SS      Oldham, Darragh             90032389    AGBR1123200916MM 2001402 UNOV11022025 2:02.00S 2:01.60S                   4 8 0 0 21           9501      NN41
G08SS          Oldham, Darragh             90032389    1 4  50C   27.80   58.36 1:29.88 2:01.60                                                P             N17
D08SS      Oldham, Darragh             90032389    AGBR1123200916MM 8001502 UNOV11022025 9:05.80S                   8:59.47S     2 6    11       39501      NN51
G08SS          Oldham, Darragh             90032389    116  50C   31.22 1:05.40 1:39.91 2:14.76 2:49.86 3:24.59 3:58.84 4:32.86 5:06.63 5:40.78F             N91
G08SS          Oldham, Darragh             90032389    216  50C 6:14.66 6:48.07 7:21.80 7:55.26 8:28.02 8:59.47                                F             N29
D08SS      Stormonth, Keir             90009664    AGBR0715200817MM 4001101 UNOV11012025 4:20.00S 4:20.72S                   4 0 0 0 14           9501      NN81
D390009664                                                                                                                                                   N58
G08SS          Stormonth, Keir             90009664    1 8  50C   29.06 1:00.19 1:32.93 2:05.62 2:38.87 3:12.61 3:46.74 4:20.72                P             N60
D08SS      Stormonth, Keir             90009664    AGBR0715200817MM 4005201 UNOV11012025 4:56.63S                   4:50.92S     4 1    15       59505      NN91
G08SS          Stormonth, Keir             90009664    1 8  50C   29.88 1:04.04 1:44.01 2:21.02 3:01.76 3:43.01 4:17.83 4:50.92                F             N50
D08SS      Stormonth, Keir             90009664    AGBR0715200817MM 2001402 UNOV11022025 2:02.70S 2:01.51S                   4 0 0 0 20           9501      NN81
G08SS          Stormonth, Keir             90009664    1 4  50C   28.02   58.64 1:30.31 2:01.51                                                P             N47
D08SS      Stormonth, Keir             90009664    AGBR0715200817MM 2005406 UNOV11022025 2:20.74S 2:16.49S                   4 0 0 0 14           9505      NN02
G08SS          Stormonth, Keir             90009664    1 4  50C   28.84 1:04.58 1:43.29 2:16.49                                                P             N87
D08SS      Stormonth, Keir             90009664    AGBR0715200817MM 8001502 UNOV11022025 8:51.68S                   8:51.95S     2 4     8  3.   2950100    NN22
G08SS          Stormonth, Keir             90009664    116  50C   30.15 1:02.86 1:36.09 2:09.72 2:43.19 3:16.68 3:50.06 4:23.57 4:57.00 5:30.94F             N12
G08SS          Stormonth, Keir             90009664    216  50C 6:04.68 6:38.40 7:12.52 7:45.97 8:19.59 8:51.95                                F             N79
D08SS      Wedderspoon, Layla          90007285    AGBR0126200817FF 2001102 UNOV11012025 2:05.10S 2:04.21S          2:03.28S 4 5 1 4  1  2  9.   2950100    NN24
D390007285                                                                                                                                                   N58
G08SS          Wedderspoon, Layla          90007285    1 4  50C   28.82 1:00.47 1:32.52 2:04.21                                                P             N68
G08SS          Wedderspoon, Layla          90007285    1 4  50C   28.77 1:00.58 1:32.49 2:03.28                                                F             N78
D08SS      Wedderspoon, Layla          90007285    AGBR0126200817FF 2005106 UNOV11012025 2:22.90S 2:24.63S          2:27.68S 4 3 1 7  6  9  2.   9950500    NN44
G08SS          Wedderspoon, Layla          90007285    1 4  50C   31.04 1:09.15 1:52.38 2:24.63                                                P             N78
G08SS          Wedderspoon, Layla          90007285    1 4  50C   31.28 1:11.07 1:54.71 2:27.68                                                F             N78
D08SS      Wedderspoon, Layla          90007285    AGBR0126200817FF 1004110 UNOV11012025 1:02.69S 1:04.02S          1:05.00S 2 5 2 6  4  7  4.   7950400    NN24
G08SS          Wedderspoon, Layla          90007285    1 2  50C   30.30 1:04.02                                                                P             N27
G08SS          Wedderspoon, Layla          90007285    1 2  50C   31.38 1:05.00                                                                F             N17
D08SS      Wedderspoon, Layla          90007285    AGBR0126200817FF 4001401 UNOV11022025 4:33.20S 4:31.99S          4:22.91S 3 3 1 6  4  2  9.   2950100    NN34
G08SS          Wedderspoon, Layla          90007285    1 8  50C   30.38 1:04.53 1:39.27 2:14.86 2:49.81 3:24.72 3:58.95 4:31.99                P             N81
G08SS          Wedderspoon, Layla          90007285    1 8  50C   29.83 1:02.28 1:35.49 2:09.42 2:43.50 3:17.81 3:51.06 4:22.91                F             N61
D08SS      Wedderspoon, Layla          90007285    AGBR0126200817FF 1001409 UNOV11022025   56.70S   58.37S            57.14S 2 4 2 2  5  3  8.   3950100    NN73
G08SS          Wedderspoon, Layla          90007285    1 2  50C   28.61   58.37                                                                P             N17
G08SS          Wedderspoon, Layla          90007285    1 2  50C   27.65   57.14                                                                F             N07
D08SS      Weir, Mollie                1172083     AGBR0529200817FF 2001102 UNOV11012025 2:10.00S 2:11.47S                   3 6 0 0 11           9501      NN20
D31172083                                                                                                                                                    N38
G08SS          Weir, Mollie                1172083     1 4  50C   30.45 1:03.62 1:37.51 2:11.47                                                P             N16
D08SS      Weir, Mollie                1172083     AGBR0529200817FF 2002114 UNOV11012025 2:26.70S 2:28.54S                   2 6 0 0 12           9502      NN40
G08SS          Weir, Mollie                1172083     1 4  50C   35.50 1:12.93 1:50.62 2:28.54                                                P             N26
D08SS      Weir, Mollie                1172083     AGBR0529200817FF 8001202 UNOV11012025 9:37.80S                   9:39.69S     3 0     6  5.   6950100    NN70
G08SS          Weir, Mollie                1172083     116  50C   33.04 1:08.75 1:45.31 2:22.23 2:59.11 3:35.93 4:12.89 4:49.87 5:26.84 6:03.62F             N70
G08SS          Weir, Mollie                1172083     216  50C 6:40.22 7:16.32 7:52.86 8:28.94 9:04.84 9:39.69                                F             N28
D08SS      Weir, Mollie                1172083     AGBR0529200817FF 4001401 UNOV11022025 4:37.23S 4:37.13S          4:36.14S 4 2 1 1  7  6  5.   6950100    NN91
G08SS          Weir, Mollie                1172083     1 8  50C   31.83 1:06.34 1:41.51 2:16.85 2:52.15 3:27.30 4:02.47 4:37.13                P             N19
G08SS          Weir, Mollie                1172083     1 8  50C   31.45 1:05.96 1:41.08 2:16.77 2:52.32 3:26.85 4:01.35 4:36.14                F             N19
D08SS      Weir, Mollie                1172083     AGBR0529200817FF 1001409 UNOV11022025 1:00.30S 1:02.19S                   4 0 0 0 32           9501      NN30
G08SS          Weir, Mollie                1172083     1 2  50C   30.09 1:02.19                                                                P             N74
C18SS      SSUHIXHighland Swim Team            Highland        co Aquadome                                 Inverness           INIV3 5SS                     N37
D08SS      Allan, Freya                90035142    AGBR0810201312FF 2003533 UNOV11022025 3:07.61S 2:59.19S                   2 7      4           9503      NN10
D390035142                                                                                                                                                   N48
G08SS          Allan, Freya                90035142    1 4  50C   40.52 1:25.67 2:12.40 2:59.19                                                P             N26
D08SS      Allan, Freya                90035142    AGBR0810201312FF 1003108 UNOV11012025 1:27.30S 1:22.32S                   5 7 0 0 30           9503      NN20
G08SS          Allan, Freya                90035142    1 2  50C   39.37 1:22.32                                                                P             N74
D08SS      Allan, Freya                90035142    AGBR0810201312FF 2002114 UNOV11012025 2:42.39S 2:40.49S                   5 6 0 0 38           9502      NN30
G08SS          Allan, Freya                90035142    1 4  50C   37.11 1:17.56 1:58.99 2:40.49                                                P             N26
D08SS      Allan, Freya                90035142    AGBR0810201312FF  503403 UNOV11022025   37.87S   38.37S                   3 5 0 0 41           9503      NN89
D08SS      Allan, Freya                90035142    AGBR0810201312FF 2004405 UNOV11022025 3:04.34S 3:09.89S                   1 1 0 0 38           9504      NN30
G08SS          Allan, Freya                90035142    1 4  50C   39.61 1:24.28 2:16.07 3:09.89                                                P             N26
D08SS      Allan, Freya                90035142    AGBR0810201312FF 2003413 UNOV11022025 3:07.61S 2:59.19S                   6 7 0 0 35           9503      NN30
G08SS          Allan, Freya                90035142    1 4  50C   40.52 1:25.67 2:12.40 2:59.19                                                P             N26
D08SS      Armitage, Jed               1303106     AGBR1031200817MM 1002107 UNOV11012025   58.72S   58.68S            59.58S 4 3 2 7  6  7  4.   7950200    NN51
D31303106                                                                                                                                                    N38
G08SS          Armitage, Jed               1303106     1 2  50C   28.42   58.68                                                                P             N74
G08SS          Armitage, Jed               1303106     1 2  50C   28.76   59.58                                                                F             N74
D08SS      Armitage, Jed               1303106     AGBR1031200817MM  504111 UNOV11012025   26.40S   27.55S                   4 8 0 0 25           9504      NN00
D08SS      Armitage, Jed               1303106     AGBR1031200817MM 4005201 UNOV11012025 4:42.35S                   4:48.76S     5 1    14       99505      NN60
G08SS          Armitage, Jed               1303106     1 8  50C   29.87 1:04.80 1:43.59 2:20.45 3:03.53 3:46.90 4:18.72 4:48.76                F             N39
D08SS      Armitage, Jed               1303106     AGBR1031200817MM  502404 UNOV11022025   27.10S   27.59S                   4 3 0 0 11           9502      NN00
D08SS      Armitage, Jed               1303106     AGBR1031200817MM 2002414 UNOV11022025 2:09.00S 2:09.97S          2:09.89S 4 3 1 1  7  7  4.   7950200    NN12
G08SS          Armitage, Jed               1303106     1 4  50C   30.06 1:03.94 1:37.54 2:09.97                                                P             N46
G08SS          Armitage, Jed               1303106     1 4  50C   30.01 1:02.96 1:36.60 2:09.89                                                F             N36
D08SS      Armitage, Tom               1303107     AGBR0115200718MM 2001402 UNOV11022025 1:58.40S 2:02.04S                   3 2 0 0 24           9501      NN60
D31303107                                                                                                                                                    N38
G08SS          Armitage, Tom               1303107     1 4  50C   26.73   56.99 1:29.27 2:02.04                                                P             N36
D08SS      Armitage, Tom               1303107     AGBR0115200718MM  502404 UNOV11022025   28.14S   28.37S                   4 2 0 0 18           9502      NN20
D08SS      Armitage, Tom               1303107     AGBR0115200718MM  501412 UNOV11022025   24.75S   25.18S                   4 7 0 0 16           9501      NN20
D08SS      Armitage, Tom               1303107     AGBR0115200718MM 2002414 UNOV11022025 2:08.28S 2:17.64S                   2 5 0 0 13           9502      NN70
G08SS          Armitage, Tom               1303107     1 4  50C   30.31 1:04.59 1:41.04 2:17.64                                                P             N46
D08SS      Barber, Madi                90008480    AGBR1231200619FF  502104 UNOV11012025   30.90S   30.76S                   4 7 0 0 11           9502      NN69
D390008480                                                                                                                                                   N48
D08SS      Barber, Madi                90008480    AGBR1231200619FF  501112 UNOV11012025   28.59S   28.83S                   5 9 0 0 31           9501      NN79
D08SS      Barber, Madi                90008480    AGBR1231200619FF 2002114 UNOV11012025 2:29.63S 2:29.63S                   4 7 0 0 13           9502      NN20
G08SS          Barber, Madi                90008480    1 4  50C   33.68 1:11.56 1:51.56 2:29.63                                                P             N16
D08SS      Barber, Madi                90008480    AGBR1231200619FF 1002407 UNOV11022025 1:07.59S 1:07.54S          1:07.38S 2 2 2 0 12 10  1.   0950200    NN81
G08SS          Barber, Madi                90008480    1 2  50C   32.81 1:07.54                                                                P             N64
G08SS          Barber, Madi                90008480    1 2  50C   32.36 1:07.38                                                                F             N64
D08SS      Barber, Madi                90008480    AGBR1231200619FF  504411 UNOV11022025   31.48S   31.53S                   3 9 0 0 34           9504      NN79
D08SS      MacDougall, Emily           90011100    AGBR1113200916FF  502104 UNOV11012025   33.00S   32.67S            32.94S 2 5 1 0 26 20       09502      NN52
D390011100                                                                                                                                                   N48
D08SS      MacDougall, Emily           90011100    AGBR1113200916FF  501112 UNOV11012025   27.90S   27.88S            27.98S 7 8 1 5 13 12       29501      NN72
D08SS      MacDougall, Emily           90011100    AGBR1113200916FF 2002114 UNOV11012025 2:24.40S 2:23.91S          2:24.56S 4 6 1 2  5  8  3.   8950200    NN53
G08SS          MacDougall, Emily           90011100    1 4  50C   34.42 1:11.13 1:47.66 2:23.91                                                P             N97
G08SS          MacDougall, Emily           90011100    1 4  50C   34.28 1:11.45 1:48.33 2:24.56                                                F             N97
D08SS      MacDougall, Emily           90011100    AGBR1113200916FF 1002407 UNOV11022025 1:09.20S 1:08.52S          1:08.21S 4 8 1 6 15 14       49502      NN33
G08SS          MacDougall, Emily           90011100    1 2  50C   33.73 1:08.52                                                                P             N56
G08SS          MacDougall, Emily           90011100    1 2  50C   33.69 1:08.21                                                                F             N46
D08SS      MacDougall, Emily           90011100    AGBR1113200916FF 1001409 UNOV11022025 1:01.62S 1:02.52S                   1 1 0 0 37           9501      NN02
G08SS          MacDougall, Emily           90011100    1 2  50C   29.86 1:02.52                                                                P             N56
D08SS      Mills, Edward               90015080    AGBR1202200916MM 2004105 UNOV11012025 2:08.60S 2:09.13S          2:11.48S 3 5 1 3  3  5  6.   5950400    NN32
D390015080                                                                                                                                                   N48
G08SS          Mills, Edward               90015080    1 4  50C   28.57 1:01.54 1:36.73 2:09.13                                                P             N66
G08SS          Mills, Edward               90015080    1 4  50C   28.85 1:02.37 1:37.25 2:11.48                                                F             N66
D08SS      Mills, Edward               90015080    AGBR1202200916MM 1002107 UNOV11012025 1:03.25S 1:04.38S          1:09.29S 3 1 1 0 23 20       09502      NN02
G08SS          Mills, Edward               90015080    1 2  50C   31.02 1:04.38                                                                P             N15
G08SS          Mills, Edward               90015080    1 2  50C   33.42 1:09.29                                                                F             N15
D08SS      Mills, Edward               90015080    AGBR1202200916MM  504111 UNOV11012025   26.99S   27.58S            27.69S 4 9 1 2 26 15       59504      NN51
D08SS      Mills, Edward               90015080    AGBR1202200916MM 2005406 UNOV11022025 2:18.34S 2:23.10S                   2 7 0 0 36           9505      NN80
G08SS          Mills, Edward               90015080    1 4  50C   29.74 1:06.17 1:50.70 2:23.10                                                P             N66
D08SS      Mills, Edward               90015080    AGBR1202200916MM 1004410 UNOV11022025   58.70S 1:00.29S          1:00.32S 4 2 2 0 12  9  2.   9950400    NN12
G08SS          Mills, Edward               90015080    1 2  50C   28.19 1:00.29                                                                P             N25
G08SS          Mills, Edward               90015080    1 2  50C   28.24 1:00.32                                                                F             N15
D08SS      Mills, Edward               90015080    AGBR1202200916MM 2002414 UNOV11022025 2:17.28S 2:19.23S                   3 2 0 0 17           9502      NN80
G08SS          Mills, Edward               90015080    1 4  50C   32.94 1:08.86 1:44.55 2:19.23                                                P             N76
D08SS      Richards, Ethan             1643838     AGBR0420200916MM 1002107 UNOV11012025 1:10.53S 1:09.27S                   6 1 0 0 55           9502      NN51
D31643838                                                                                                                                                    N48
G08SS          Richards, Ethan             1643838     1 2  50C   33.07 1:09.27                                                                P             N85
D08SS      Richards, Ethan             1643838     AGBR0420200916MM 2002534 UNOV11022025 2:35.53S 2:32.39S                   1 6      8           9502      NN31
G08SS          Richards, Ethan             1643838     1 4  50C   36.09 1:14.75 1:54.82 2:32.39                                                P             N37
D08SS      Richards, Ethan             1643838     AGBR0420200916MM 1003528 UNOV11022025 1:20.43S 1:19.46S                   4 0     21           9503      NN31
G08SS          Richards, Ethan             1643838     1 2  50C   36.24 1:19.46                                                                P             N95
D08SS      Richards, Ethan             1643838     AGBR0420200916MM 1003408 UNOV11022025 1:20.43S 1:19.46S                   8 0 0 0 57           9503      NN51
G08SS          Richards, Ethan             1643838     1 2  50C   36.24 1:19.46                                                                P             N95
D08SS      Richards, Ethan             1643838     AGBR0420200916MM 2002414 UNOV11022025 2:35.53S 2:32.39S                   5 6 0 0 46           9502      NN61
G08SS          Richards, Ethan             1643838     1 4  50C   36.09 1:14.75 1:54.82 2:32.39                                                P             N37
D08SS      Robertson, Eva              90016563    AGBR0819200916FF 1001529 UNOV11022025 1:02.95S 1:04.19S                   4 6     16           9501      NN21
D390016563                                                                                                                                                   N48
G08SS          Robertson, Eva              90016563    1 2  50C   30.59 1:04.19                                                                P             N75
D08SS      Robertson, Eva              90016563    AGBR0819200916FF 2005106 UNOV11012025 2:31.91S 2:37.36S                   4 1 0 0 31           9505      NN41
G08SS          Robertson, Eva              90016563    1 4  50C   33.74 1:13.42 2:00.11 2:37.36                                                P             N17
D08SS      Robertson, Eva              90016563    AGBR0819200916FF 1003108 UNOV11012025 1:15.86S 1:22.28S                   2 3 0 0 29           9503      NN41
G08SS          Robertson, Eva              90016563    1 2  50C   38.02 1:22.28                                                                P             N75
D08SS      Robertson, Eva              90016563    AGBR0819200916FF  501112 UNOV11012025   29.50S   30.02S                   2 6 0 0 56           9501      NN80
D08SS      Robertson, Eva              90016563    AGBR0819200916FF  503403 UNOV11022025   34.90S   35.61S            36.01S 6 7 1 3 15 14       49503      NN91
D08SS      Robertson, Eva              90016563    AGBR0819200916FF 2003413 UNOV11022025 2:44.55S 2:49.51S                   2 6 0 0 15           9503      NN41
G08SS          Robertson, Eva              90016563    1 4  50C   38.20 1:20.07 2:04.35 2:49.51                                                P             N17
D08SS      Robertson, Eva              90016563    AGBR0819200916FF 1001409 UNOV11022025 1:02.95S 1:04.19S                   8 6 0 0 47           9501      NN41
G08SS          Robertson, Eva              90016563    1 2  50C   30.59 1:04.19                                                                P             N75
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM 4001101 UNOV11012025 4:21.50S 4:18.78S                   4 9 0 0 13           9501      NN21
D390009686                                                                                                                                                   N58
G08SS          Senguler, Nebi              90009686    1 8  50C   28.24 1:00.32 1:33.43 2:06.71 2:41.03 3:13.64 3:46.58 4:18.78                P             N00
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM  503103 UNOV11012025   32.72S   32.63S            32.06S 4 8 1 7 27 24       49503      NN81
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM 1001109 UNOV11012025   52.90S   53.50S            54.01S 3 6 2 0  9 10  1.   0950100    NN02
G08SS          Senguler, Nebi              90009686    1 2  50C   25.73   53.50                                                                P             N45
G08SS          Senguler, Nebi              90009686    1 2  50C   25.75   54.01                                                                F             N35
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM  504111 UNOV11012025   24.70S   26.13S            26.92S 5 3 2 1  7  9  2.   9950400    NN02
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM 2001402 UNOV11022025 1:57.80S 1:58.42S          1:57.45S 2 3 1 1  8  7  4.   7950100    NN82
G08SS          Senguler, Nebi              90009686    1 4  50C   26.79   57.28 1:28.19 1:58.42                                                P             N07
G08SS          Senguler, Nebi              90009686    1 4  50C   26.74   57.02 1:27.99 1:57.45                                                F             N96
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM  502404 UNOV11022025   28.30S   28.69S               DQS 6 1 1 6 20  0       09502      NN61
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM 1004410 UNOV11022025   56.70S 1:00.86S            59.12S 2 3 1 5 15 11       19504      NN12
G08SS          Senguler, Nebi              90009686    1 2  50C   27.62 1:00.86                                                                P             N65
G08SS          Senguler, Nebi              90009686    1 2  50C   27.98   59.12                                                                F             N45
D08SS      Senguler, Nebi              90009686    AGBR0123201015MM  501412 UNOV11022025   23.30S   25.35S            24.94S 5 5 1 6 20 13       39501      NN71
D08SS      Smith, Lucy                 90034066    AGBR0219201015FF 2003533 UNOV11022025 3:02.46S 3:08.08S                   1 5     11           9503      NN00
D390034066                                                                                                                                                   N48
G08SS          Smith, Lucy                 90034066    1 4  50C   41.52 1:29.14 2:19.72 3:08.08                                                P             N06
D08SS      Smith, Lucy                 90034066    AGBR0219201015FF  503403 UNOV11022025   38.46S   39.18S                   2 6 0 0 51           9503      NN79
D08SS      Smith, Lucy                 90034066    AGBR0219201015FF 2003413 UNOV11022025 3:02.46S 3:08.08S                   5 5 0 0 47           9503      NN20
G08SS          Smith, Lucy                 90034066    1 4  50C   41.52 1:29.14 2:19.72 3:08.08                                                P             N06
D08SS      Sutherland, Katelin         90028736    AGBR0322201213FF 1004110 UNOV11012025 1:12.84S 1:12.85S                   5 5 0 0 36           9504      NN23
D390028736                                                                                                                                                   N58
G08SS          Sutherland, Katelin         90028736    1 2  50C   33.85 1:12.85                                                                P             N77
D08SS      Sutherland, Katelin         90028736    AGBR0322201213FF 2005106 UNOV11012025 2:39.31S 2:42.24S                   1 7 0 0 43           9505      NN23
G08SS          Sutherland, Katelin         90028736    1 4  50C   34.13 1:14.77 2:04.53 2:42.24                                                P             N19
D08SS      Sutherland, Katelin         90028736    AGBR0322201213FF 1002407 UNOV11022025 1:13.50S 1:14.32S                   1 0 0 0 35           9502      NN13
G08SS          Sutherland, Katelin         90028736    1 2  50C   35.99 1:14.32                                                                P             N77
D08SS      Sutherland, Katelin         90028736    AGBR0322201213FF 4005501 UNOV11022025 5:41.42S                   5:39.23S     2 2    29       69505      NN23
G08SS          Sutherland, Katelin         90028736    1 8  50C   35.74 1:14.25 1:57.25 2:40.38 3:31.82 4:23.10 5:02.27 5:39.23                F             N91
D08SS      Vass, Fraser                90028604    AGBR1214201114MM 1002107 UNOV11012025 1:03.80S 1:03.63S          1:02.53S 3 8 1 7 18 13       39502      NN81
D390028604                                                                                                                                                   N48
G08SS          Vass, Fraser                90028604    1 2  50C   30.37 1:03.63                                                                P             N94
G08SS          Vass, Fraser                90028604    1 2  50C   30.37 1:02.53                                                                F             N84
D08SS      Vass, Fraser                90028604    AGBR1214201114MM  502404 UNOV11022025   29.10S   28.87S            28.66S 4 8 1 7 22 16       69502      NN21
D08SS      Vass, Fraser                90028604    AGBR1214201114MM 2002414 UNOV11022025 2:21.68S 2:17.06S                   4 0 0 0 12           9502      NN50
G08SS          Vass, Fraser                90028604    1 4  50C   31.35 1:06.99 1:43.01 2:17.06                                                P             N36
D08SS      Vass, Fraser                90028604    AGBR1214201114MM 1001109 UNOV11012025   58.40S   56.56S                   6 7 0 0 36           9501      NN10
G08SS          Vass, Fraser                90028604    1 2  50C   27.29   56.56                                                                P             N74
D08SS      Waller, Esme                90020318    AGBR0922201015FF 2001102 UNOV11012025 2:16.10S 2:16.58S                   1 6 0 0 27           9501      NN30
D390020318                                                                                                                                                   N48
G08SS          Waller, Esme                90020318    1 4  50C   31.68 1:06.06 1:41.38 2:16.58                                                P             N36
D08SS      Waller, Esme                90020318    AGBR0922201015FF 8001202 UNOV11012025 9:52.60S                   9:43.76S     2 7    11       49501      NN40
G08SS          Waller, Esme                90020318    116  50C   32.85 1:09.66 1:46.55 2:24.14 3:01.98 3:39.17 4:16.30 4:53.59 5:30.95 6:08.43F             N80
G08SS          Waller, Esme                90020318    216  50C 6:45.96 7:22.48 7:58.95 8:34.78 9:09.98 9:43.76                                F             N48
D08SS      Waller, Esme                90020318    AGBR0922201015FF 4001401 UNOV11022025 4:44.20S 4:49.93S                   3 8 0 0 19           9501      NN40
G08SS          Waller, Esme                90020318    1 8  50C   33.11 1:09.55 1:46.87 2:24.00 3:01.18 3:37.80 4:14.29 4:49.93                P             N29
D08SS      Waller, Esme                90020318    AGBR0922201015FF 2004405 UNOV11022025 2:37.82S 2:44.04S                   4 1 0 0 22           9504      NN40
G08SS          Waller, Esme                90020318    1 4  50C   36.36 1:18.05 2:02.24 2:44.04                                                P             N26
D08SS      Waller, Esme                90020318    AGBR0922201015FF 4005501 UNOV11022025 5:29.79S                   5:28.03S     3 6    21       49505      NN40
G08SS          Waller, Esme                90020318    1 8  50C   36.62 1:17.75 2:00.46 2:40.73 3:29.36 4:17.90 4:53.37 5:28.03                F             N29
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 4001101 UNOV11012025 4:09.26S 4:13.01S          4:13.63S 3 3 1 7  6  7  4.   7950100    NN93
D390011156                                                                                                                                                   N48
G08SS          Williamson, Aiden           90011156    1 8  50C   28.20   59.33 1:31.42 2:03.67 2:36.24 3:09.16 3:41.93 4:13.01                P             N80
G08SS          Williamson, Aiden           90011156    1 8  50C   28.39   59.17 1:31.14 2:03.77 2:36.28 3:08.56 3:41.44 4:13.63                F             N90
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 2004105 UNOV11012025 2:17.65S 2:18.79S                   3 6 0 0 12           9504      NN52
G08SS          Williamson, Aiden           90011156    1 4  50C   30.95 1:05.42 1:41.74 2:18.79                                                P             N28
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 2003113 UNOV11012025 2:26.82S 2:31.40S                   2 6 0 0 14           9503      NN42
G08SS          Williamson, Aiden           90011156    1 4  50C   35.09 1:13.70 1:52.85 2:31.40                                                P             N18
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 4005201 UNOV11012025 4:43.69S                   4:47.40S     5 8    12       89505      NN42
G08SS          Williamson, Aiden           90011156    1 8  50C   30.23 1:06.47 1:46.43 2:24.96 3:03.51 3:43.04 4:16.35 4:47.40                F             N01
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 2001402 UNOV11022025 1:58.00S 1:58.86S          2:01.50S 4 2 1 0 10  9  2.   9950100    NN93
G08SS          Williamson, Aiden           90011156    1 4  50C   27.29   57.70 1:28.55 1:58.86                                                P             N18
G08SS          Williamson, Aiden           90011156    1 4  50C   27.51   58.15 1:30.04 2:01.50                                                F             N87
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 1003408 UNOV11022025 1:08.23S 1:08.52S                   4 2 0 0 13           9503      NN42
G08SS          Williamson, Aiden           90011156    1 2  50C   32.00 1:08.52                                                                P             N76
D08SS      Williamson, Aiden           90011156    AGBR0722200817MM 1004410 UNOV11022025 1:02.67S 1:01.18S                   1 3 0 0 19           9504      NN42
G08SS          Williamson, Aiden           90011156    1 2  50C   28.18 1:01.18                                                                P             N76
E08SS      ASSUHIX  X 2006301 UNOV  011012025 1:46.40S                   1:47.04S     2 9     9                                                8N13001  X    N26
F08SS          SSUHIXASenguler, Nebi              90009686    GBR0123201015M  1             90009686                                                         N18
G08SS          Senguler, Nebi              90009686    1 4  50C   24.89                                                                        F             N94
F08SS          SSUHIXAMacDougall, Emily           90011100    GBR1113200916F  2             90011100                                                         N88
G08SS          MacDougall, Emily           90011100    1 4  50C   54.25                                                                        F             N75
F08SS          SSUHIXABarber, Madi                90008480    GBR1231200619F  3             90008480                                                         N07
G08SS          Barber, Madi                90008480    1 4  50C 1:22.31                                                                        F             N04
F08SS          SSUHIXAArmitage, Jed               1303106     GBR1031200817M  4             1303106                                                          N27
G08SS          Armitage, Jed               1303106     1 4  50C 1:47.04                                                                        F             N44
E08SS      BSSUHIX  X 2006301 UNOV  011012025 1:49.92S                   1:50.10S     1 6    14                                                4N13001  X    N36
F08SS          SSUHIXBRobertson, Eva              90016563    GBR0819200916F  1             90016563                                                         N28
G08SS          Robertson, Eva              90016563    1 4  50C   29.74                                                                        F             N05
F08SS          SSUHIXBWaller, Esme                90020318    GBR0922201015F  2             90020318                                                         N27
G08SS          Waller, Esme                90020318    1 4  50C   58.86                                                                        F             N14
F08SS          SSUHIXBVass, Fraser                90028604    GBR1214201114M  3             90028604                                                         N37
G08SS          Vass, Fraser                90028604    1 4  50C 1:24.89                                                                        F             N44
F08SS          SSUHIXBWilliamson, Aiden           90011156    GBR0722200817M  4             90011156                                                         N29
G08SS          Williamson, Aiden           90011156    1 4  50C 1:50.10                                                                        F             N16
E08SS      ASSUHIX  X 2007601 UNOV  011022025 1:57.10S                        DQS     2 0     0                                                0N13005  X    N95
F08SS          SSUHIXABarber, Madi                90008480    GBR1231200619F  1             90008480                                                         N07
G08SS          Barber, Madi                90008480    1 4  50C                                                                                F             N43
F08SS          SSUHIXAWilliamson, Aiden           90011156    GBR0722200817M  2             90011156                                                         N29
G08SS          Williamson, Aiden           90011156    1 4  50C                                                                                F             N55
F08SS          SSUHIXASenguler, Nebi              90009686    GBR0123201015M  3             90009686                                                         N18
G08SS          Senguler, Nebi              90009686    1 4  50C                                                                                F             N44
F08SS          SSUHIXAMacDougall, Emily           90011100    GBR1113200916F  4             90011100                                                         N88
G08SS          MacDougall, Emily           90011100    1 4  50C                                                                                F             N25
C18          NHYXHuntly Asc                    Huntly          Liz Bassindale        1 Hermit Seat, AuchlevInsch                 AB52 6QZ  GBR               N39
D08        Bassindale, Lauren          90037700    A   1019201114FF 1003108 UNOV11012025 1:23.78S 1:21.46S                   1 8 0 0 25           9503      NN41
D390037700                                                                                                                                                   N48
G08            Bassindale, Lauren          90037700    1 2  50C   38.37 1:21.46                                                                P             N56
D08        Bassindale, Lauren          90037700    A   1019201114FF  503403 UNOV11022025   37.46S   36.25S            36.58S 4 8 1 2 18 19       99503      NN12
D08        Bassindale, Lauren          90037700    A   1019201114FF  504411 UNOV11022025   31.81S   31.41S                   2 3 0 0 31           9504      NN80
D08        Bassindale, Lauren          90037700    A   1019201114FF 2003533 UNOV11022025 3:01.55S 2:53.80S                   2 4      1           9503      NN21
G08            Bassindale, Lauren          90037700    1 4  50C   38.94 1:23.38 2:08.91 2:53.80                                                P             N08
D08        Bassindale, Lauren          90037700    A   1019201114FF 1004110 UNOV11012025 1:16.67S 1:15.02S                   7 7 0 0 47           9504      NN41
G08            Bassindale, Lauren          90037700    1 2  50C   35.00 1:15.02                                                                P             N46
D08        Bassindale, Lauren          90037700    A   1019201114FF 2005106 UNOV11012025 2:44.69S 2:40.59S                   6 7 0 0 37           9505      NN61
G08            Bassindale, Lauren          90037700    1 4  50C   33.58 1:15.05 2:00.95 2:40.59                                                P             N08
D08        Bassindale, Lauren          90037700    A   1019201114FF 2003413 UNOV11022025 3:01.55S 2:53.80S                   6 4 0 0 25           9503      NN41
G08            Bassindale, Lauren          90037700    1 4  50C   38.94 1:23.38 2:08.91 2:53.80                                                P             N08
D08        Proctor, Samantha           90019729    A   0917200916FF 2003533 UNOV11022025 3:02.68S 3:02.80S                   1 3      7           9503      NN11
D390019729      Sam                                                                                                                                          N59
G08            Proctor, Samantha           90019729    1 4  50C   40.66 1:27.15 2:15.24 3:02.80                                                P             N87
D08        Proctor, Samantha           90019729    A   0917200916FF  502104 UNOV11012025   33.98S   34.40S                   2 0 0 0 36           9502      NN80
D08        Proctor, Samantha           90019729    A   0917200916FF 2002114 UNOV11012025 2:41.35S 2:43.58S                   1 0 0 0 42           9502      NN31
G08            Proctor, Samantha           90019729    1 4  50C   38.97 1:20.91 2:02.90 2:43.58                                                P             N97
D08        Proctor, Samantha           90019729    A   0917200916FF  503403 UNOV11022025   37.47S   38.09S                   4 0 0 0 37           9503      NN90
D08        Proctor, Samantha           90019729    A   0917200916FF 1003108 UNOV11012025 1:25.16S 1:23.50S                   5 4 0 0 37           9503      NN31
G08            Proctor, Samantha           90019729    1 2  50C   39.10 1:23.50                                                                P             N36
D08        Proctor, Samantha           90019729    A   0917200916FF 2003413 UNOV11022025 3:02.68S 3:02.80S                   5 3 0 0 43           9503      NN41
G08            Proctor, Samantha           90019729    1 4  50C   40.66 1:27.15 2:15.24 3:02.80                                                P             N87
C18          NLKXLerwick Asc                   Lerwick         Laehann Johnson       Karingal, Lower HIllsiGulberwick            ZE2 9Jx   GBR               N82
D08        Adamson, Jenny              90030153    A   1102201015FF 2005106 UNOV11012025 2:41.82S 2:42.24S                   5 3 0 0 43           9505      NN99
D390030153                                                                                                                                                   N48
G08            Adamson, Jenny              90030153    1 4  50C   35.48 1:17.93 2:06.46 2:42.24                                                P             N56
D08        Adamson, Jenny              90030153    A   1102201015FF 1001529 UNOV11022025 1:04.25S 1:05.85S                   2 0     29           9501      NN79
G08            Adamson, Jenny              90030153    1 2  50C   30.72 1:05.85                                                                P             N05
D08        Adamson, Jenny              90030153    A   1102201015FF  502104 UNOV11012025   33.43S   34.09S                   2 7 0 0 34           9502      NN49
D08        Adamson, Jenny              90030153    A   1102201015FF  501112 UNOV11012025   28.62S   29.84S                   4 3 0 0 54           9501      NN49
D08        Adamson, Jenny              90030153    A   1102201015FF 2002114 UNOV11012025 2:37.47S 2:36.42S                   1 4 0 0 26           9502      NN99
G08            Adamson, Jenny              90030153    1 4  50C   36.07 1:16.11 1:56.62 2:36.42                                                P             N56
D08        Adamson, Jenny              90030153    A   1102201015FF  503403 UNOV11022025   39.35S   39.26S                   2 9 0 0 52           9503      NN49
D08        Adamson, Jenny              90030153    A   1102201015FF 1002407 UNOV11022025 1:12.69S 1:15.92S                   3 9 0 0 42           9502      NN99
G08            Adamson, Jenny              90030153    1 2  50C   35.83 1:15.92                                                                P             N15
D08        Adamson, Jenny              90030153    A   1102201015FF  504411 UNOV11022025   31.55S   32.22S                   2 5 0 0 43           9504      NN39
D08        Adamson, Jenny              90030153    A   1102201015FF 1001409 UNOV11022025 1:04.25S 1:05.85S                   6 0 0 0 62           9501      NN99
G08            Adamson, Jenny              90030153    1 2  50C   30.72 1:05.85                                                                P             N05
D08        Geddes, Carys               90013402    A   1231200916FF 1004110 UNOV11012025 1:13.61S 1:14.64S                   7 3 0 0 43           9504      NN49
D390013402                                                                                                                                                   N48
G08            Geddes, Carys               90013402    1 2  50C   34.77 1:14.64                                                                P             N64
D08        Geddes, Carys               90013402    A   1231200916FF 2004405 UNOV11022025 2:48.29S      DQS                   4 9 0 0  0           9504      NN29
G08            Geddes, Carys               90013402    1 4  50C                                                                                P             N43
D08        Geddes, Carys               90013402    A   1231200916FF 4005501 UNOV11022025 5:50.97S                   6:01.33S     1 5    37       29505      NN59
G08            Geddes, Carys               90013402    1 8  50C   36.97 1:19.70 2:04.42 2:48.99 3:41.99 4:35.01 5:18.66 6:01.33                F             N09
D08        Redfern, Archie             90018124    A   0717201015MM 4001101 UNOV11012025 4:55.98S 4:49.90S                   5 3 0 0 41           9501      NN40
D390018124                                                                                                                                                   N48
G08            Redfern, Archie             90018124    1 8  50C   32.62 1:09.21 1:46.36 2:23.50 3:00.55 3:37.43 4:14.16 4:49.90                P             N69
D08        Redfern, Archie             90018124    A   0717201015MM 1003528 UNOV11022025 1:16.85S 1:17.15S                   3 3     13           9503      NN10
G08            Redfern, Archie             90018124    1 2  50C   36.86 1:17.15                                                                P             N35
D08        Redfern, Archie             90018124    A   0717201015MM 2005526 UNOV11022025 2:35.52S 2:34.13S                   1 9     26           9505      NN20
G08            Redfern, Archie             90018124    1 4  50C   32.73 1:13.55 1:56.97 2:34.13                                                P             N86
D08        Redfern, Archie             90018124    A   0717201015MM 2004105 UNOV11012025 2:46.61S 2:41.12S                   5 4 0 0 39           9504      NN30
G08            Redfern, Archie             90018124    1 4  50C   35.81 1:17.02 1:59.20 2:41.12                                                P             N76
D08        Redfern, Archie             90018124    A   0717201015MM 2003113 UNOV11012025 2:43.63S 2:44.10S                   1 1 0 0 42           9503      NN20
G08            Redfern, Archie             90018124    1 4  50C   37.20 1:18.52 2:01.83 2:44.10                                                P             N76
D08        Redfern, Archie             90018124    A   0717201015MM 4005201 UNOV11012025 5:20.80S                   5:19.71S     1 5    40       49505      NN20
G08            Redfern, Archie             90018124    1 8  50C   34.00 1:13.20 1:56.69 2:38.63 3:21.52 4:06.51 4:43.31 5:19.71                F             N69
D08        Redfern, Archie             90018124    A   0717201015MM 2005406 UNOV11022025 2:35.52S 2:34.13S                   5 9 0 0 64           9505      NN40
G08            Redfern, Archie             90018124    1 4  50C   32.73 1:13.55 1:56.97 2:34.13                                                P             N86
D08        Redfern, Archie             90018124    A   0717201015MM 1003408 UNOV11022025 1:16.85S 1:17.15S                   7 3 0 0 49           9503      NN40
G08            Redfern, Archie             90018124    1 2  50C   36.86 1:17.15                                                                P             N35
D08        Williamson, Thea            90020260    A   0823201015FF 1004110 UNOV11012025 1:18.17S 1:20.55S                   5 1 0 0 53           9504      NN70
D390020260                                                                                                                                                   N48
G08            Williamson, Thea            90020260    1 2  50C   36.61 1:20.55                                                                P             N85
D08        Williamson, Thea            90020260    A   0823201015FF 2005106 UNOV11012025 2:45.25S 2:50.40S                   6 1 0 0 51           9505      NN70
G08            Williamson, Thea            90020260    1 4  50C   35.87 1:20.35 2:11.00 2:50.40                                                P             N27
D08        Williamson, Thea            90020260    A   0823201015FF 2001102 UNOV11012025 2:22.67S 2:23.70S                   5 7 0 0 46           9501      NN70
G08            Williamson, Thea            90020260    1 4  50C   32.95 1:09.62 1:47.42 2:23.70                                                P             N37
D08        Williamson, Thea            90020260    A   0823201015FF 4001401 UNOV11022025 4:57.40S 5:09.66S                   1 4 0 0 37           9501      NN80
G08            Williamson, Thea            90020260    1 8  50C   34.32 1:12.65 1:52.68 2:31.61 3:11.61 3:51.17 4:30.64 5:09.66                P             N20
C18SS      SSMMLXMenzieshill Whitehall SwimmingMenzieshill     1 Drummond Street                           Dundee              DuDD3 6LL                     N04
D08SS      Allan, Brody                90030228    AGBR0914201213MM 2004105 UNOV11012025 3:02.84S 2:52.77S                   5 0 0 0 45           9504      NN40
D390030228                                                                                                                                                   N48
G08SS          Allan, Brody                90030228    1 4  50C   36.72 1:21.33 2:09.11 2:52.77                                                P             N26
D08SS      Bryden, India-Leoni         1101417     AGBR1031200718FF  503403 UNOV11022025   36.99S   37.20S                   4 6 0 0 33           9503      NN91
D31101417                                                                                                                                                    N38
D08SS      Bryden, India-Leoni         1101417     AGBR1031200718FF 1001409 UNOV11022025   59.60S 1:00.77S                   4 7 0 0 17           9501      NN22
G08SS          Bryden, India-Leoni         1101417     1 2  50C   29.22 1:00.77                                                                P             N86
D08SS      Bryden, India-Leoni         1101417     AGBR1031200718FF  504411 UNOV11022025   29.80S   31.21S                   7 9 0 0 27           9504      NN91
D08SS      Carver, Nico                90048651    AGBR1230201114MM 2005526 UNOV11022025 2:33.46S 2:31.83S                   2 0     24           9505      NN30
D390048651                                                                                                                                                   N58
G08SS          Carver, Nico                90048651    1 4  50C   31.96 1:14.68 1:56.94 2:31.83                                                P             N36
D08SS      Carver, Nico                90048651    AGBR1230201114MM 2003113 UNOV11012025 2:44.50S 2:44.53S                   8 4 0 0 44           9503      NN40
G08SS          Carver, Nico                90048651    1 4  50C   36.85 1:19.20 2:02.37 2:44.53                                                P             N36
D08SS      Carver, Nico                90048651    AGBR1230201114MM  503103 UNOV11012025   33.20S   34.23S                   3 7 0 0 51           9503      NN89
D08SS      Carver, Nico                90048651    AGBR1230201114MM 1003408 UNOV11022025 1:14.00S 1:13.99S                   1 7 0 0 37           9503      NN40
G08SS          Carver, Nico                90048651    1 2  50C   35.00 1:13.99                                                                P             N84
D08SS      Carver, Nico                90048651    AGBR1230201114MM 2005406 UNOV11022025 2:33.46S 2:31.83S                   6 0 0 0 62           9505      NN50
G08SS          Carver, Nico                90048651    1 4  50C   31.96 1:14.68 1:56.94 2:31.83                                                P             N36
D08SS      Grubb, Mollie               90026867    AGBR0624201114FF 2002114 UNOV11012025 2:42.36S 2:35.44S                   5 3 0 0 22           9502      NN80
D390026867                                                                                                                                                   N58
G08SS          Grubb, Mollie               90026867    1 4  50C   36.81 1:16.06 1:56.15 2:35.44                                                P             N76
D08SS      Grubb, Mollie               90026867    AGBR0624201114FF 1004110 UNOV11012025 1:16.60S 1:14.95S                   6 2 0 0 45           9504      NN80
G08SS          Grubb, Mollie               90026867    1 2  50C   35.55 1:14.95                                                                P             N35
D08SS      Grubb, Mollie               90026867    AGBR0624201114FF 1002407 UNOV11022025 1:12.82S 1:11.77S          1:11.18S 2 9 1 8 25 18       89502      NN12
G08SS          Grubb, Mollie               90026867    1 2  50C   34.85 1:11.77                                                                P             N25
G08SS          Grubb, Mollie               90026867    1 2  50C   34.64 1:11.18                                                                F             N25
D08SS      Leisegang, Mathew           90038072    AGBR0318200916MM  503103 UNOV11012025   32.50S   33.00S                   4 7 0 0 35           9503      NN81
D390038072                                                                                                                                                   N48
D08SS      Leisegang, Mathew           90038072    AGBR0318200916MM 2003113 UNOV11012025 2:41.80S 2:40.36S                   1 2 0 0 30           9503      NN32
G08SS          Leisegang, Mathew           90038072    1 4  50C   34.42 1:13.67 1:56.68 2:40.36                                                P             N28
D08SS      Mann, Ksenia                90022269    AGBR0507201015FF 1001529 UNOV11022025 1:03.70S 1:02.24S                   3 7      7           9501      NN00
D390022269                                                                                                                                                   N48
G08SS          Mann, Ksenia                90022269    1 2  50C   29.81 1:02.24                                                                P             N74
D08SS      Mann, Ksenia                90022269    AGBR0507201015FF 2005106 UNOV11012025 2:36.01S 2:29.07S                   1 5 0 0 13           9505      NN30
G08SS          Mann, Ksenia                90022269    1 4  50C   30.82 1:10.77 1:53.95 2:29.07                                                P             N26
D08SS      Mann, Ksenia                90022269    AGBR0507201015FF 1003108 UNOV11012025 1:17.58S 1:17.32S          1:15.28S 2 7 2 0  9  7  4.   7950300    NN91
G08SS          Mann, Ksenia                90022269    1 2  50C   36.63 1:17.32                                                                P             N84
G08SS          Mann, Ksenia                90022269    1 2  50C   34.98 1:15.28                                                                F             N84
D08SS      Mann, Ksenia                90022269    AGBR0507201015FF 2004405 UNOV11022025 2:35.25S      DQS                   3 7 0 0  0           9504      NN00
G08SS          Mann, Ksenia                90022269    1 4  50C                                                                                P             N63
D08SS      Mann, Ksenia                90022269    AGBR0507201015FF 1001409 UNOV11022025 1:03.70S 1:02.24S                   7 7 0 0 33           9501      NN30
G08SS          Mann, Ksenia                90022269    1 2  50C   29.81 1:02.24                                                                P             N74
D08SS      McIntosh, Reilly            1289535     AGBR0307200916FF  502104 UNOV11012025   33.30S   32.53S            32.24S 2 3 1 8 24 18       89502      NN42
D31289535                                                                                                                                                    N48
D08SS      McIntosh, Reilly            1289535     AGBR0307200916FF 1004110 UNOV11012025 1:09.92S 1:09.55S          1:08.72S 1 6 1 2 21 17       79504      NN23
G08SS          McIntosh, Reilly            1289535     1 2  50C   32.71 1:09.55                                                                P             N36
G08SS          McIntosh, Reilly            1289535     1 2  50C   31.56 1:08.72                                                                F             N36
D08SS      McIntosh, Reilly            1289535     AGBR0307200916FF 1002407 UNOV11022025 1:13.27S 1:09.61S          1:10.20S 1 2 1 1 19 17       79502      NN13
G08SS          McIntosh, Reilly            1289535     1 2  50C   32.80 1:09.61                                                                P             N36
G08SS          McIntosh, Reilly            1289535     1 2  50C   33.27 1:10.20                                                                F             N26
D08SS      McIntosh, Reilly            1289535     AGBR0307200916FF  504411 UNOV11022025   30.75S   31.53S                   3 6 0 0 34           9504      NN41
D08SS      Mocci, Christopher          90012032    AGBR1011200817MM 1002107 UNOV11012025 1:07.56S 1:07.39S                   6 3 0 0 43           9502      NN82
D390012032                                                                                                                                                   N48
G08SS          Mocci, Christopher          90012032    1 2  50C   33.09 1:07.39                                                                P             N27
D08SS      Mocci, Christopher          90012032    AGBR1011200817MM  502404 UNOV11022025   30.21S   30.81S                   3 1 0 0 44           9502      NN22
D08SS      Mocci, Christopher          90012032    AGBR1011200817MM  501412 UNOV11022025   26.40S   26.18S                   2 9 0 0 36           9501      NN32
D08SS      Primrose, William           1238645     AGBR1202200916MM  502404 UNOV11022025   31.11S   31.23S                   2 8 0 0 48           9502      NN91
D31238645                                                                                                                                                    N48
D08SS      Primrose, William           1238645     AGBR1202200916MM 2002414 UNOV11022025 2:23.21S 2:22.91S                   3 9 0 0 27           9502      NN52
G08SS          Primrose, William           1238645     1 4  50C   33.19 1:09.84 1:46.91 2:22.91                                                P             N38
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM 2003113 UNOV11012025 2:48.60S 2:42.92S                   7 6 0 0 39           9503      NN92
D390022258                                                                                                                                                   N48
G08SS          Robertson, Thomas A         90022258    1 4  50C   36.69 1:19.24 2:01.37 2:42.92                                                P             N68
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM 1001109 UNOV11012025   56.70S   56.76S                   5 5 0 0 39           9501      NN52
G08SS          Robertson, Thomas A         90022258    1 2  50C   27.41   56.76                                                                P             N07
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM 2005526 UNOV11022025 2:25.53S 2:25.43S                   2 5      7           9505      NN62
G08SS          Robertson, Thomas A         90022258    1 4  50C   29.90 1:09.61 1:51.99 2:25.43                                                P             N78
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM  503103 UNOV11012025   32.50S   33.04S                   4 2 0 0 38           9503      NN22
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM 1003408 UNOV11022025 1:13.02S 1:13.64S                   2 9 0 0 34           9503      NN82
G08SS          Robertson, Thomas A         90022258    1 2  50C   33.77 1:13.64                                                                P             N27
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM  501412 UNOV11022025   25.10S   26.19S                   4 0 0 0 37           9501      NN32
D08SS      Robertson, Thomas A         90022258    AGBR0219200916MM 2005406 UNOV11022025 2:25.53S 2:25.43S                   6 5 0 0 44           9505      NN92
G08SS          Robertson, Thomas A         90022258    1 4  50C   29.90 1:09.61 1:51.99 2:25.43                                                P             N78
C18          MMHXMonifieth Swim Club           Monifieth       Fiona Thompson                                                              GBR               N93
D08        Carnegie, Ellie             90026052    A   0518201114FF  502104 UNOV11012025   34.20S   33.49S                   1 3 0 0 33           9502      NN69
D390026052                                                                                                                                                   N48
D08        Carnegie, Ellie             90026052    A   0518201114FF  501112 UNOV11012025   29.90S   31.18S                   2 9 0 0 65           9501      NN69
D08        Carnegie, Ellie             90026052    A   0518201114FF 2002114 UNOV11012025 2:34.90S 2:39.42S                   3 9 0 0 35           9502      NN20
G08            Carnegie, Ellie             90026052    1 4  50C   36.61 1:17.38 1:59.16 2:39.42                                                P             N76
D08        Carnegie, Ellie             90026052    A   0518201114FF 8001202 UNOV1101202510:11.91S                  10:23.19S     1 2    24       69501      NN20
G08            Carnegie, Ellie             90026052    116  50C   34.23 1:13.20 1:52.18 2:31.41 3:10.93 3:49.90 4:29.14 5:08.49 5:48.01 6:27.79F             N11
G08            Carnegie, Ellie             90026052    216  50C 7:07.68 7:47.36 8:26.97 9:06.01 9:45.5410:23.19                                F             N78
D08        Carnegie, Ellie             90026052    A   0518201114FF 4001401 UNOV11022025 4:56.90S 5:11.14S                   2 9 0 0 38           9501      NN20
G08            Carnegie, Ellie             90026052    1 8  50C   33.28 1:11.95 1:51.94 2:31.84 3:12.23 3:52.55 4:32.77 5:11.14                P             N69
D08        Carnegie, Ellie             90026052    A   0518201114FF 1002407 UNOV11022025 1:13.40S 1:15.49S                   1 1 0 0 40           9502      NN10
G08            Carnegie, Ellie             90026052    1 2  50C   36.31 1:15.49                                                                P             N25
D08        Cooper, Finlay              90031743    A   0604201015MM 1002107 UNOV11012025 1:10.01S 1:10.84S                   8 1 0 0 61           9502      NN00
D390031743                                                                                                                                                   N48
G08            Cooper, Finlay              90031743    1 2  50C   34.31 1:10.84                                                                P             N05
D08        Falconer, Sadie             90001092    A   1218200916FF 8001202 UNOV11012025 9:37.26S                   9:50.21S     3 8    14       89501      NN20
D390001092                                                                                                                                                   N48
G08            Falconer, Sadie             90001092    116  50C   32.06 1:07.13 1:43.23 2:19.87 2:56.66 3:34.29 4:11.54 4:48.74 5:26.49 6:04.23F             N21
G08            Falconer, Sadie             90001092    216  50C 6:41.96 7:20.46 7:58.66 8:36.42 9:13.98 9:50.21                                F             N78
D08        Falconer, Sadie             90001092    A   1218200916FF 2003413 UNOV11022025 2:59.09S 2:59.39S                   1 2 0 0 36           9503      NN30
G08            Falconer, Sadie             90001092    1 4  50C   41.14 1:26.68 2:14.12 2:59.39                                                P             N76
D08        Falconer, Sadie             90001092    A   1218200916FF 4005501 UNOV11022025 5:28.70S                   5:33.38S     3 5    23       69505      NN20
G08            Falconer, Sadie             90001092    1 8  50C   36.34 1:21.46 2:02.12 2:42.32 3:31.52 4:20.72 4:57.40 5:33.38                F             N59
D08        Hutchinson, Ross            90002446    A   0214200817MM  503103 UNOV11012025   32.50S   33.27S                   4 6 0 0 39           9503      NN60
D390002446                                                                                                                                                   N48
D08        Hutchinson, Ross            90002446    A   0214200817MM 2003113 UNOV11012025 2:40.47S 2:50.98S                   1 4 0 0 53           9503      NN11
G08            Hutchinson, Ross            90002446    1 4  50C   35.50 1:17.75 2:03.41 2:50.98                                                P             N57
D08        Hutchinson, Ross            90002446    A   0214200817MM  502404 UNOV11022025   31.10S   31.33S                   2 1 0 0 50           9502      NN40
D08        Hutchinson, Ross            90002446    A   0214200817MM 1003408 UNOV11022025 1:11.96S 1:14.72S                   3 0 0 0 43           9503      NN11
G08            Hutchinson, Ross            90002446    1 2  50C   34.70 1:14.72                                                                P             N16
D08        Hutchinson, Ross            90002446    A   0214200817MM  501412 UNOV11022025   26.49S   27.24S                   1 5 0 0 54           9501      NN60
D08        Nicol, Rose                 90020333    A   0907201114FF 2003533 UNOV11022025 3:09.31S 3:08.66S                   1 0     12           9503      NN68
D390020333                                                                                                                                                   N48
G08            Nicol, Rose                 90020333    1 4  50C   41.27 1:30.96 2:19.94 3:08.66                                                P             N45
D08        Nicol, Rose                 90020333    A   0907201114FF  503403 UNOV11022025   39.53S   38.49S                   1 5 0 0 43           9503      NN48
D08        Nicol, Rose                 90020333    A   0907201114FF 2003413 UNOV11022025 3:09.31S 3:08.66S                   5 0 0 0 48           9503      NN98
G08            Nicol, Rose                 90020333    1 4  50C   41.27 1:30.96 2:19.94 3:08.66                                                P             N45
D08        Petrie, Skye                90012088    A   0106201114FF 2001102 UNOV11012025 2:15.60S 2:14.35S                   3 9 0 0 20           9501      NN29
D390012088                                                                                                                                                   N48
G08            Petrie, Skye                90012088    1 4  50C   30.80 1:04.49 1:39.41 2:14.35                                                P             N85
D08        Petrie, Skye                90012088    A   0106201114FF 1004110 UNOV11012025 1:08.80S 1:08.44S          1:08.25S 4 9 1 3 16 15       59504      NN60
G08            Petrie, Skye                90012088    1 2  50C   31.54 1:08.44                                                                P             N44
G08            Petrie, Skye                90012088    1 2  50C   31.57 1:08.25                                                                F             N34
D08        Petrie, Skye                90012088    A   0106201114FF 8001202 UNOV11012025 9:49.90S                   9:40.43S     2 2     7  4.   1950100    NN59
G08            Petrie, Skye                90012088    116  50C   31.32 1:06.20 1:41.59 2:17.66 2:54.02 3:30.36 4:07.50 4:44.67 5:22.02 5:59.24F             N20
G08            Petrie, Skye                90012088    216  50C 6:36.37 7:13.97 7:51.23 8:28.50 9:05.45 9:40.43                                F             N77
D08        Petrie, Skye                90012088    A   0106201114FF 4001401 UNOV11022025 4:43.50S 4:46.43S                   3 1 0 0 12           9501      NN29
G08            Petrie, Skye                90012088    1 8  50C   31.44 1:05.92 1:41.70 2:18.32 2:55.30 3:32.58 4:09.87 4:46.43                P             N88
D08        Petrie, Skye                90012088    A   0106201114FF 2004405 UNOV11022025 2:30.80S 2:33.92S                   2 6 0 0 11           9504      NN39
G08            Petrie, Skye                90012088    1 4  50C   32.94 1:11.21 1:53.17 2:33.92                                                P             N85
D08        Petrie, Skye                90012088    A   0106201114FF 1002407 UNOV11022025 1:13.07S 1:11.85S          1:14.83S 1 5 1 0 27 20       09502      NN50
G08            Petrie, Skye                90012088    1 2  50C   35.00 1:11.85                                                                P             N34
G08            Petrie, Skye                90012088    1 2  50C   35.61 1:14.83                                                                F             N34
D08        Petrie, Skye                90012088    A   0106201114FF 4005501 UNOV11022025 5:29.08S                   5:22.85S     3 3    15       39505      NN39
G08            Petrie, Skye                90012088    1 8  50C   32.87 1:12.29 1:54.22 2:34.89 3:24.28 4:12.43 4:48.53 5:22.85                F             N88
D08        Taylor, Rylee               90021900    A   0801201114FF 2004525 UNOV11022025 3:08.30S      DQS                   1 4      0           9504      NN29
D390021900                                                                                                                                                   N48
G08            Taylor, Rylee               90021900    1 4  50C   38.57 1:27.67 2:21.01 3:15.12                                                P             N26
D08        Taylor, Rylee               90021900    A   0801201114FF 1002527 UNOV11022025 1:15.20S 1:19.91S                   1 8      9           9502      NN59
G08            Taylor, Rylee               90021900    1 2  50C   37.99 1:19.91                                                                P             N94
D08        Taylor, Rylee               90021900    A   0801201114FF  502104 UNOV11012025   34.00S   34.29S                   1 4 0 0 35           9502      NN19
D08        Taylor, Rylee               90021900    A   0801201114FF  501112 UNOV11012025   29.80S   31.12S                   2 0 0 0 64           9501      NN19
D08        Taylor, Rylee               90021900    A   0801201114FF 2004405 UNOV11022025 3:08.30S      DQS                   5 4 0 0  0           9504      NN39
G08            Taylor, Rylee               90021900    1 4  50C   38.57 1:27.67 2:21.01 3:15.12                                                P             N26
D08        Taylor, Rylee               90021900    A   0801201114FF 1002407 UNOV11022025 1:15.20S 1:19.91S                   5 8 0 0 47           9502      NN79
G08            Taylor, Rylee               90021900    1 2  50C   37.99 1:19.91                                                                P             N94
D08        Winton, Elliot              90027122    A   0714201213MM 4001101 UNOV11012025 5:04.70S 4:58.85S                   6 8 0 0 46           9501      NN30
D390027122                                                                                                                                                   N48
G08            Winton, Elliot              90027122    1 8  50C   32.62 1:08.86 1:45.78 2:23.69 3:02.40 3:41.14 4:20.35 4:58.85                P             N79
D08        Winton, Elliot              90027122    A   0714201213MM 1003528 UNOV11022025 1:19.02S 1:22.13S                   3 7     38           9503      NN00
G08            Winton, Elliot              90027122    1 2  50C   38.69 1:22.13                                                                P             N25
D08        Winton, Elliot              90027122    A   0714201213MM 2003113 UNOV11012025 2:57.50S 2:57.88S                   8 9 0 0 63           9503      NN30
G08            Winton, Elliot              90027122    1 4  50C   40.88 1:26.71 2:12.50 2:57.88                                                P             N76
D08        Winton, Elliot              90027122    A   0714201213MM  503103 UNOV11012025   35.62S   37.00S                   1 1 0 0 63           9503      NN69
D08        Winton, Elliot              90027122    A   0714201213MM 1003408 UNOV11022025 1:19.02S 1:22.13S                   7 7 0 0 74           9503      NN20
G08            Winton, Elliot              90027122    1 2  50C   38.69 1:22.13                                                                P             N25
D08        Winton, Gabriella           923246      A   0405200520FF 1003108 UNOV11012025 1:14.50S 1:14.06S          1:14.52S 4 5 2 3  3  5  6.   5950300    NN42
D3923246                                                                                                                                                     N38
G08            Winton, Gabriella           923246      1 2  50C   35.51 1:14.06                                                                P             N06
G08            Winton, Gabriella           923246      1 2  50C   34.96 1:14.52                                                                F             N06
D08        Winton, Gabriella           923246      A   0405200520FF  501112 UNOV11012025   28.60S   28.82S                   4 5 0 0 29           9501      NN40
D08        Winton, Gabriella           923246      A   0405200520FF  503403 UNOV11022025   33.40S   34.34S            34.52S 6 5 2 2  5  8  3.   8950300    NN71
D08        Winton, Gabriella           923246      A   0405200520FF 2003413 UNOV11022025 2:42.30S 2:42.55S          2:43.83S 3 3 1 1  7  9  2.   9950300    NN42
G08            Winton, Gabriella           923246      1 4  50C   37.29 1:18.42 1:59.97 2:42.55                                                P             N67
G08            Winton, Gabriella           923246      1 4  50C   37.24 1:18.90 2:01.11 2:43.83                                                F             N47
C18          MMSXMontrose & District Seals Asc Montrose                                                                        AN          GBR               N02
D08        Lees, Logan                 90007731    A   1215200916MM  503103 UNOV11012025   35.60S   35.43S                   1 7 0 0 57           9503      NN38
D390007731                                                                                                                                                   N48
D08        Lees, Logan                 90007731    A   1215200916MM 2004105 UNOV11012025 2:45.70S 2:43.37S                   1 9 0 0 41           9504      NN98
G08            Lees, Logan                 90007731    1 4  50C   33.12 1:12.74 1:57.80 2:43.37                                                P             N35
D08        Simpson, Kaleb              90005466    A   0507200817MM  501412 UNOV11022025   26.70S   26.29S                   1 1 0 0 40           9501      NN59
D390005466                                                                                                                                                   N48
D08        Simpson, Kaleb              90005466    A   0507200817MM 1003408 UNOV11022025 1:10.86S 1:12.77S                   4 8 0 0 30           9503      NN10
G08            Simpson, Kaleb              90005466    1 2  50C   33.69 1:12.77                                                                P             N15
D08        Stewart, Sonny              1282803     A   0517201015MM 1003528 UNOV11022025 1:24.94S 1:21.05S                   1 5     32           9503      NN10
D31282803                                                                                                                                                    N38
G08            Stewart, Sonny              1282803     1 2  50C   38.09 1:21.05                                                                P             N35
D08        Stewart, Sonny              1282803     A   0517201015MM 1002107 UNOV11012025 1:12.47S 1:09.05S                   5 5 0 0 53           9502      NN20
G08            Stewart, Sonny              1282803     1 2  50C   32.96 1:09.05                                                                P             N35
D08        Stewart, Sonny              1282803     A   0517201015MM 1003408 UNOV11022025 1:24.94S 1:21.05S                   5 5 0 0 68           9503      NN30
G08            Stewart, Sonny              1282803     1 2  50C   38.09 1:21.05                                                                P             N35
D08        Wakulinska, Natalia         1292566     A   1116201015FF 1003108 UNOV11012025 1:21.98S 1:22.24S                   1 4 0 0 27           9503      NN81
D31292566                                                                                                                                                    N48
G08            Wakulinska, Natalia         1292566     1 2  50C   38.30 1:22.24                                                                P             N96
D08        Wakulinska, Natalia         1292566     A   1116201015FF  503403 UNOV11022025   37.20S   36.93S                   4 2 0 0 31           9503      NN31
D08        Wakulinska, Natalia         1292566     A   1116201015FF 1002407 UNOV11022025 1:13.36S 1:16.11S                   1 7 0 0 43           9502      NN81
G08            Wakulinska, Natalia         1292566     1 2  50C   36.68 1:16.11                                                                P             N96
D08        Wakulinska, Natalia         1292566     A   1116201015FF 2003533 UNOV11022025 3:06.05S 2:57.09S                   2 2      2           9503      NN61
G08            Wakulinska, Natalia         1292566     1 4  50C   40.25 1:25.70 2:11.76 2:57.09                                                P             N48
D08        Wakulinska, Natalia         1292566     A   1116201015FF 2002114 UNOV11012025 2:42.80S 2:43.00S                   5 2 0 0 41           9502      NN71
G08            Wakulinska, Natalia         1292566     1 4  50C   38.42 1:19.34         2:43.00                                                P             N67
D08        Wakulinska, Natalia         1292566     A   1116201015FF 2003413 UNOV11022025 3:06.05S 2:57.09S                   6 2 0 0 30           9503      NN81
G08            Wakulinska, Natalia         1292566     1 4  50C   40.25 1:25.70 2:11.76 2:57.09                                                P             N48
C18          NOYXOrkney Asc                    Orkney                                                                                      GBR               N15
D08        Blowfield, Tamsin           90019537    A   0409201114FF 1001529 UNOV11022025 1:02.01S 1:01.54S                   3 4      2           9501      NN80
D390019537      Tamsin                                                                                                                                       N70
G08            Blowfield, Tamsin           90019537    1 2  50C   29.07 1:01.54                                                                P             N26
D08        Blowfield, Tamsin           90019537    A   0409201114FF 2001102 UNOV11012025 2:17.97S 2:18.32S                   6 5 0 0 34           9501      NN21
G08            Blowfield, Tamsin           90019537    1 4  50C   31.71 1:06.58 1:42.86 2:18.32                                                P             N77
D08        Blowfield, Tamsin           90019537    A   0409201114FF 1003108 UNOV11012025 1:22.31S 1:22.16S                   1 3 0 0 26           9503      NN11
G08            Blowfield, Tamsin           90019537    1 2  50C   38.51 1:22.16                                                                P             N26
D08        Blowfield, Tamsin           90019537    A   0409201114FF  501112 UNOV11012025   28.60S   28.52S            28.39S 4 4 1 1 21 17       79501      NN71
D08        Blowfield, Tamsin           90019537    A   0409201114FF  503403 UNOV11022025   38.15S   37.58S                   3 0 0 0 36           9503      NN70
D08        Blowfield, Tamsin           90019537    A   0409201114FF 1002407 UNOV11022025 1:12.98S 1:12.31S                   1 4 0 0 31           9502      NN11
G08            Blowfield, Tamsin           90019537    1 2  50C   34.34 1:12.31                                                                P             N26
D08        Blowfield, Tamsin           90019537    A   0409201114FF 1001409 UNOV11022025 1:02.01S 1:01.54S          1:02.30S 7 4 1 8 25 19       99501      NN42
G08            Blowfield, Tamsin           90019537    1 2  50C   29.07 1:01.54                                                                P             N26
G08            Blowfield, Tamsin           90019537    1 2  50C   29.66 1:02.30                                                                F             N26
D08        Burton, Craig               90014146    A   1219200916MM 1001109 UNOV11012025   57.95S   58.32S                   5 6 0 0 50           9501      NN39
D390014146      Craig                                                                                                                                        N10
G08            Burton, Craig               90014146    1 2  50C   28.04   58.32                                                                P             N54
D08        Burton, Craig               90014146    A   1219200916MM 1002107 UNOV11012025 1:10.94S      NSS                   7 8 0 0  0           9502      NN49
G08            Burton, Craig               90014146    1 2  50C                                                                                P             N53
D08        Burton, Craig               90014146    A   1219200916MM 2003113 UNOV11012025 2:50.82S 2:42.73S                   8 8 0 0 38           9503      NN89
G08            Burton, Craig               90014146    1 4  50C   35.39 1:17.12 2:00.45 2:42.73                                                P             N16
D08        Burton, Craig               90014146    A   1219200916MM  503103 UNOV11012025   33.30S   32.74S            32.00S 3 1 2 3 30 12       29503      NN10
D08        Burton, Craig               90014146    A   1219200916MM 1003408 UNOV11022025 1:12.04S 1:12.50S          1:13.45S 4 9 1 0 26 20       09503      NN90
G08            Burton, Craig               90014146    1 2  50C   35.08 1:12.50                                                                P             N64
G08            Burton, Craig               90014146    1 2  50C   33.79 1:13.45                                                                F             N64
D08        Burton, Craig               90014146    A   1219200916MM  501412 UNOV11022025   26.00S   26.73S                   3 9 0 0 50           9501      NN29
D08        Price, Alfie B              90035130    A   0601200916MM 1001109 UNOV11012025   51.50S   51.61S            51.90S 2 3 2 1  7  7  4.   7950100    NN00
D390035130      Alfie                                                                                                                                        N10
G08            Price, Alfie B              90035130    1 2  50C   24.67   51.61                                                                P             N04
G08            Price, Alfie B              90035130    1 2  50C   24.73   51.90                                                                F             N04
D08        Price, Alfie B              90035130    A   0601200916MM  504111 UNOV11012025   24.30S   24.79S            25.02S 4 5 2 5  2  3  8.   3950400    NN00
D08        Price, Alfie B              90035130    A   0601200916MM  502404 UNOV11022025   26.37S   27.62S                   4 5 0 0 12           9502      NN88
D08        Price, Alfie B              90035130    A   0601200916MM 1004410 UNOV11022025   55.59S 1:00.08S            58.63S 3 5 2 8 10  8  3.   8950400    NN50
G08            Price, Alfie B              90035130    1 2  50C   27.05 1:00.08                                                                P             N24
G08            Price, Alfie B              90035130    1 2  50C   27.47   58.63                                                                F             N04
D08        Price, Alfie B              90035130    A   0601200916MM  501412 UNOV11022025   22.70S   23.59S            23.10S 4 4 2 6  4  2  9.   2950100    NN99
D08        Wood, Eve                   90002768    A   0507200817FF 2005106 UNOV11012025 2:21.80S 2:22.08S          2:20.96S 3 5 1 5  2  2  9.   2950500    NN69
D390002768      Eve                                                                                                                                          N59
G08            Wood, Eve                   90002768    1 4  50C   29.50 1:05.74 1:47.59 2:22.08                                                P             N74
G08            Wood, Eve                   90002768    1 4  50C   29.71 1:06.04 1:47.64 2:20.96                                                F             N64
D08        Wood, Eve                   90002768    A   0507200817FF 1004110 UNOV11012025 1:01.25S 1:04.33S          1:05.16S 3 4 2 1  7  8  3.   8950400    NN59
G08            Wood, Eve                   90002768    1 2  50C   29.61 1:04.33                                                                P             N13
G08            Wood, Eve                   90002768    1 2  50C   29.42 1:05.16                                                                F             N13
D08        Wood, Eve                   90002768    A   0507200817FF  501112 UNOV11012025   25.70S   26.47S            26.48S 8 4 2 3  3  3  8.   3950100    NN98
D08        Wood, Eve                   90002768    A   0507200817FF 1002407 UNOV11022025 1:02.68S 1:04.41S          1:03.81S 2 4 2 6  4  5  6.   5950200    NN69
G08            Wood, Eve                   90002768    1 2  50C   30.33 1:04.41                                                                P             N13
G08            Wood, Eve                   90002768    1 2  50C   30.43 1:03.81                                                                F             N13
D08        Wood, Eve                   90002768    A   0507200817FF 1001409 UNOV11022025   56.90S   58.53S            58.64S 4 5 2 7  6  5  6.   5950100    NN19
G08            Wood, Eve                   90002768    1 2  50C   28.40   58.53                                                                P             N03
G08            Wood, Eve                   90002768    1 2  50C   28.12   58.64                                                                F             N92
D08        Wood, Eve                   90002768    A   0507200817FF  504411 UNOV11022025   26.70S   28.03S            27.47S 7 4 2 3  3  3  8.   3950400    NN98
E08        A  NOYX  X 2006301 UNOV  011012025 1:43.00S                   1:47.19S     2 6    10                                                9N13001  X    N35
F08              NOYXABurton, Craig               90014146       1219200916M  1             90014146      Craig                                              N87
G08            Burton, Craig               90014146    1 4  50C   26.00                                                                        F             N93
F08              NOYXABlowfield, Tamsin           90019537       0409201114F  2             90019537      Tamsin                                             N89
G08            Blowfield, Tamsin           90019537    1 4  50C   55.83                                                                        F             N55
F08              NOYXAWood, Eve                   90002768       0507200817F  3             90002768      Eve                                                N55
G08            Wood, Eve                   90002768    1 4  50C 1:22.69                                                                        F             N62
F08              NOYXAPrice, Alfie B              90035130       0601200916M  4             90035130      Alfie                                              N37
G08            Price, Alfie B              90035130    1 4  50C 1:47.19                                                                        F             N83
E08        A  NOYX  X 2007601 UNOV  011022025 1:54.97S                   1:57.06S     2 7     8                                                7N13005  X    N35
F08              NOYXAPrice, Alfie B              90035130       0601200916M  1             90035130      Alfie                                              N37
G08            Price, Alfie B              90035130    1 4  50C   26.93                                                                        F             N53
F08              NOYXABurton, Craig               90014146       1219200916M  2             90014146      Craig                                              N87
G08            Burton, Craig               90014146    1 4  50C 1:00.08                                                                        F             N14
F08              NOYXAWood, Eve                   90002768       0507200817F  3             90002768      Eve                                                N55
G08            Wood, Eve                   90002768    1 4  50C 1:28.31                                                                        F             N62
F08              NOYXABlowfield, Tamsin           90019537       0409201114F  4             90019537      Tamsin                                             N99
G08            Blowfield, Tamsin           90019537    1 4  50C 1:57.06                                                                        F             N75
C18SS      SSMPCXPerth City Swim Club          Perth City      Perth Leisure Pool,  G                      Perth               PEPH2 0HZ                     N19
D08SS      Adam, Tearlach H            90018906    AGBR1215201015MM 1003408 UNOV11022025 1:12.00S 1:10.39S          1:09.70S 2 0 1 6 19 13       39503      NN52
D390018906                                                                                                                                                   N58
G08SS          Adam, Tearlach H            90018906    1 2  50C   33.00 1:10.39                                                                P             N55
G08SS          Adam, Tearlach H            90018906    1 2  50C   32.66 1:09.70                                                                F             N55
D08SS      Adam, Tearlach H            90018906    AGBR1215201015MM 8001502 UNOV11022025 9:18.52S                   9:14.45S     2 0    15       69501      NN21
G08SS          Adam, Tearlach H            90018906    116  50C   31.03 1:06.17 1:41.32 2:16.75 2:52.16 3:27.60 4:02.79 4:38.52 5:13.29 5:48.36F             N51
G08SS          Adam, Tearlach H            90018906    216  50C 6:23.58 6:58.52 7:33.19 8:08.33 8:42.86 9:14.45                                F             N09
D08SS      Auld, Charlie               90003311    AGBR0816200817MM 1002107 UNOV11012025 1:06.90S 1:03.72S                   7 5 0 0 21           9502      NN70
D390003311                                                                                                                                                   N48
G08SS          Auld, Charlie               90003311    1 2  50C   30.16 1:03.72                                                                P             N94
D08SS      Auld, Charlie               90003311    AGBR0816200817MM  502404 UNOV11022025   30.26S   30.00S                   3 0 0 0 32           9502      NN00
D08SS      Combe, Daniel               90036713    AGBR0905201114MM 1001109 UNOV11012025   56.10S   55.38S            58.58S 6 4 1 7 23 20       09501      NN31
D390036713                                                                                                                                                   N48
G08SS          Combe, Daniel               90036713    1 2  50C   26.05   55.38                                                                P             N84
G08SS          Combe, Daniel               90036713    1 2  50C   27.23   58.58                                                                F             N84
D08SS      Combe, Daniel               90036713    AGBR0905201114MM 1002107 UNOV11012025 1:05.70S 1:03.15S          1:05.74S 1 5 1 2 16 18       89502      NN91
G08SS          Combe, Daniel               90036713    1 2  50C   30.40 1:03.15                                                                P             N94
G08SS          Combe, Daniel               90036713    1 2  50C   31.07 1:05.74                                                                F             N94
D08SS      Combe, Daniel               90036713    AGBR0905201114MM  504111 UNOV11012025   28.26S   27.83S            29.33S 2 9 1 8 29 19       99504      NN41
D08SS      Combe, Daniel               90036713    AGBR0905201114MM 2001402 UNOV11022025 2:02.70S 2:05.91S                   3 0 0 0 35           9501      NN60
G08SS          Combe, Daniel               90036713    1 4  50C   27.99   59.76 1:33.23 2:05.91                                                P             N36
D08SS      Combe, Daniel               90036713    AGBR0905201114MM  502404 UNOV11022025   31.00S   30.07S                   2 7 0 0 34           9502      NN00
D08SS      Combe, Daniel               90036713    AGBR0905201114MM  501412 UNOV11022025   25.60S   25.55S                   3 6 0 0 24           9501      NN10
D08SS      Dow, Frazer                 90023234    AGBR0310200916MM  503103 UNOV11012025   30.30S   30.15S            30.07S 7 7 3 0  9  8  3.   8950300    NN80
D390023234                                                                                                                                                   N48
D08SS      Dow, Frazer                 90023234    AGBR0310200916MM 2003113 UNOV11012025 2:22.20S 2:20.99S          2:18.40S 2 5 1 5  2  2  9.   2950300    NN51
G08SS          Dow, Frazer                 90023234    1 4  50C   31.70 1:07.70 1:44.64 2:20.99                                                P             N95
G08SS          Dow, Frazer                 90023234    1 4  50C   31.16 1:05.99 1:41.69 2:18.40                                                F             N95
D08SS      Dow, Frazer                 90023234    AGBR0310200916MM 4005201 UNOV11012025 4:49.04S                   4:40.79S     4 5     6  5.   1950500    NN40
G08SS          Dow, Frazer                 90023234    1 8  50C   29.36 1:02.95 1:40.74 2:18.35 2:55.88 3:35.27 4:08.87 4:40.79                F             N09
D08SS      Jackson, Anna               90026573    AGBR1101201114FF 1001529 UNOV11022025 1:03.00S 1:01.92S                   3 6      3           9501      NN30
D390026573      Anna                                                                                                                                         N89
G08SS          Jackson, Anna               90026573    1 2  50C   29.98 1:01.92                                                                P             N25
D08SS      Jackson, Anna               90026573    AGBR1101201114FF 2001102 UNOV11012025 2:16.50S 2:15.42S                   1 2 0 0 23           9501      NN50
G08SS          Jackson, Anna               90026573    1 4  50C   30.88 1:05.84 1:41.25 2:15.42                                                P             N66
D08SS      Jackson, Anna               90026573    AGBR1101201114FF 1003108 UNOV11012025 1:17.80S 1:17.53S          1:18.23S 4 1 2 9 10  9  2.   9950300    NN22
G08SS          Jackson, Anna               90026573    1 2  50C   36.25 1:17.53                                                                P             N15
G08SS          Jackson, Anna               90026573    1 2  50C   36.31 1:18.23                                                                F             N05
D08SS      Jackson, Anna               90026573    AGBR1101201114FF  501112 UNOV11012025   28.20S   28.53S            28.77S 6 9 1 8 23 19       99501      NN31
D08SS      Jackson, Anna               90026573    AGBR1101201114FF  503403 UNOV11022025   35.17S   35.26S            34.33S 6 1 1 5 14 11       19503      NN21
D08SS      Jackson, Anna               90026573    AGBR1101201114FF 2003413 UNOV11022025 2:51.20S 2:50.04S                   2 1 0 0 17           9503      NN60
G08SS          Jackson, Anna               90026573    1 4  50C   38.45 1:21.84 2:05.85 2:50.04                                                P             N66
D08SS      Jackson, Anna               90026573    AGBR1101201114FF 1001409 UNOV11022025 1:03.00S 1:01.92S          1:01.60S 7 6 1 9 27 18       89501      NN91
G08SS          Jackson, Anna               90026573    1 2  50C   29.98 1:01.92                                                                P             N25
G08SS          Jackson, Anna               90026573    1 2  50C   29.87 1:01.60                                                                F             N15
D08SS      Martin, Harry               90018033    AGBR0529201015MM 1001109 UNOV11012025   59.10S   59.04S                   5 0 0 0 54           9501      NN50
D390018033                                                                                                                                                   N48
G08SS          Martin, Harry               90018033    1 2  50C   28.13   59.04                                                                P             N15
D08SS      Martin, Harry               90018033    AGBR0529201015MM 1003528 UNOV11022025 1:22.11S 1:19.59S                   2 6     23           9503      NN80
G08SS          Martin, Harry               90018033    1 2  50C   37.33 1:19.59                                                                P             N35
D08SS      Martin, Harry               90018033    AGBR0529201015MM 2005526 UNOV11022025 2:32.74S 2:29.73S                   3 0     21           9505      NN80
G08SS          Martin, Harry               90018033    1 4  50C   34.05 1:12.97 1:58.14 2:29.73                                                P             N86
D08SS      Martin, Harry               90018033    AGBR0529201015MM 2001522 UNOV11022025 2:14.59S 2:10.52S                   2 1     13           9501      NN70
G08SS          Martin, Harry               90018033    1 4  50C   29.31 1:01.92 1:36.58 2:10.52                                                P             N76
D08SS      Martin, Harry               90018033    AGBR0529201015MM 2001402 UNOV11022025 2:14.59S 2:10.52S                   6 1 0 0 51           9501      NN90
G08SS          Martin, Harry               90018033    1 4  50C   29.31 1:01.92 1:36.58 2:10.52                                                P             N76
D08SS      Martin, Harry               90018033    AGBR0529201015MM 2005406 UNOV11022025 2:32.74S 2:29.73S                   7 0 0 0 59           9505      NN11
G08SS          Martin, Harry               90018033    1 4  50C   34.05 1:12.97 1:58.14 2:29.73                                                P             N86
D08SS      Martin, Harry               90018033    AGBR0529201015MM 1003408 UNOV11022025 1:22.11S 1:19.59S                   6 6 0 0 59           9503      NN01
G08SS          Martin, Harry               90018033    1 2  50C   37.33 1:19.59                                                                P             N35
D08SS      McKenzie, Calum             90014159    AGBR0824200916MM 1002107 UNOV11012025 1:00.74S 1:01.59S          1:00.64S 4 6 1 4 11 11       19502      NN72
D390014159                                                                                                                                                   N48
G08SS          McKenzie, Calum             90014159    1 2  50C   29.03 1:01.59                                                                P             N85
G08SS          McKenzie, Calum             90014159    1 2  50C   28.91 1:00.64                                                                F             N75
D08SS      McKenzie, Calum             90014159    AGBR0824200916MM 1001109 UNOV11012025   53.53S   55.36S            54.18S 3 2 1 2 22 13       39501      NN12
G08SS          McKenzie, Calum             90014159    1 2  50C   26.68   55.36                                                                P             N65
G08SS          McKenzie, Calum             90014159    1 2  50C   26.25   54.18                                                                F             N55
D08SS      McKenzie, Calum             90014159    AGBR0824200916MM 2001402 UNOV11022025 1:57.84S 2:01.66S                   3 6 0 0 22           9501      NN51
G08SS          McKenzie, Calum             90014159    1 4  50C   27.20   57.07 1:29.19 2:01.66                                                P             N07
D08SS      McKenzie, Calum             90014159    AGBR0824200916MM  502404 UNOV11022025   28.11S   28.99S            28.13S 6 2 1 1 24 14       49502      NN12
D08SS      McKenzie, Calum             90014159    AGBR0824200916MM  501412 UNOV11022025   24.90S   25.44S            25.39S 6 8 1 1 23 15       59501      NN12
D08SS      Norris, Jensen              1308340     AGBR0706200817MM 1001109 UNOV11012025   49.10S   51.43S            50.79S 3 4 2 2  5  4  7.   4950100    NN12
D31308340                                                                                                                                                    N38
G08SS          Norris, Jensen              1308340     1 2  50C   24.82   51.43                                                                P             N45
G08SS          Norris, Jensen              1308340     1 2  50C   24.37   50.79                                                                F             N45
D08SS      Norris, Jensen              1308340     AGBR0706200817MM  504111 UNOV11012025   24.20S   25.22S            28.81S 5 5 2 6  4 10  1.   0950400    NN02
D08SS      Norris, Jensen              1308340     AGBR0706200817MM 1004410 UNOV11022025   53.30S   57.46S            57.15S 2 4 2 2  5  6  5.   6950400    NN12
G08SS          Norris, Jensen              1308340     1 2  50C   26.22   57.46                                                                P             N45
G08SS          Norris, Jensen              1308340     1 2  50C   26.29   57.15                                                                F             N45
D08SS      Norris, Jensen              1308340     AGBR0706200817MM  501412 UNOV11022025   22.20S   23.52S            23.18S 5 4 2 5  2  3  8.   3950100    NN91
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF 1002527 UNOV11022025 1:13.90S 1:15.46S                   1 6      5           9502      NN80
D390014174                                                                                                                                                   N48
G08SS          Renfrew, Alice              90014174    1 2  50C   36.48 1:15.46                                                                P             N55
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF 2001102 UNOV11012025 2:15.90S 2:19.46S                   2 9 0 0 39           9501      NN11
G08SS          Renfrew, Alice              90014174    1 4  50C   32.32 1:07.24 1:43.58 2:19.46                                                P             N07
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF  501112 UNOV11012025   29.20S   30.18S                   3 1 0 0 60           9501      NN50
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF 1001529 UNOV11022025 1:03.10S 1:04.35S                   4 2     19           9501      NN90
G08SS          Renfrew, Alice              90014174    1 2  50C   31.14 1:04.35                                                                P             N55
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF 1002407 UNOV11022025 1:13.90S 1:15.46S                   5 6 0 0 39           9502      NN11
G08SS          Renfrew, Alice              90014174    1 2  50C   36.48 1:15.46                                                                P             N55
D08SS      Renfrew, Alice              90014174    AGBR0309201015FF 1001409 UNOV11022025 1:03.10S 1:04.35S                   8 2 0 0 50           9501      NN01
G08SS          Renfrew, Alice              90014174    1 2  50C   31.14 1:04.35                                                                P             N55
D08SS      Renfrew, Grace              90014173    AGBR0309201015FF 2001102 UNOV11012025 2:09.90S 2:11.76S                   4 6 0 0 12           9501      NN11
D390014173                                                                                                                                                   N48
G08SS          Renfrew, Grace              90014173    1 4  50C   30.13 1:03.34 1:37.73 2:11.76                                                P             N96
D08SS      Renfrew, Grace              90014173    AGBR0309201015FF 1004110 UNOV11012025 1:11.74S 1:10.85S                   1 9 0 0 30           9504      NN01
G08SS          Renfrew, Grace              90014173    1 2  50C   33.11 1:10.85                                                                P             N55
D08SS      Renfrew, Grace              90014173    AGBR0309201015FF  501112 UNOV11012025   28.44S   28.27S            28.37S 5 7 1 2 18 16       69501      NN71
D08SS      Renfrew, Grace              90014173    AGBR0309201015FF 1002407 UNOV11022025 1:11.92S 1:12.15S                   4 9 0 0 30           9502      NN11
G08SS          Renfrew, Grace              90014173    1 2  50C   34.88 1:12.15                                                                P             N55
D08SS      Renfrew, Grace              90014173    AGBR0309201015FF 1001409 UNOV11022025   59.90S   59.96S            59.38S 2 1 1 4 12 12       29501      NN81
G08SS          Renfrew, Grace              90014173    1 2  50C   29.56   59.96                                                                P             N45
G08SS          Renfrew, Grace              90014173    1 2  50C   29.11   59.38                                                                F             N35
D08SS      Ridler, Harry               90017989    AGBR0211201015MM 1002107 UNOV11012025 1:12.40S 1:08.00S                   5 4 0 0 45           9502      NN90
D390017989                                                                                                                                                   N58
G08SS          Ridler, Harry               90017989    1 2  50C   33.69 1:08.00                                                                P             N35
D08SS      Ridler, Harry               90017989    AGBR0211201015MM 4001101 UNOV11012025 4:45.30S 4:39.47S                   6 4 0 0 35           9501      NN01
G08SS          Ridler, Harry               90017989    1 8  50C   30.06 1:04.44 1:40.29 2:16.27 2:52.23 3:28.37 4:04.41 4:39.47                P             N79
D08SS      Scott, Katie                90031531    AGBR1202201015FF 1001529 UNOV11022025 1:04.00S 1:04.09S                   3 8     15           9501      NN20
D390031531                                                                                                                                                   N48
G08SS          Scott, Katie                90031531    1 2  50C   31.38 1:04.09                                                                P             N84
D08SS      Scott, Katie                90031531    AGBR1202201015FF  501112 UNOV11012025   29.60S   29.81S                   2 2 0 0 53           9501      NN89
D08SS      Scott, Katie                90031531    AGBR1202201015FF  504411 UNOV11022025   32.40S   32.46S                   1 4 0 0 49           9504      NN89
D08SS      Scott, Katie                90031531    AGBR1202201015FF 1002527 UNOV11022025 1:13.57S 1:12.07S                   1 4      2           9502      NN10
G08SS          Scott, Katie                90031531    1 2  50C   35.10 1:12.07                                                                P             N84
D08SS      Scott, Katie                90031531    AGBR1202201015FF 2001102 UNOV11012025 2:17.20S 2:17.73S                   5 4 0 0 32           9501      NN30
G08SS          Scott, Katie                90031531    1 4  50C   32.32 1:07.36 1:43.17 2:17.73                                                P             N36
D08SS      Scott, Katie                90031531    AGBR1202201015FF 1002407 UNOV11022025 1:13.57S 1:12.07S                   5 4 0 0 29           9502      NN40
G08SS          Scott, Katie                90031531    1 2  50C   35.10 1:12.07                                                                P             N84
D08SS      Scott, Katie                90031531    AGBR1202201015FF 1001409 UNOV11022025 1:04.00S 1:04.09S                   7 8 0 0 45           9501      NN30
G08SS          Scott, Katie                90031531    1 2  50C   31.38 1:04.09                                                                P             N84
D08SS      Smart, Katie                1292831     AGBR0720200817FF 8001202 UNOV11012025 9:49.40S                   9:53.66S     2 6    16       79501      NN40
D31292831                                                                                                                                                    N38
G08SS          Smart, Katie                1292831     116  50C   32.92 1:09.17 1:46.07 2:23.50 3:00.51 3:38.44 4:15.73 4:53.07 5:30.64 6:08.66F             N60
G08SS          Smart, Katie                1292831     216  50C 6:46.43         8:01.71 8:39.61 9:17.32 9:53.66                                F             N47
D08SS      Thomson, Ella               90017993    AGBR0220201015FF  503403 UNOV11022025   34.10S   34.31S            34.35S 6 3 2 6  4  6  5.   6950300    NN51
D390017993                                                                                                                                                   N58
D08SS      Thomson, Ella               90017993    AGBR0220201015FF 1001409 UNOV11022025 1:01.40S 1:00.95S                   1 5 0 0 20           9501      NN70
G08SS          Thomson, Ella               90017993    1 2  50C   29.21 1:00.95                                                                P             N35
D08SS      Thomson, Ella               90017993    AGBR0220201015FF 2003413 UNOV11022025 2:41.00S 2:43.95S          2:42.51S 2 5 1 0  9  7  4.   7950300    NN32
G08SS          Thomson, Ella               90017993    1 4  50C   37.22 1:18.46 2:01.54 2:43.95                                                P             N86
G08SS          Thomson, Ella               90017993    1 4  50C   37.22 1:19.51 2:01.11 2:42.51                                                F             N66
D08SS      Thomson, Stuart             90023246    AGBR0222201015MM 2001402 UNOV11022025 1:58.80S 2:00.73S                   2 2 0 0 16           9501      NN91
D390023246                                                                                                                                                   N48
G08SS          Thomson, Stuart             90023246    1 4  50C   27.56   58.33 1:29.68 2:00.73                                                P             N67
D08SS      Thomson, Stuart             90023246    AGBR0222201015MM  502404 UNOV11022025   30.36S   30.21S                   3 9 0 0 36           9502      NN31
D08SS      Thomson, Stuart             90023246    AGBR0222201015MM 2005406 UNOV11022025 2:23.40S 2:22.30S                   1 8 0 0 34           9505      NN91
G08SS          Thomson, Stuart             90023246    1 4  50C   30.69 1:07.11 1:50.08 2:22.30                                                P             N77
D08SS      Thomson, Stuart             90023246    AGBR0222201015MM  501412 UNOV11022025   25.05S   26.37S                   5 0 0 0 41           9501      NN31
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 1001529 UNOV11022025 1:02.30S 1:02.11S                   2 4      4           9501      NN00
D390032063                                                                                                                                                   N48
G08SS          Wilson, Aila                90032063    1 2  50C   29.73 1:02.11                                                                P             N84
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 2003533 UNOV11022025 3:07.93S 2:58.43S                   1 1      3           9503      NN10
G08SS          Wilson, Aila                90032063    1 4  50C   40.97 1:26.54 2:13.49 2:58.43                                                P             N36
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 2001102 UNOV11012025 2:13.60S 2:17.13S                   2 8 0 0 28           9501      NN30
G08SS          Wilson, Aila                90032063    1 4  50C   30.80 1:05.05 1:41.17 2:17.13                                                P             N26
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 2005106 UNOV11012025 2:39.50S 2:39.84S                   1 8 0 0 35           9505      NN40
G08SS          Wilson, Aila                90032063    1 4  50C   34.77 1:14.56 2:03.72 2:39.84                                                P             N36
D08SS      Wilson, Aila                90032063    AGBR0421201213FF  501112 UNOV11012025   28.90S   29.36S                   4 8 0 0 41           9501      NN89
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 4001401 UNOV11022025 4:46.00S 4:56.13S                   3 0 0 0 24           9501      NN30
G08SS          Wilson, Aila                90032063    1 8  50C   31.91 1:06.97 1:43.43 2:21.39 3:00.11 3:38.91 4:18.03 4:56.13                P             N29
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 1001409 UNOV11022025 1:02.30S 1:02.11S                   6 4 0 0 29           9501      NN30
G08SS          Wilson, Aila                90032063    1 2  50C   29.73 1:02.11                                                                P             N84
D08SS      Wilson, Aila                90032063    AGBR0421201213FF 2003413 UNOV11022025 3:07.93S 2:58.43S                   5 1 0 0 33           9503      NN40
G08SS          Wilson, Aila                90032063    1 4  50C   40.97 1:26.54 2:13.49 2:58.43                                                P             N36
C18          NPDXPeterhead Asc                 Peterhead       Veronica Smith                              Peterhead                       GBR               N15
D08        Wallace, Keir               90029311    A   0731201015MM 2004105 UNOV11012025 2:50.81S      DQS                   5 3 0 0  0           9504      NN19
D390029311                                                                                                                                                   N48
G08            Wallace, Keir               90029311    1 4  50C   37.30 1:20.90 2:05.54 2:49.62                                                P             N06
D08        West, Noah                  90025530    A   0313201114MM 4001101 UNOV11012025 4:59.72S 4:59.03S                   5 7 0 0 47           9501      NN68
D390025530                                                                                                                                                   N48
G08            West, Noah                  90025530    1 8  50C   31.51 1:07.34 1:43.98 2:22.24 3:01.16 3:39.86 4:19.70 4:59.03                P             N08
C18          NSHXShetland Acsc                 Shetland        Petur Petursson       17 Hillside Brae      Gulberwick            ZE2 9FD   GBR               N61
D08    IG  Bain, Katie                 301071      A   0627200025FF  502104 UNOV11012025   32.94S   33.34S                   3 9 0 0 31           9502      NN38
D3301071                                                                                                                                                     N28
D08    IG  Bain, Katie                 301071      A   0627200025FF  501112 UNOV11012025   28.16S   28.52S                   8 9 0 0 21           9501      NN38
D08    IG  Bain, Katie                 301071      A   0627200025FF  504411 UNOV11022025   30.12S   30.23S                   5 9 0 0 16           9504      NN38
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM 1002107 UNOV11012025 1:03.12S 1:01.22S          1:00.61S 2 7 2 9 10  8  3.   8950200    NN03
D390004842      Lockie                                                                                                                                       N60
G08            Bullough, Lachlan           90004842    1 2  50C   29.43 1:01.22                                                                P             N16
G08            Bullough, Lachlan           90004842    1 2  50C   29.02 1:00.61                                                                F             N06
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM 1001109 UNOV11012025   55.92S   56.61S                   1 7 0 0 37           9501      NN11
G08            Bullough, Lachlan           90004842    1 2  50C   26.94   56.61                                                                P             N06
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM  504111 UNOV11012025   26.48S   27.69S            27.04S 3 8 1 1 28 13       39504      NN12
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM 2001402 UNOV11022025 2:01.19S 2:00.79S                   2 1 0 0 17           9501      NN51
G08            Bullough, Lachlan           90004842    1 4  50C   27.59   58.26 1:29.88 2:00.79                                                P             N57
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM  502404 UNOV11022025   28.28S   28.73S            27.77S 4 7 1 2 21 11       19502      NN12
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM 1004410 UNOV11022025   59.96S 1:00.95S            59.88S 2 7 1 3 17 13       39504      NN52
G08            Bullough, Lachlan           90004842    1 2  50C   28.39 1:00.95                                                                P             N26
G08            Bullough, Lachlan           90004842    1 2  50C   28.16   59.88                                                                F             N06
D08    IG  Bullough, Lachlan           90004842    A   0410201015MM 2002414 UNOV11022025 2:19.12S 2:23.23S                   2 7 0 0 28           9502      NN51
G08            Bullough, Lachlan           90004842    1 4  50C   31.85 1:08.69 1:46.56 2:23.23                                                P             N67
D08        Drakeford, Ross             90012861    A   0202201114MM 1003528 UNOV11022025 1:23.23S 1:18.37S                   2 7     17           9503      NN30
D390012861                                                                                                                                                   N48
G08            Drakeford, Ross             90012861    1 2  50C   37.21 1:18.37                                                                P             N55
D08        Drakeford, Ross             90012861    A   0202201114MM 2003113 UNOV11012025 2:57.74S 2:53.50S                   7 9 0 0 57           9503      NN50
G08            Drakeford, Ross             90012861    1 4  50C   39.45 1:23.63 2:08.85 2:53.50                                                P             N07
D08        Drakeford, Ross             90012861    A   0202201114MM 1003408 UNOV11022025 1:23.23S 1:18.37S                   6 7 0 0 53           9503      NN50
G08            Drakeford, Ross             90012861    1 2  50C   37.21 1:18.37                                                                P             N55
C18SS      SSWSEXSouth Ayrshire Swim Team (SastSth Ayrshire    c/o Prestwick Swimming                      Prestwick           ScKA9 1NW                     N26
D08SS      Black, Hamish               90036788    AGBR1022201114MM 2005526 UNOV11022025 2:31.24S 2:26.23S                   3 1     10           9505      NN50
D390036788                                                                                                                                                   N58
G08SS          Black, Hamish               90036788    1 4  50C   31.95 1:09.99 1:52.09 2:26.23                                                P             N66
D08SS      Black, Hamish               90036788    AGBR1022201114MM 1002107 UNOV11012025 1:09.66S 1:09.03S                   8 7 0 0 52           9502      NN70
G08SS          Black, Hamish               90036788    1 2  50C   33.38 1:09.03                                                                P             N15
D08SS      Black, Hamish               90036788    AGBR1022201114MM 4005201 UNOV11012025 5:30.44S                   5:19.38S     1 2    38       39505      NN70
G08SS          Black, Hamish               90036788    1 8  50C   34.20 1:14.26 1:55.45 2:36.68 3:22.49 4:08.36 4:45.23 5:19.38                F             N59
D08SS      Black, Hamish               90036788    AGBR1022201114MM 2003113 UNOV11012025 2:45.30S 2:51.79S                   7 4 0 0 55           9503      NN70
G08SS          Black, Hamish               90036788    1 4  50C   37.56 1:22.77 2:09.17 2:51.79                                                P             N66
D08SS      Black, Hamish               90036788    AGBR1022201114MM 1003528 UNOV11022025 1:17.00S 1:17.53S                   4 6     15           9503      NN50
G08SS          Black, Hamish               90036788    1 2  50C   38.29 1:17.53                                                                P             N15
D08SS      Black, Hamish               90036788    AGBR1022201114MM 1004530 UNOV11022025 1:08.99S 1:10.99S                   2 8     14           9504      NN60
G08SS          Black, Hamish               90036788    1 2  50C   33.78 1:10.99                                                                P             N15
D08SS      Black, Hamish               90036788    AGBR1022201114MM 1003408 UNOV11022025 1:17.00S 1:17.53S                   8 6 0 0 51           9503      NN70
G08SS          Black, Hamish               90036788    1 2  50C   38.29 1:17.53                                                                P             N15
D08SS      Black, Hamish               90036788    AGBR1022201114MM 2005406 UNOV11022025 2:31.24S 2:26.23S                   7 1 0 0 47           9505      NN70
G08SS          Black, Hamish               90036788    1 4  50C   31.95 1:09.99 1:52.09 2:26.23                                                P             N66
D08SS      Black, Hamish               90036788    AGBR1022201114MM 1004410 UNOV11022025 1:08.99S 1:10.99S                   6 8 0 0 51           9504      NN80
G08SS          Black, Hamish               90036788    1 2  50C   33.78 1:10.99                                                                P             N15
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2002534 UNOV11022025 2:30.40S 2:25.27S                   2 5      1           9502      NN79
D390045709      Max                                                                                                                                          N59
G08SS          Clark, Max S                90045709    1 4  50C   34.55 1:11.79 1:49.11 2:25.27                                                P             N85
D08SS      Clark, Max S                90045709    AGBR0928201114MM 1003528 UNOV11022025 1:14.30S 1:13.37S                   5 4      3           9503      NN79
G08SS          Clark, Max S                90045709    1 2  50C   34.98 1:13.37                                                                P             N34
D08SS      Clark, Max S                90045709    AGBR0928201114MM  503103 UNOV11012025   34.80S   34.67S                   2 0 0 0 55           9503      NN49
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2004105 UNOV11012025 2:37.96S 2:35.65S                   1 1 0 0 34           9504      NN00
G08SS          Clark, Max S                90045709    1 4  50C   33.65 1:13.09 1:53.49 2:35.65                                                P             N85
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2003113 UNOV11012025 2:40.80S 2:38.09S                   1 3 0 0 25           9503      NN99
G08SS          Clark, Max S                90045709    1 4  50C   35.53 1:16.48 1:57.51 2:38.09                                                P             N85
D08SS      Clark, Max S                90045709    AGBR0928201114MM 4005201 UNOV11012025 5:09.10S                   5:07.77S     3 0    32       99505      NN99
G08SS          Clark, Max S                90045709    1 8  50C   33.36 1:13.31 1:51.77 2:29.49 3:12.16 3:54.53 4:33.47 5:07.77                F             N78
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2005526 UNOV11022025 2:25.10S 2:22.27S                   3 5      3           9505      NN79
G08SS          Clark, Max S                90045709    1 4  50C   31.33 1:07.39 1:48.21 2:22.27                                                P             N75
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2005406 UNOV11022025 2:25.10S 2:22.27S                   7 5 0 0 33           9505      NN00
G08SS          Clark, Max S                90045709    1 4  50C   31.33 1:07.39 1:48.21 2:22.27                                                P             N75
D08SS      Clark, Max S                90045709    AGBR0928201114MM 1003408 UNOV11022025 1:14.30S 1:13.37S                   9 4 0 0 33           9503      NN00
G08SS          Clark, Max S                90045709    1 2  50C   34.98 1:13.37                                                                P             N34
D08SS      Clark, Max S                90045709    AGBR0928201114MM 2002414 UNOV11022025 2:30.40S 2:25.27S                   6 5 0 0 35           9502      NN99
G08SS          Clark, Max S                90045709    1 4  50C   34.55 1:11.79 1:49.11 2:25.27                                                P             N85
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM 4001101 UNOV11012025 4:30.60S 4:38.57S                   2 9 0 0 34           9501      NN11
D390030712      Max                                                                                                                                          N49
G08SS          Corcoran, Max O             90030712    1 8  50C   29.10 1:01.70 1:36.52 2:12.19 2:48.79 3:25.70 4:02.82 4:38.57                P             N89
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM 1002107 UNOV11012025 1:05.68S 1:04.58S                   1 4 0 0 26           9502      NN11
G08SS          Corcoran, Max O             90030712    1 2  50C   31.04 1:04.58                                                                P             N45
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM  504111 UNOV11012025   28.60S   28.71S                   1 2 0 0 37           9504      NN50
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM  502404 UNOV11022025   29.50S   29.61S            28.96S 6 9 1 0 27 17       79502      NN71
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM 1004410 UNOV11022025 1:04.20S      NSS                   1 0 0 0  0           9504      NN60
G08SS          Corcoran, Max O             90030712    1 2  50C                                                                                P             N24
D08SS      Corcoran, Max O             90030712    AGBR0523201015MM  501412 UNOV11022025   26.68S   26.50S                   1 7 0 0 43           9501      NN50
D08SS      Currie, Sam                 90011504    AGBR0926201015MM 1001109 UNOV11012025   57.35S   56.73S                   5 3 0 0 38           9501      NN79
D390011504                                                                                                                                                   N48
G08SS          Currie, Sam                 90011504    1 2  50C   27.29   56.73                                                                P             N24
D08SS      Currie, Sam                 90011504    AGBR0926201015MM 4001101 UNOV11012025 4:22.02S 4:22.52S                   2 4 0 0 16           9501      NN00
G08SS          Currie, Sam                 90011504    1 8  50C   28.62 1:00.29 1:33.24 2:06.97 2:40.97 3:15.31 3:49.63 4:22.52                P             N88
D08SS      Currie, Sam                 90011504    AGBR0926201015MM 4005201 UNOV11012025 5:03.17S                   4:54.74S     3 6    18       39505      NN10
G08SS          Currie, Sam                 90011504    1 8  50C   32.55 1:07.81 1:46.44 2:24.24 3:07.87 3:50.20 4:23.34 4:54.74                F             N78
D08SS      Currie, Sam                 90011504    AGBR0926201015MM 2001402 UNOV11022025 2:03.63S 2:03.93S                   3 9 0 0 30           9501      NN00
G08SS          Currie, Sam                 90011504    1 4  50C   28.05   59.14 1:31.31 2:03.93                                                P             N65
D08SS      Currie, Sam                 90011504    AGBR0926201015MM 2005406 UNOV11022025 2:22.34S 2:20.25S                   1 6 0 0 24           9505      NN00
G08SS          Currie, Sam                 90011504    1 4  50C   31.64 1:06.63 1:49.31 2:20.25                                                P             N85
D08SS      Currie, Sam                 90011504    AGBR0926201015MM  501412 UNOV11022025   26.40S   26.59S                   1 4 0 0 47           9501      NN59
D08SS      Haddow, Gracie              90017307    AGBR0423201015FF  502104 UNOV11012025   30.70S   31.44S            30.84S 5 7 1 6 17 13       39502      NN51
D390017307                                                                                                                                                   N48
D08SS      Haddow, Gracie              90017307    AGBR0423201015FF  501112 UNOV11012025   26.10S   27.72S            27.12S 8 5 1 4 12 11       19501      NN41
D08SS      Haddow, Gracie              90017307    AGBR0423201015FF 1002407 UNOV11022025 1:07.70S 1:11.44S                   3 7 0 0 24           9502      NN90
G08SS          Haddow, Gracie              90017307    1 2  50C   34.18 1:11.44                                                                P             N45
D08SS      Haddow, Gracie              90017307    AGBR0423201015FF 1001409 UNOV11022025   58.75S 1:03.61S                   3 6 0 0 44           9501      NN80
G08SS          Haddow, Gracie              90017307    1 2  50C   29.86 1:03.61                                                                P             N45
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 4001101 UNOV11012025 4:24.19S 4:43.27S                   2 3 0 0 37           9501      NN50
D390017001                                                                                                                                                   N48
G08SS          Harper, Kyle                90017001    1 8  50C   28.53 1:00.27 1:34.38 2:10.39 2:47.87 3:25.99 4:04.42 4:43.27                P             N29
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 1002107 UNOV11012025 1:02.80S 1:05.97S                   4 7 0 0 35           9502      NN50
G08SS          Harper, Kyle                90017001    1 2  50C   30.53 1:05.97                                                                P             N84
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 1001109 UNOV11012025   55.60S 1:02.64S                   1 5 0 0 61           9501      NN20
G08SS          Harper, Kyle                90017001    1 2  50C   28.97 1:02.64                                                                P             N84
D08SS      Harper, Kyle                90017001    AGBR0713200916MM  502404 UNOV11022025   29.40S   29.69S                   4 0 0 0 29  0       09502      NN20
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 2002414 UNOV11022025 2:18.32S 2:24.08S                   2 2 0 0 32           9502      NN40
G08SS          Harper, Kyle                90017001    1 4  50C   32.05 1:08.51 1:45.82 2:24.08                                                P             N26
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 1003528 UNOV11022025 1:19.86S 1:20.09S                   4 8     25           9503      NN40
G08SS          Harper, Kyle                90017001    1 2  50C   37.08 1:20.09                                                                P             N84
D08SS      Harper, Kyle                90017001    AGBR0713200916MM 1003408 UNOV11022025 1:19.86S 1:20.09S                   8 8 0 0 61           9503      NN60
G08SS          Harper, Kyle                90017001    1 2  50C   37.08 1:20.09                                                                P             N84
D08SS      Hart, Connie R              90026501    AGBR1222201015FF 2001102 UNOV11012025 2:16.09S 2:13.72S                   1 3 0 0 15           9501      NN50
D390026501      Connie                                                                                                                                       N60
G08SS          Hart, Connie R              90026501    1 4  50C   30.22 1:04.69 1:39.59 2:13.72                                                P             N56
D08SS      Hart, Connie R              90026501    AGBR1222201015FF 1003108 UNOV11012025 1:15.42S 1:15.01S          1:14.26S 4 3 2 7  6  4  7.   4950300    NN02
G08SS          Hart, Connie R              90026501    1 2  50C   35.48 1:15.01                                                                P             N05
G08SS          Hart, Connie R              90026501    1 2  50C   35.13 1:14.26                                                                F             N94
D08SS      Hart, Connie R              90026501    AGBR1222201015FF  501112 UNOV11012025   27.10S   27.22S            27.18S 7 2 2 1  7  8  2.   8950150    NN31
D08SS      Hart, Connie R              90026501    AGBR1222201015FF  503403 UNOV11022025   34.10S   34.69S            33.69S 5 3 2 7  6  4  7.   4950300    NN41
D08SS      Hart, Connie R              90026501    AGBR1222201015FF 1001409 UNOV11022025 1:01.50S 1:00.20S          1:00.42S 1 6 1 5 13 15       59501      NN71
G08SS          Hart, Connie R              90026501    1 2  50C   28.72 1:00.20                                                                P             N05
G08SS          Hart, Connie R              90026501    1 2  50C   28.80 1:00.42                                                                F             N94
D08SS      Hart, Connie R              90026501    AGBR1222201015FF 2003413 UNOV11022025 2:48.70S 2:44.42S                   2 2 0 0 10           9503      NN50
G08SS          Hart, Connie R              90026501    1 4  50C   38.12 1:21.53 2:04.79 2:44.42                                                P             N56
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM  503103 UNOV11012025   31.30S   31.29S            30.87S 5 8 1 5 19 22       29503      NN22
D390017064                                                                                                                                                   N48
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM 1002107 UNOV11012025 1:02.64S 1:03.12S          1:03.07S 3 2 1 6 15 14       49502      NN82
G08SS          Maxwell, Hamish             90017064    1 2  50C   30.79 1:03.12                                                                P             N06
G08SS          Maxwell, Hamish             90017064    1 2  50C   31.27 1:03.07                                                                F             N95
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM 1001109 UNOV11012025   54.30S   54.20S            53.95S 2 1 1 4 15 12       29501      NN22
G08SS          Maxwell, Hamish             90017064    1 2  50C   26.36   54.20                                                                P             N85
G08SS          Maxwell, Hamish             90017064    1 2  50C   26.41   53.95                                                                F             N75
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM  504111 UNOV11012025   27.21S   27.06S            27.11S 2 3 1 3 17 14       49504      NN12
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM  502404 UNOV11022025   28.32S   27.82S            27.78S 5 1 1 4 13 12       29502      NN22
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM 1003408 UNOV11022025 1:13.26S 1:12.00S          1:11.64S 1 4 1 7 23 15       59503      NN92
G08SS          Maxwell, Hamish             90017064    1 2  50C   33.68 1:12.00                                                                P             N06
G08SS          Maxwell, Hamish             90017064    1 2  50C   34.11 1:11.64                                                                F             N95
D08SS      Maxwell, Hamish             90017064    AGBR0211200916MM  501412 UNOV11022025   23.80S   24.15S            23.93S 4 3 2 1  7  8  3.   8950100    NN42
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 1001529 UNOV11022025 1:03.80S 1:03.46S                   4 1     14           9501      NN70
D390013219      Ruby                                                                                                                                         N99
G08SS          McInnes, Ruby J             90013219    1 2  50C   30.67 1:03.46                                                                P             N35
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 1004110 UNOV11012025 1:11.96S 1:12.66S                   6 4 0 0 35           9504      NN90
G08SS          McInnes, Ruby J             90013219    1 2  50C   33.51 1:12.66                                                                P             N35
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 2001102 UNOV11012025 2:15.90S 2:17.20S                   1 4 0 0 29           9501      NN80
G08SS          McInnes, Ruby J             90013219    1 4  50C   31.67 1:06.42 1:41.82 2:17.20                                                P             N86
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 2005106 UNOV11012025 2:34.65S      DQS                   4 9 0 0  0           9505      NN50
G08SS          McInnes, Ruby J             90013219    1 4  50C   34.79 1:14.95 2:01.69 2:38.69                                                P             N96
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF  503403 UNOV11022025   36.88S   36.91S                   4 4 0 0 30           9503      NN40
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 2003413 UNOV11022025 2:55.92S 2:51.86S                   3 9 0 0 21           9503      NN90
G08SS          McInnes, Ruby J             90013219    1 4  50C   39.29 1:23.48 2:07.93 2:51.86                                                P             N96
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 4005501 UNOV11022025 5:26.96S                   5:24.60S     4 9    17       59505      NN90
G08SS          McInnes, Ruby J             90013219    1 8  50C   34.29 1:15.00 1:58.36 2:41.27 3:27.01 4:11.23 4:49.31 5:24.60                F             N69
D08SS      McInnes, Ruby J             90013219    AGBR1110201015FF 1001409 UNOV11022025 1:03.80S 1:03.46S                   8 1 0 0 43           9501      NN80
G08SS          McInnes, Ruby J             90013219    1 2  50C   30.67 1:03.46                                                                P             N35
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 1003528 UNOV11022025 1:19.19S 1:19.17S                   5 1     20           9503      NN50
D390033865                                                                                                                                                   N58
G08SS          Relly, Lewis                90033865    1 2  50C   37.54 1:19.17                                                                P             N05
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 4001101 UNOV11012025 4:36.90S 4:38.33S                   1 8 0 0 33           9501      NN60
G08SS          Relly, Lewis                90033865    1 8  50C   30.06 1:03.87 1:38.27 2:13.67 2:49.92 3:26.39 4:02.85 4:38.33                P             N59
D08SS      Relly, Lewis                90033865    AGBR0307201114MM  503103 UNOV11012025   34.58S   35.75S                   2 2 0 0 58           9503      NN10
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 2005526 UNOV11022025 2:29.50S 2:30.32S                   3 7     23           9505      NN50
G08SS          Relly, Lewis                90033865    1 4  50C   32.79 1:11.56 1:56.35 2:30.32                                                P             N46
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 2001522 UNOV11022025 2:10.30S 2:11.28S                   3 6     15           9501      NN40
G08SS          Relly, Lewis                90033865    1 4  50C   29.31 1:02.45 1:37.21 2:11.28                                                P             N46
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 1004530 UNOV11022025 1:07.70S 1:09.26S                   1 7     10           9504      NN40
G08SS          Relly, Lewis                90033865    1 2  50C   32.27 1:09.26                                                                P             N05
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 1001109 UNOV11012025   58.68S 1:00.09S                   6 1 0 0 57           9501      NN40
G08SS          Relly, Lewis                90033865    1 2  50C   28.78 1:00.09                                                                P             N05
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 2001402 UNOV11022025 2:10.30S 2:11.28S                   7 6 0 0 53           9501      NN60
G08SS          Relly, Lewis                90033865    1 4  50C   29.31 1:02.45 1:37.21 2:11.28                                                P             N46
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 2005406 UNOV11022025 2:29.50S 2:30.32S                   7 7 0 0 61           9505      NN70
G08SS          Relly, Lewis                90033865    1 4  50C   32.79 1:11.56 1:56.35 2:30.32                                                P             N46
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 1003408 UNOV11022025 1:19.19S 1:19.17S                   9 1 0 0 56           9503      NN70
G08SS          Relly, Lewis                90033865    1 2  50C   37.54 1:19.17                                                                P             N05
D08SS      Relly, Lewis                90033865    AGBR0307201114MM 1004410 UNOV11022025 1:07.70S 1:09.26S                   5 7 0 0 47           9504      NN70
G08SS          Relly, Lewis                90033865    1 2  50C   32.27 1:09.26                                                                P             N05
D08SS      Stericker, Theo             90024381    AGBR0823200916MM 1004530 UNOV11022025 1:05.60S      NSS                   1 5      0           9504      NN21
D390024381                                                                                                                                                   N48
G08SS          Stericker, Theo             90024381    1 2  50C                                                                                P             N84
D08SS      Stericker, Theo             90024381    AGBR0823200916MM 1001109 UNOV11012025   56.60S   58.98S                   6 5 0 0 53           9501      NN41
G08SS          Stericker, Theo             90024381    1 2  50C   27.40   58.98                                                                P             N95
D08SS      Stericker, Theo             90024381    AGBR0823200916MM 1002107 UNOV11012025 1:03.17S 1:04.44S          1:07.08S 4 1 1 9 24 19       99502      NN03
G08SS          Stericker, Theo             90024381    1 2  50C   30.77 1:04.44                                                                P             N06
G08SS          Stericker, Theo             90024381    1 2  50C   32.10 1:07.08                                                                F             N95
D08SS      Stericker, Theo             90024381    AGBR0823200916MM  504111 UNOV11012025   27.60S   28.28S                   2 2 0 0 34           9504      NN21
D08SS      Stericker, Theo             90024381    AGBR0823200916MM  502404 UNOV11022025   29.70S   29.77S                   3 3 0 0 30           9502      NN21
D08SS      Stericker, Theo             90024381    AGBR0823200916MM  501412 UNOV11022025   25.30S   25.75S            26.09S 3 4 1 8 27 20       09501      NN32
D08SS      Stericker, Theo             90024381    AGBR0823200916MM 1004410 UNOV11022025 1:05.60S      NSS                   5 5 0 0  0           9504      NN41
G08SS          Stericker, Theo             90024381    1 2  50C                                                                                P             N84
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF 2001102 UNOV11012025 2:10.00S 2:14.12S                   2 6 0 0 17           9501      NN52
D390029184      Brooke                                                                                                                                       N70
G08SS          Stevenson, Brooke C         90029184    1 4  50C   31.00 1:05.23 1:40.29 2:14.12                                                P             N58
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF  501112 UNOV11012025   27.30S   28.86S                   8 7 0 0 32           9501      NN22
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF 2002114 UNOV11012025 2:37.16S 2:39.96S                   2 9 0 0 36           9502      NN82
G08SS          Stevenson, Brooke C         90029184    1 4  50C   37.81 1:18.41 1:59.53 2:39.96                                                P             N78
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF 4001401 UNOV11022025 4:46.02S 4:45.46S          4:44.81S 4 9 1 9 10 10  1.   0950100    NN34
G08SS          Stevenson, Brooke C         90029184    1 8  50C   32.13 1:07.68 1:44.36 2:21.12 2:57.96 3:34.53 4:11.57 4:45.46                P             N61
G08SS          Stevenson, Brooke C         90029184    1 8  50C   31.73 1:07.41 1:43.92 2:20.54 2:57.83 3:34.64 4:10.56 4:44.81                F             N51
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF 1002407 UNOV11022025 1:13.09S 1:12.49S                   1 3 0 0 32           9502      NN62
G08SS          Stevenson, Brooke C         90029184    1 2  50C   35.42 1:12.49                                                                P             N27
D08SS      Stevenson, Brooke C         90029184    AGBR0301201015FF 1001409 UNOV11022025   59.70S 1:01.89S          1:01.22S 4 1 1 0 26 17       79501      NN83
G08SS          Stevenson, Brooke C         90029184    1 2  50C   30.31 1:01.89                                                                P             N17
G08SS          Stevenson, Brooke C         90029184    1 2  50C   30.08 1:01.22                                                                F             N07
E08SS      ASSWSEX  X 2006301 UNOV  011012025 1:44.05S                   1:44.36S     2 7     4                                                4N13001  X    N26
F08SS          SSWSEXAMaxwell, Hamish             90017064    GBR0211200916M  1             90017064                                                         N58
G08SS          Maxwell, Hamish             90017064    1 4  50C   24.64                                                                        F             N25
F08SS          SSWSEXAHarper, Kyle                90017001    GBR0713200916M  2             90017001                                                         N37
G08SS          Harper, Kyle                90017001    1 4  50C   49.95                                                                        F             N14
F08SS          SSWSEXAHaddow, Gracie              90017307    GBR0423201015F  3             90017307                                                         N87
G08SS          Haddow, Gracie              90017307    1 4  50C 1:17.64                                                                        F             N94
F08SS          SSWSEXAHart, Connie R              90026501    GBR1222201015F  4             90026501      Connie                                             N69
G08SS          Hart, Connie R              90026501    1 4  50C 1:44.36                                                                        F             N54
E08SS      BSSWSEX  X 2006301 UNOV  011012025 1:50.21S                   1:49.99S     1 2    13                                                3N13001  X    N36
F08SS          SSWSEXBCurrie, Sam                 90011504    GBR0926201015M  1             90011504                                                         N96
G08SS          Currie, Sam                 90011504    1 4  50C   26.27                                                                        F             N73
F08SS          SSWSEXBStericker, Theo             90024381    GBR0823200916M  2             90024381                                                         N68
G08SS          Stericker, Theo             90024381    1 4  50C   52.71                                                                        F             N35
F08SS          SSWSEXBMcInnes, Ruby J             90013219    GBR1110201015F  3             90013219      Ruby                                               N39
G08SS          McInnes, Ruby J             90013219    1 4  50C 1:22.53                                                                        F             N84
F08SS          SSWSEXBStevenson, Brooke C         90029184    GBR0301201015F  4             90029184      Brooke                                             N81
G08SS          Stevenson, Brooke C         90029184    1 4  50C 1:49.99                                                                        F             N76
C18SS      SSNUAXUniversity of Aberdeen PerformUoAPS           Aquatics Centre, Aberd                      Aberdeen            GrAB24 1SX                    N13
D08SS      Aberdein, James A           90014465    AGBR0803200817MM  503103 UNOV11012025   30.80S   31.05S                   7 1 0 0 17           9503      NN11
D390014465                                                                                                                                                   N48
D08SS      Aberdein, James A           90014465    AGBR0803200817MM 2003113 UNOV11012025 2:29.48S 2:27.80S                   2 2 0 0 13           9503      NN71
G08SS          Aberdein, James A           90014465    1 4  50C   32.93 1:10.39 1:48.74 2:27.80                                                P             N57
D08SS      Aberdein, James A           90014465    AGBR0803200817MM 2005406 UNOV11022025 2:15.17S 2:15.92S          2:14.30S 3 6 1 9 12  9  2.   9950500    NN33
G08SS          Aberdein, James A           90014465    1 4  50C   29.73 1:04.54 1:44.03 2:15.92                                                P             N47
G08SS          Aberdein, James A           90014465    1 4  50C   29.69 1:04.39 1:43.10 2:14.30                                                F             N37
D08SS      Aberdein, James A           90014465    AGBR0803200817MM 1003408 UNOV11022025 1:07.79S 1:08.31S                   3 6 0 0 11           9503      NN71
G08SS          Aberdein, James A           90014465    1 2  50C   31.94 1:08.31                                                                P             N06
D08SS      Aitchison, Kallum S         1228600     AGBR1026200619MM 4001101 UNOV11012025 4:24.18S 4:18.28S                   2 5 0 0 11           9501      NN62
D31228600       Kallum                                                                                                                                       N50
G08SS          Aitchison, Kallum S         1228600     1 8  50C   27.39   59.09 1:31.98 2:05.50 2:38.99 3:12.27 3:45.54 4:18.28                P             N21
D08SS      Aitchison, Kallum S         1228600     AGBR1026200619MM  503103 UNOV11012025   29.60S   30.23S                   5 3 0 0 11           9503      NN02
D08SS      Aitchison, Kallum S         1228600     AGBR1026200619MM 2003113 UNOV11012025 2:23.80S 2:27.20S          2:27.00S 2 3 1 9 10  8  3.   8950300    NN14
G08SS          Aitchison, Kallum S         1228600     1 4  50C   32.16 1:09.89 1:49.32 2:27.20                                                P             N48
G08SS          Aitchison, Kallum S         1228600     1 4  50C   32.67 1:09.25 1:47.87 2:27.00                                                F             N48
D08SS      Aitchison, Kallum S         1228600     AGBR1026200619MM 2005406 UNOV11022025 2:18.80S 2:17.99S                   2 1 0 0 17           9505      NN72
G08SS          Aitchison, Kallum S         1228600     1 4  50C   29.99 1:07.28 1:45.17 2:17.99                                                P             N58
D08SS      Aitchison, Kallum S         1228600     AGBR1026200619MM 1003408 UNOV11022025 1:04.39S 1:05.50S          1:05.29S 4 3 2 7  6  7  4.   7950300    NN14
G08SS          Aitchison, Kallum S         1228600     1 2  50C   31.07 1:05.50                                                                P             N96
G08SS          Aitchison, Kallum S         1228600     1 2  50C   30.40 1:05.29                                                                F             N86
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM  503103 UNOV11012025   31.50S      NSS                   7 9 0 0  0           9503      NN29
D31728228       Alif                                                                                                                                         N79
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM  504111 UNOV11012025   28.10S      NSS                   2 8 0 0  0           9504      NN29
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM 2003113 UNOV11012025 2:36.00S      NSS                   2 8 0 0  0           9503      NN59
G08SS          Ammar, Alif                 1728228     1 4  50C                                                                                P             N03
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM  502404 UNOV11022025   29.30S   29.99S                   6 0 0 0 31           9502      NN49
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM 1003408 UNOV11022025 1:10.42S      NSS                   2 1 0 0  0           9503      NN59
G08SS          Ammar, Alif                 1728228     1 2  50C                                                                                P             N03
D08SS      Ammar, Alif                 1728228     AGBR0401200916MM  501412 UNOV11022025   25.79S   25.70S                   3 1 0 0 26           9501      NN39
D08SS      Ammar, Aliya Qaisara Q      1728226     AGBR0324201114FF  504411 UNOV11022025   32.30S   32.78S                   2 8 0 0 54           9504      NN52
D31728226       Aliya                                                                                                                                        N10
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 1004110 UNOV11012025 1:17.99S 1:22.33S                   6 1 0 0 55           9504      NN92
D390026732                                                                                                                                                   N48
G08SS          Ancketill, Isabella         90026732    1 2  50C   37.59 1:22.33                                                                P             N47
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 2002114 UNOV11012025 2:38.36S 2:39.20S                   1 3 0 0 34           9502      NN92
G08SS          Ancketill, Isabella         90026732    1 4  50C   36.79 1:16.98 1:58.45 2:39.20                                                P             N98
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 4001401 UNOV11022025 5:06.60S 4:58.33S                   1 0 0 0 26           9501      NN92
G08SS          Ancketill, Isabella         90026732    1 8  50C   33.02 1:09.83 1:47.80 2:25.80 3:04.39 3:43.01 4:21.15 4:58.33                P             N71
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 2004405 UNOV11022025 3:04.20S 2:57.29S                   1 7 0 0 33           9504      NN92
G08SS          Ancketill, Isabella         90026732    1 4  50C   38.92 1:24.73 2:12.42 2:57.29                                                P             N98
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 2001102 UNOV11012025 2:22.60S 2:21.15S                   6 7 0 0 42           9501      NN82
G08SS          Ancketill, Isabella         90026732    1 4  50C   32.73 1:08.54 1:45.24 2:21.15                                                P             N88
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 1002527 UNOV11022025 1:15.20S 1:15.90S                   1 0      6           9502      NN62
G08SS          Ancketill, Isabella         90026732    1 2  50C   36.72 1:15.90                                                                P             N47
D08SS      Ancketill, Isabella         90026732    AGBR0714201213FF 1002407 UNOV11022025 1:15.20S 1:15.90S                   5 0 0 0 41           9502      NN92
G08SS          Ancketill, Isabella         90026732    1 2  50C   36.72 1:15.90                                                                P             N47
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 1001109 UNOV11012025   56.40S   57.51S                   7 5 0 0 44           9501      NN11
D390032446                                                                                                                                                   N48
G08SS          Anderson, Aiden             90032446    1 2  50C   27.89   57.51                                                                P             N75
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 4001101 UNOV11012025 4:01.30S 4:05.10S          4:06.75S 4 5 1 5  2  4  7.   4950100    NN92
G08SS          Anderson, Aiden             90032446    1 8  50C   27.65   58.09 1:28.82 1:59.86 2:31.10 3:02.83         4:05.10                P             N39
G08SS          Anderson, Aiden             90032446    1 8  50C   27.72   58.31 1:30.03 2:01.67 2:32.95 3:04.74 3:36.38 4:06.75                F             N00
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 2004105 UNOV11012025 2:09.70S 2:13.78S          2:15.53S 4 3 1 1  7  8  3.   8950400    NN03
G08SS          Anderson, Aiden             90032446    1 4  50C   29.60 1:04.00 1:39.06 2:13.78                                                P             N37
G08SS          Anderson, Aiden             90032446    1 4  50C   30.38 1:05.37 1:40.91 2:15.53                                                F             N37
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 4005201 UNOV11012025 4:44.87S                   4:41.71S     5 0     7  4.   6950500    NN81
G08SS          Anderson, Aiden             90032446    1 8  50C   30.05 1:04.76 1:40.49 2:15.45 2:57.91 3:39.52 4:11.42 4:41.71                F             N20
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 2001402 UNOV11022025 1:57.80S 1:59.92S                   4 6 0 0 14           9501      NN61
G08SS          Anderson, Aiden             90032446    1 4  50C   27.76   58.38 1:29.37 1:59.92                                                P             N37
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 2005406 UNOV11022025 2:16.40S 2:18.85S                   4 2 0 0 19           9505      NN61
G08SS          Anderson, Aiden             90032446    1 4  50C   29.85 1:06.79 1:48.38 2:18.85                                                P             N57
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 1004410 UNOV11022025 1:02.10S 1:04.01S                   4 9 0 0 36           9504      NN41
G08SS          Anderson, Aiden             90032446    1 2  50C   29.63 1:04.01                                                                P             N85
D08SS      Anderson, Aiden             90032446    AGBR0417201015MM 8001502 UNOV11022025 8:22.60S                   8:27.61S     3 3     2  9.   2950100    NN81
G08SS          Anderson, Aiden             90032446    116  50C   28.93 1:00.82 1:32.90 2:04.81 2:36.71 3:08.88 3:41.15 4:13.45 4:45.58 5:17.48F             N81
G08SS          Anderson, Aiden             90032446    216  50C 5:49.44 6:21.61 6:53.56 7:25.34 7:56.87 8:27.61                                F             N39
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 2001102 UNOV11012025 2:16.89S 2:16.34S                   1 1 0 0 26           9501      NN61
D390032447                                                                                                                                                   N48
G08SS          Anderson, Esmay             90032447    1 4  50C   30.81 1:05.52 1:41.41 2:16.34                                                P             N47
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF  501112 UNOV11012025   29.74S   30.05S                   2 8 0 0 57           9501      NN01
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 8001202 UNOV11012025 9:56.60S                   9:42.98S     2 0    10  1.   3950100    NN91
G08SS          Anderson, Esmay             90032447    116  50C   31.19 1:06.83 1:43.37 2:19.96 2:56.75 3:33.95 4:10.71 4:47.51 5:24.82 6:02.30F             N02
G08SS          Anderson, Esmay             90032447    216  50C 6:39.70 7:17.21 7:54.45 8:31.66 9:08.32 9:42.98                                F             N59
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 4001401 UNOV11022025 4:43.62S 4:45.55S                   4 8 0 0 11           9501      NN61
G08SS          Anderson, Esmay             90032447    1 8  50C   31.07 1:06.14 1:42.32 2:19.18 2:56.03 3:33.12 4:10.19 4:45.55                P             N30
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 1001529 UNOV11022025 1:04.00S 1:04.51S                   2 8     21           9501      NN31
G08SS          Anderson, Esmay             90032447    1 2  50C   30.70 1:04.51                                                                P             N06
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 2005106 UNOV11012025 2:45.26S 2:48.30S                   5 1 0 0 50           9505      NN61
G08SS          Anderson, Esmay             90032447    1 4  50C   40.57 1:24.78 2:12.28 2:48.30                                                P             N57
D08SS      Anderson, Esmay             90032447    AGBR0214201213FF 1001409 UNOV11022025 1:04.00S 1:04.51S                   6 8 0 0 52           9501      NN51
G08SS          Anderson, Esmay             90032447    1 2  50C   30.70 1:04.51                                                                P             N06
D08SS      Anderson, Taylor            90032445    AGBR1128200718MM  504111 UNOV11012025   28.66S      NSS                   1 7 0 0  0           9504      NN61
D390032445                                                                                                                                                   N48
D08SS      Anderson, Taylor            90032445    AGBR1128200718MM  502404 UNOV11022025   29.85S   30.63S                   3 2 0 0 42           9502      NN71
D08SS      Anderson, Taylor            90032445    AGBR1128200718MM  501412 UNOV11022025   25.98S   26.93S                   3 0 0 0 51           9501      NN71
D08SS      Anderson, Taylor            90032445    AGBR1128200718MM 1002107 UNOV11012025 1:06.74S      NSS                   6 4 0 0  0           9502      NN91
G08SS          Anderson, Taylor            90032445    1 2  50C                                                                                P             N35
D08SS      Angelakis, Panos            1286036     AGBR0723200718MM 4001101 UNOV11012025 4:14.50S 4:17.01S          4:17.82S 4 6 1 0  9  9  2.   9950100    NN43
D31286036       Panos                                                                                                                                        N20
G08SS          Angelakis, Panos            1286036     1 8  50C   28.56   59.87 1:32.28 2:05.17 2:37.85 3:11.01 3:44.52 4:17.01                P             N40
G08SS          Angelakis, Panos            1286036     1 8  50C   28.47   59.51 1:31.26 2:03.84 2:36.74 3:10.12 3:44.00 4:17.82                F             N30
D08SS      Angelakis, Panos            1286036     AGBR0723200718MM 1001109 UNOV11012025   54.80S   56.55S                   2 0 0 0 35           9501      NN51
G08SS          Angelakis, Panos            1286036     1 2  50C   27.35   56.55                                                                P             N06
D08SS      Angelakis, Panos            1286036     AGBR0723200718MM 2001402 UNOV11022025 2:00.30S 2:01.33S                   4 1 0 0 19           9501      NN81
G08SS          Angelakis, Panos            1286036     1 4  50C   27.83   58.22 1:29.88 2:01.33                                                P             N57
D08SS      Angelakis, Panos            1286036     AGBR0723200718MM 8001502 UNOV11022025 8:50.40S                   8:59.44S     3 9    10  1.   8950100    NN32
G08SS          Angelakis, Panos            1286036     116  50C   30.16 1:03.11 1:36.63 2:10.60 2:44.65 3:18.99 3:53.30 4:27.49 5:01.97 5:35.91F             N12
G08SS          Angelakis, Panos            1286036     216  50C 6:09.64 6:43.72 7:17.75 7:52.20 8:26.49 8:59.44                                F             N79
D08SS      Arthur, Andrew              894228      AGBR0604200223MM  503103 UNOV11012025   27.63S   28.73S            28.05S 7 4 3 4  1  1 10.   1950300    NN02
D3894228        Andrew                                                                                                                                       N50
D08SS      Arthur, Andrew              894228      AGBR0604200223MM 2003113 UNOV11012025 2:11.16S 2:17.47S          2:15.53S 4 4 1 4  1  1 10.   1950300    NN62
G08SS          Arthur, Andrew              894228      1 4  50C   30.46 1:04.81 1:40.18 2:17.47                                                P             N07
G08SS          Arthur, Andrew              894228      1 4  50C   30.18 1:04.31 1:39.16 2:15.53                                                F             N96
D08SS      Arthur, Andrew              894228      AGBR0604200223MM 2001402 UNOV11022025 1:56.80S 1:54.32S                   3 3 0 0  5           9501      NN11
G08SS          Arthur, Andrew              894228      1 4  50C   26.18   54.68 1:24.13 1:54.32                                                P             N86
D08SS      Arthur, Andrew              894228      AGBR0604200223MM 1003408 UNOV11022025 1:00.64S 1:01.93S          1:01.61S 4 4 2 4  1  1 10.   1950300    NN62
G08SS          Arthur, Andrew              894228      1 2  50C   28.96 1:01.93                                                                P             N65
G08SS          Arthur, Andrew              894228      1 2  50C   28.70 1:01.61                                                                F             N55
D08SS      Baird, Morven               90029325    AGBR0708201213FF 1003108 UNOV11012025 1:23.50S 1:24.20S                   1 1 0 0 41           9503      NN70
D390029325      Morven                                                                                                                                       N80
G08SS          Baird, Morven               90029325    1 2  50C   39.51 1:24.20                                                                P             N25
D08SS      Baird, Morven               90029325    AGBR0708201213FF  503403 UNOV11022025   38.53S   39.27S                   2 2 0 0 53           9503      NN30
D08SS      Baird, Morven               90029325    AGBR0708201213FF 2003413 UNOV11022025 2:55.60S      DQS                   4 9 0 0  0           9503      NN40
G08SS          Baird, Morven               90029325    1 4  50C                                                                                P             N04
D08SS      Batey, Ewan                 1310030     AGBR0517200520MM  503103 UNOV11012025   29.90S   30.06S            29.89S 6 6 3 8  8  7  4.   7950300    NN70
D31310030                                                                                                                                                    N28
D08SS      Batey, Ewan                 1310030     AGBR0517200520MM 1001109 UNOV11012025   54.20S   53.74S                   4 1 0 0 12           9501      NN39
G08SS          Batey, Ewan                 1310030     1 2  50C   25.29   53.74                                                                P             N04
D08SS      Batey, Ewan                 1310030     AGBR0517200520MM  502404 UNOV11022025   27.10S   26.88S            26.79S 5 3 2 8  8  6  5.   6950200    NN70
D08SS      Batey, Ewan                 1310030     AGBR0517200520MM  501412 UNOV11022025   23.50S   24.11S            23.78S 6 3 2 2  5  5  6.   5950100    NN50
D08SS      Beeley, Tom                 820745      AGBR0602199926MM 2004105 UNOV11012025 1:56.60S 1:59.59S          1:57.58S 4 4 1 4  1  1 10.   1950400    NN61
D3820745                                                                                                                                                     N38
G08SS          Beeley, Tom                 820745      1 4  50C   26.01   56.08 1:27.56 1:59.59                                                P             N55
G08SS          Beeley, Tom                 820745      1 4  50C   25.92   55.92 1:26.76 1:57.58                                                F             N55
D08SS      Beeley, Tom                 820745      AGBR0602199926MM 1001109 UNOV11012025   50.80S   52.19S            53.58S 3 5 2 8  8  8  3.   8950100    NN90
G08SS          Beeley, Tom                 820745      1 2  50C   25.28   52.19                                                                P             N04
G08SS          Beeley, Tom                 820745      1 2  50C   25.59   53.58                                                                F             N04
D08SS      Beeley, Tom                 820745      AGBR0602199926MM  504111 UNOV11012025   24.30S   24.85S            24.71S 3 5 2 3  3  2  9.   2950400    NN70
D08SS      Beeley, Tom                 820745      AGBR0602199926MM  502404 UNOV11022025   24.64S   25.55S            24.90S 5 4 2 5  2  2  9.   2950200    NN70
D08SS      Beeley, Tom                 820745      AGBR0602199926MM 1004410 UNOV11022025   52.20S   54.64S            53.10S 4 4 2 4  1  1 10.   1950400    NN80
G08SS          Beeley, Tom                 820745      1 2  50C   25.63   54.64                                                                P             N04
G08SS          Beeley, Tom                 820745      1 2  50C   25.08   53.10                                                                F             N93
D08SS      Beeley, Tom                 820745      AGBR0602199926MM  501412 UNOV11022025   23.35S   24.19S            23.85S 4 5 2 8  8  7  4.   7950100    NN80
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 2005106 UNOV11012025 2:26.42S 2:26.55S          2:25.33S 3 6 1 8  8  6  5.   6950500    NN83
D31104538       Catherine                                                                                                                                    N61
G08SS          Boddie, Catherine J         1104538     1 4  50C   31.52 1:08.17 1:52.34 2:26.55                                                P             N18
G08SS          Boddie, Catherine J         1104538     1 4  50C   30.77 1:07.67 1:50.22 2:25.33                                                F             N08
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 1004110 UNOV11012025 1:05.50S 1:06.58S          1:06.22S 4 7 2 9 11 10  1.   0950400    NN83
G08SS          Boddie, Catherine J         1104538     1 2  50C   31.99 1:06.58                                                                P             N76
G08SS          Boddie, Catherine J         1104538     1 2  50C   30.86 1:06.22                                                                F             N66
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 2002114 UNOV11012025 2:25.14S 2:24.67S          2:23.06S 3 6 1 7  6  5  6.   5950200    NN73
G08SS          Boddie, Catherine J         1104538     1 4  50C   34.46 1:11.03 1:48.01 2:24.67                                                P             N18
G08SS          Boddie, Catherine J         1104538     1 4  50C   33.69 1:09.58 1:46.83 2:23.06                                                F             N18
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 2004405 UNOV11022025 2:25.30S 2:25.35S          2:24.28S 2 5 1 6  4  3  8.   3950400    NN73
G08SS          Boddie, Catherine J         1104538     1 4  50C   31.88 1:08.55 1:46.54 2:25.35                                                P             N28
G08SS          Boddie, Catherine J         1104538     1 4  50C   31.40 1:08.33 1:46.27 2:24.28                                                F             N08
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 1001409 UNOV11022025 1:00.00S 1:02.09S                   3 8 0 0 28           9501      NN22
G08SS          Boddie, Catherine J         1104538     1 2  50C   29.72 1:02.09                                                                P             N76
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF  504411 UNOV11022025   29.50S   30.44S                   6 1 0 0 19           9504      NN71
D08SS      Boddie, Catherine J         1104538     AGBR0409200421FF 4005501 UNOV11022025 5:04.70S                   5:07.80S     5 6     5  6.   5950500    NN52
G08SS          Boddie, Catherine J         1104538     1 8  50C   31.47 1:08.74 1:47.92 2:26.52 3:11.15 3:56.08 4:32.37 5:07.80                F             N01
D08SS      Boddie, James               1291380     AGBR1122200718MM 4001101 UNOV11012025 3:57.60S 4:00.80S          3:55.72S 3 4 1 4  1  1 10.   1950100    NN02
D31291380                                                                                                                                                    N38
G08SS          Boddie, James               1291380     1 8  50C   27.62   58.02 1:28.89 2:00.91 2:30.56 3:00.92 3:31.30 4:00.80                P             N09
G08SS          Boddie, James               1291380     1 8  50C   26.52   55.85 1:25.81 1:56.07 2:26.00 2:56.55 3:26.59 3:55.72                F             N19
D08SS      Boddie, James               1291380     AGBR1122200718MM 2004105 UNOV11012025 2:08.60S 2:13.79S          2:17.25S 2 5 1 8  8  9  2.   9950400    NN12
G08SS          Boddie, James               1291380     1 4  50C   29.10 1:03.59 1:38.42 2:13.79                                                P             N46
G08SS          Boddie, James               1291380     1 4  50C   29.61 1:04.80 1:42.38 2:17.25                                                F             N36
D08SS      Boddie, James               1291380     AGBR1122200718MM 2003113 UNOV11012025 2:24.30S 2:25.97S          2:32.19S 3 6 1 7  6  9  2.   9950300    NN12
G08SS          Boddie, James               1291380     1 4  50C   34.00 1:11.30 1:48.26 2:25.97                                                P             N36
G08SS          Boddie, James               1291380     1 4  50C   33.60 1:13.01 1:52.34 2:32.19                                                F             N26
D08SS      Boddie, James               1291380     AGBR1122200718MM 4005201 UNOV11012025 4:29.00S                   4:32.10S     5 5     2  9.   2950500    NN70
G08SS          Boddie, James               1291380     1 8  50C   28.83 1:03.18 1:39.41 2:15.12 2:53.64 3:32.88 4:03.09 4:32.10                F             N29
D08SS      Boddie, James               1291380     AGBR1122200718MM 2001402 UNOV11022025 1:51.70S 1:53.38S          1:53.52S 3 5 1 3  3  5  6.   5950100    NN02
G08SS          Boddie, James               1291380     1 4  50C   26.46   55.20 1:24.24 1:53.38                                                P             N16
G08SS          Boddie, James               1291380     1 4  50C   26.15   54.56 1:24.09 1:53.52                                                F             N16
D08SS      Boddie, James               1291380     AGBR1122200718MM 2005406 UNOV11022025 2:05.40S 2:09.54S          2:10.14S 4 4 1 6  4  6  5.   6950500    NN12
G08SS          Boddie, James               1291380     1 4  50C   28.66 1:03.01 1:40.52 2:09.54                                                P             N36
G08SS          Boddie, James               1291380     1 4  50C   28.51 1:03.90 1:41.30 2:10.14                                                F             N26
D08SS      Boddie, James               1291380     AGBR1122200718MM 1004410 UNOV11022025   58.00S 1:01.16S                   2 6 0 0 18           9504      NN30
G08SS          Boddie, James               1291380     1 2  50C   28.46 1:01.16                                                                P             N94
D08SS      Boddie, James               1291380     AGBR1122200718MM 8001502 UNOV11022025 8:15.70S                   8:12.22S     3 5     1 10.   1950100    NN80
G08SS          Boddie, James               1291380     116  50C   26.80   57.02 1:27.69 1:58.63 2:29.56 3:00.62 3:31.85 4:02.86 4:33.81 5:05.27F             N60
G08SS          Boddie, James               1291380     216  50C 5:36.97 6:08.73 6:39.91 7:11.57 7:42.60 8:12.22                                F             N38
D08SS      Brechin, Kirsty             90006102    AGBR0505200817FF 1004110 UNOV11012025 1:03.40S 1:06.70S                   4 3 0 0 12           9504      NN51
D390006102      Kirsty                                                                                                                                       N80
G08SS          Brechin, Kirsty             90006102    1 2  50C   30.87 1:06.70                                                                P             N06
D08SS      Brechin, Kirsty             90006102    AGBR0505200817FF  501112 UNOV11012025   27.90S   29.22S                   7 0 0 0 37           9501      NN11
D08SS      Brechin, Kirsty             90006102    AGBR0505200817FF 1001409 UNOV11022025 1:01.80S 1:04.55S                   1 0 0 0 53           9501      NN61
G08SS          Brechin, Kirsty             90006102    1 2  50C   30.48 1:04.55                                                                P             N06
D08SS      Brechin, Kirsty             90006102    AGBR0505200817FF  504411 UNOV11022025   28.50S   29.64S                   6 3 0 0 13           9504      NN11
D08SS      Burr, Layton                1291403     AGBR0225200619MM 1001109 UNOV11012025   53.80S   54.14S                   2 2 0 0 14           9501      NN00
D31291403                                                                                                                                                    N38
G08SS          Burr, Layton                1291403     1 2  50C   25.90   54.14                                                                P             N64
D08SS      Campbell, Jamie             90022729    AGBR0601200817MM  503103 UNOV11012025   32.80S   33.01S                   4 0 0 0 36           9503      NN80
D390022729                                                                                                                                                   N58
D08SS      Campbell, Jamie             90022729    AGBR0601200817MM  502404 UNOV11022025   31.49S   31.40S                   1 5 0 0 52           9502      NN90
D08SS      Campbell, Jamie             90022729    AGBR0601200817MM  501412 UNOV11022025   25.60S   26.21S                   3 2 0 0 38           9501      NN90
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 2001522 UNOV11022025 2:07.65S 1:59.41S                   2 4      1           9501      NN60
D390019608                                                                                                                                                   N58
G08SS          Cantley, Alex               90019608    1 4  50C   27.65   58.27 1:29.03 1:59.41                                                P             N56
D08SS      Cantley, Alex               90019608    AGBR0721201015MM  503103 UNOV11012025   31.60S   31.57S            31.03S 6 9 2 5 20 11       19503      NN31
D08SS      Cantley, Alex               90019608    AGBR0721201015MM  504111 UNOV11012025   27.70S   28.04S                   2 7 0 0 31  0       09504      NN50
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 2003113 UNOV11012025 2:32.20S 2:26.87S                   3 7 0 0  9  0       09503      NN90
G08SS          Cantley, Alex               90019608    1 4  50C   32.97 1:10.38 1:48.44 2:26.87                                                P             N86
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 4005201 UNOV11012025 5:03.20S                   4:45.89S     3 2    11       19505      NN80
G08SS          Cantley, Alex               90019608    1 8  50C   30.17 1:04.88 1:42.56 2:19.71 2:59.48 3:40.11 4:13.82 4:45.89                F             N69
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 2005406 UNOV11022025 2:21.30S 2:16.83S                   4 9 0 0 15           9505      NN90
G08SS          Cantley, Alex               90019608    1 4  50C   29.42 1:05.25 1:44.71 2:16.83                                                P             N76
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 1003408 UNOV11022025 1:09.90S 1:09.55S          1:07.88S 3 1 1 5 16 11       19503      NN22
G08SS          Cantley, Alex               90019608    1 2  50C   32.83 1:09.55                                                                P             N25
G08SS          Cantley, Alex               90019608    1 2  50C   31.91 1:07.88                                                                F             N25
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 1004530 UNOV11022025 1:04.47S 1:03.71S                   1 4      2           9504      NN50
G08SS          Cantley, Alex               90019608    1 2  50C   30.11 1:03.71                                                                P             N15
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 1001109 UNOV11012025   56.90S   55.83S            55.95S 7 3 1 0 27 15       59501      NN61
G08SS          Cantley, Alex               90019608    1 2  50C   27.42   55.83                                                                P             N05
G08SS          Cantley, Alex               90019608    1 2  50C   27.32   55.95                                                                F             N05
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 2001402 UNOV11022025 2:07.65S 1:59.41S          1:59.04S 6 4 1 9 12  8  3.   8950100    NN52
G08SS          Cantley, Alex               90019608    1 4  50C   27.65   58.27 1:29.03 1:59.41                                                P             N56
G08SS          Cantley, Alex               90019608    1 4  50C   26.92   56.66 1:27.56 1:59.04                                                F             N56
D08SS      Cantley, Alex               90019608    AGBR0721201015MM 1004410 UNOV11022025 1:04.47S 1:03.71S                   5 4 0 0 34           9504      NN80
G08SS          Cantley, Alex               90019608    1 2  50C   30.11 1:03.71                                                                P             N15
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF 2005106 UNOV11012025 2:32.30S 2:33.45S                   2 1 0 0 19           9505      NN51
D390022137                                                                                                                                                   N48
G08SS          Cantley, Lauren             90022137    1 4  50C   34.22 1:14.06 1:58.11 2:33.45                                                P             N47
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF 1003108 UNOV11012025 1:17.40S 1:18.22S          1:19.72S 4 7 1 3 13 18       89503      NN92
G08SS          Cantley, Lauren             90022137    1 2  50C   37.08 1:18.22                                                                P             N06
G08SS          Cantley, Lauren             90022137    1 2  50C   37.42 1:19.72                                                                F             N06
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF  501112 UNOV11012025   28.50S   29.74S                   5 1 0 0 51           9501      NN01
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF  503403 UNOV11022025   34.30S   36.58S            36.09S 7 6 1 8 22 15       59503      NN22
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF 1001409 UNOV11022025 1:01.80S 1:05.97S                   1 9 0 0 64           9501      NN61
G08SS          Cantley, Lauren             90022137    1 2  50C   31.79 1:05.97                                                                P             N16
D08SS      Cantley, Lauren             90022137    AGBR0721201015FF  504411 UNOV11022025   30.50S   33.14S                   4 8 0 0 56           9504      NN01
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 4001101 UNOV11012025 4:18.73S 4:24.99S                   4 8 0 0 19           9501      NN40
D390014290                                                                                                                                                   N48
G08SS          Clark, Ethan                90014290    1 8  50C   28.82 1:01.13 1:34.68 2:08.62 2:42.41 3:16.24 3:50.74 4:24.99                P             N19
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 2004105 UNOV11012025 2:21.03S 2:34.58S                   3 7 0 0 33           9504      NN30
G08SS          Clark, Ethan                90014290    1 4  50C   31.70 1:10.31 1:52.04 2:34.58                                                P             N16
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 4005201 UNOV11012025 5:00.31S                   4:55.89S     3 4    19       49505      NN30
G08SS          Clark, Ethan                90014290    1 8  50C   30.62 1:06.80 1:44.88 2:21.88 3:07.49 3:53.23 4:25.54 4:55.89                F             N19
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 2001402 UNOV11022025 2:04.59S 2:06.76S                   1 4 0 0 41           9501      NN30
G08SS          Clark, Ethan                90014290    1 4  50C   28.37   59.73 1:32.97 2:06.76                                                P             N06
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 8001502 UNOV11022025 8:50.40S                   8:57.16S     3 0     9  2.   7950100    NN60
G08SS          Clark, Ethan                90014290    116  50C   29.84 1:03.04 1:36.93 2:11.07 2:45.32 3:19.40 3:53.40 4:27.52 5:01.87 5:36.34F             N60
G08SS          Clark, Ethan                90014290    216  50C 6:10.68 6:44.78 7:18.90 7:52.37 8:25.51 8:57.16                                F             N18
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 2005526 UNOV11022025 2:24.22S 2:22.04S                   3 4      2           9505      NN00
G08SS          Clark, Ethan                90014290    1 4  50C   30.14 1:06.64 1:51.16 2:22.04                                                P             N16
D08SS      Clark, Ethan                90014290    AGBR1205201015MM 2005406 UNOV11022025 2:24.22S 2:22.04S                   7 4 0 0 32           9505      NN30
G08SS          Clark, Ethan                90014290    1 4  50C   30.14 1:06.64 1:51.16 2:22.04                                                P             N16
D08SS      Connolly, Kai               1310962     AGBR1122200718MM 2003113 UNOV11012025 2:30.20S 2:27.77S                   4 7 0 0 12           9503      NN80
D31310962                                                                                                                                                    N38
G08SS          Connolly, Kai               1310962     1 4  50C   33.74 1:10.90 1:49.57 2:27.77                                                P             N76
D08SS      Connolly, Kai               1310962     AGBR1122200718MM 4005201 UNOV11012025 4:48.30S                   4:42.92S     4 4     9  2.   2950500    NN01
G08SS          Connolly, Kai               1310962     1 8  50C   29.37 1:03.27 1:40.73 2:17.49 2:56.87 3:37.26 4:10.44 4:42.92                F             N59
D08SS      Connolly, Kai               1310962     AGBR1122200718MM 2005406 UNOV11022025 2:14.40S 2:13.98S          2:14.16S 4 6 1 8  9  8  3.   8950500    NN42
G08SS          Connolly, Kai               1310962     1 4  50C   29.42 1:03.20 1:42.89 2:13.98                                                P             N66
G08SS          Connolly, Kai               1310962     1 4  50C   28.65 1:03.43 1:42.33 2:14.16                                                F             N56
D08SS      Connolly, Kai               1310962     AGBR1122200718MM 1003408 UNOV11022025 1:11.40S 1:10.95S                   3 8 0 0 20           9503      NN70
G08SS          Connolly, Kai               1310962     1 2  50C   33.36 1:10.95                                                                P             N15
D08SS      Connolly, Kai               1310962     AGBR1122200718MM 2002414 UNOV11022025 2:20.60S 2:18.47S                   2 1 0 0 16           9502      NN80
G08SS          Connolly, Kai               1310962     1 4  50C   32.62 1:07.61 1:43.38 2:18.47                                                P             N66
D08SS      Coull, Madison B            1300364     AGBR0720200817FF 2001102 UNOV11012025 2:13.50S 2:10.38S          2:09.23S 4 8 1 0  9  9  2.   9950100    NN72
D31300364                                                                                                                                                    N38
G08SS          Coull, Madison B            1300364     1 4  50C   30.09 1:03.18 1:37.29 2:10.38                                                P             N17
G08SS          Coull, Madison B            1300364     1 4  50C   29.87 1:02.61 1:36.21 2:09.23                                                F             N17
D08SS      Coull, Madison B            1300364     AGBR0720200817FF 1004110 UNOV11012025 1:04.10S 1:04.12S          1:04.02S 2 3 2 7  6  4  7.   4950400    NN62
G08SS          Coull, Madison B            1300364     1 2  50C   29.89 1:04.12                                                                P             N75
G08SS          Coull, Madison B            1300364     1 2  50C   29.98 1:04.02                                                                F             N65
D08SS      Coull, Madison B            1300364     AGBR0720200817FF  501112 UNOV11012025   27.90S   28.22S                   8 8 0 0 16           9501      NN70
D08SS      Coull, Madison B            1300364     AGBR0720200817FF 2004405 UNOV11022025 2:26.20S 2:23.16S          2:22.22S 3 3 1 5  2  2  9.   2950400    NN72
G08SS          Coull, Madison B            1300364     1 4  50C   30.68 1:06.75 1:44.78 2:23.16                                                P             N27
G08SS          Coull, Madison B            1300364     1 4  50C   30.76 1:06.88 1:44.51 2:22.22                                                F             N07
D08SS      Coull, Madison B            1300364     AGBR0720200817FF 1001409 UNOV11022025 1:00.70S 1:00.92S                   3 9 0 0 19           9501      NN21
G08SS          Coull, Madison B            1300364     1 2  50C   29.37 1:00.92                                                                P             N75
D08SS      Coull, Madison B            1300364     AGBR0720200817FF  504411 UNOV11022025   29.00S   29.29S            29.40S 6 2 2 1  7  9  2.   9950400    NN02
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF  502104 UNOV11012025   32.28S   31.51S            31.43S 5 0 1 2 18 14       49502      NN70
D390021724                                                                                                                                                   N48
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 2005106 UNOV11012025 2:34.77S 2:31.97S                   3 9 0 0 16           9505      NN30
G08SS          Craib, Abbie E              90021724    1 4  50C   32.88 1:09.91 1:56.31 2:31.97                                                P             N26
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 1003108 UNOV11012025 1:18.30S 1:19.72S          1:18.93S 4 8 1 1 20 17       79503      NN61
G08SS          Craib, Abbie E              90021724    1 2  50C   37.95 1:19.72                                                                P             N74
G08SS          Craib, Abbie E              90021724    1 2  50C   37.78 1:18.93                                                                F             N74
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 2002114 UNOV11012025 2:32.50S 2:30.54S                   3 8 0 0 16           9502      NN20
G08SS          Craib, Abbie E              90021724    1 4  50C   35.45 1:13.58 1:52.52 2:30.54                                                P             N16
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF  503403 UNOV11022025   36.66S   36.68S                   5 9 0 0 26           9503      NN89
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 1002407 UNOV11022025 1:09.20S 1:08.29S          1:07.02S 2 1 1 3 14 12       29502      NN41
G08SS          Craib, Abbie E              90021724    1 2  50C   33.38 1:08.29                                                                P             N74
G08SS          Craib, Abbie E              90021724    1 2  50C   32.57 1:07.02                                                                F             N64
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 2003413 UNOV11022025 2:53.90S 2:51.16S                   4 0 0 0 20           9503      NN20
G08SS          Craib, Abbie E              90021724    1 4  50C   40.84 1:24.80 2:08.89 2:51.16                                                P             N26
D08SS      Craib, Abbie E              90021724    AGBR0330201114FF 4005501 UNOV11022025 5:35.70S                   5:25.75S     2 4    20       19505      NN20
G08SS          Craib, Abbie E              90021724    1 8  50C   35.66 1:17.01 1:58.32 2:38.90 3:24.58 4:10.82 4:49.38 5:25.75                F             N19
D08SS      Dickens, Emily              90012237    AGBR1123200718FF 2001102 UNOV11012025 2:13.00S 2:18.59S                   2 1 0 0 36           9501      NN11
D390012237                                                                                                                                                   N48
G08SS          Dickens, Emily              90012237    1 4  50C   30.83 1:05.33 1:41.47 2:18.59                                                P             N07
D08SS      Dickens, Emily              90012237    AGBR1123200718FF 1004110 UNOV11012025 1:07.70S 1:10.29S                   2 8 0 0 25           9504      NN11
G08SS          Dickens, Emily              90012237    1 2  50C   32.69 1:10.29                                                                P             N65
D08SS      Dickens, Emily              90012237    AGBR1123200718FF  501112 UNOV11012025   28.50S   29.34S                   5 0 0 0 40           9501      NN60
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 1003528 UNOV11022025 1:17.90S 1:19.13S                   4 7     19           9503      NN70
D390026592                                                                                                                                                   N58
G08SS          Downie, Aiden               90026592    1 2  50C   37.68 1:19.13                                                                P             N25
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 1002107 UNOV11012025 1:07.90S 1:07.32S                   7 6 0 0 42           9502      NN80
G08SS          Downie, Aiden               90026592    1 2  50C   32.13 1:07.32                                                                P             N15
D08SS      Downie, Aiden               90026592    AGBR0228201213MM  502404 UNOV11022025   32.03S   31.44S                   1 7 0 0 53           9502      NN20
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 2002414 UNOV11022025 2:26.65S 2:29.61S                   1 6 0 0 42           9502      NN80
G08SS          Downie, Aiden               90026592    1 4  50C   34.23 1:13.09 1:51.51 2:29.61                                                P             N56
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 2005526 UNOV11022025 2:31.06S 2:30.01S                   1 7     22           9505      NN60
G08SS          Downie, Aiden               90026592    1 4  50C   32.35 1:10.18 1:53.98 2:30.01                                                P             N56
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 2003113 UNOV11012025 2:47.86S 2:54.58S                   6 3 0 0 58           9503      NN90
G08SS          Downie, Aiden               90026592    1 4  50C   39.25 1:23.34 2:09.50 2:54.58                                                P             N66
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 2005406 UNOV11022025 2:31.06S 2:30.01S                   5 7 0 0 60           9505      NN70
G08SS          Downie, Aiden               90026592    1 4  50C   32.35 1:10.18 1:53.98 2:30.01                                                P             N56
D08SS      Downie, Aiden               90026592    AGBR0228201213MM 1003408 UNOV11022025 1:17.90S 1:19.13S                   8 7 0 0 55           9503      NN80
G08SS          Downie, Aiden               90026592    1 2  50C   37.68 1:19.13                                                                P             N25
D08SS      Elfouly, Yehya              90058090    AGBR0821200817MM 1001109 UNOV11012025   54.60S   54.59S                   3 8 0 0 18           9501      NN01
D390058090                                                                                                                                                   N58
G08SS          Elfouly, Yehya              90058090    1 2  50C   26.34   54.59                                                                P             N65
D08SS      Elfouly, Yehya              90058090    AGBR0821200817MM 2001402 UNOV11022025 1:59.90S 2:01.95S                   3 7 0 0 23           9501      NN41
G08SS          Elfouly, Yehya              90058090    1 4  50C   28.32   58.97 1:30.80 2:01.95                                                P             N07
D08SS      Elfouly, Yehya              90058090    AGBR0821200817MM 1004410 UNOV11022025 1:00.00S 1:01.51S                   4 1 0 0 20           9504      NN31
G08SS          Elfouly, Yehya              90058090    1 2  50C   28.67 1:01.51                                                                P             N75
D08SS      Elfouly, Yehya              90058090    AGBR0821200817MM  501412 UNOV11022025   24.80S   25.85S                   6 1 0 0 29           9501      NN90
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 2003533 UNOV11022025 3:01.73S 2:59.48S                   1 4      5           9503      NN00
D390023610                                                                                                                                                   N48
G08SS          Ellis, Paige                90023610    1 4  50C   40.34 1:26.30 2:13.20 2:59.48                                                P             N16
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 4001401 UNOV11022025 5:05.78S 5:06.99S                   1 1 0 0 36           9501      NN30
G08SS          Ellis, Paige                90023610    1 8  50C   33.71 1:11.67 1:51.23 2:31.18 3:11.22 3:50.64 4:29.85 5:06.99                P             N19
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 2004405 UNOV11022025 2:47.19S 2:51.93S                   3 0 0 0 29           9504      NN30
G08SS          Ellis, Paige                90023610    1 4  50C   34.91 1:17.53 2:05.73 2:51.93                                                P             N26
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 1004110 UNOV11012025 1:14.50S 1:14.66S                   6 6 0 0 44           9504      NN20
G08SS          Ellis, Paige                90023610    1 2  50C   34.96 1:14.66                                                                P             N74
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 1003108 UNOV11012025 1:25.84S 1:25.99S                   5 5 0 0 44           9503      NN30
G08SS          Ellis, Paige                90023610    1 2  50C   40.52 1:25.99                                                                P             N74
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 2005106 UNOV11012025 2:41.70S 2:40.77S                   6 3 0 0 38           9505      NN30
G08SS          Ellis, Paige                90023610    1 4  50C   34.05 1:16.22 2:03.26 2:40.77                                                P             N16
D08SS      Ellis, Paige                90023610    AGBR0206201015FF 2003413 UNOV11022025 3:01.73S 2:59.48S                   5 4 0 0 37           9503      NN30
G08SS          Ellis, Paige                90023610    1 4  50C   40.34 1:26.30 2:13.20 2:59.48                                                P             N16
D08SS      Emad Elsayed, Saif          90030118    AGBR0320201015MM 1002107 UNOV11012025 1:11.78S 1:08.85S                   8 9 0 0 51           9502      NN02
D390030118                                                                                                                                                   N48
G08SS          Emad Elsayed, Saif          90030118    1 2  50C   32.98 1:08.85                                                                P             N46
D08SS      Emad Elsayed, Saif          90030118    AGBR0320201015MM 2002534 UNOV11022025 2:35.35S 2:27.87S                   2 6      2           9502      NN81
G08SS          Emad Elsayed, Saif          90030118    1 4  50C   34.15 1:12.03 1:50.38 2:27.87                                                P             N87
D08SS      Emad Elsayed, Saif          90030118    AGBR0320201015MM  503103 UNOV11012025   32.90S   34.01S                   4 9 0 0 48           9503      NN41
D08SS      Emad Elsayed, Saif          90030118    AGBR0320201015MM 2002414 UNOV11022025 2:35.35S 2:27.87S                   6 6 0 0 37           9502      NN12
G08SS          Emad Elsayed, Saif          90030118    1 4  50C   34.15 1:12.03 1:50.38 2:27.87                                                P             N87
D08SS      Enoch, Theresa              90032479    AGBR0727201015FF 1003108 UNOV11012025 1:26.25S 1:28.32S                   6 6 0 0 49           9503      NN21
D390032479                                                                                                                                                   N58
G08SS          Enoch, Theresa              90032479    1 2  50C   42.22 1:28.32                                                                P             N55
D08SS      Ferguson, Jamie W           946980      AGBR1019200322MM 1002107 UNOV11012025   53.61S   53.95S            53.58S 4 4 2 4  1  1 10.   1950200    NN62
D3946980        Jamie                                                                                                                                        N00
G08SS          Ferguson, Jamie W           946980      1 2  50C   26.08   53.95                                                                P             N06
G08SS          Ferguson, Jamie W           946980      1 2  50C   25.73   53.58                                                                F             N95
D08SS      Ferguson, Jamie W           946980      AGBR1019200322MM  502404 UNOV11022025   24.50S   24.89S            24.65S 6 4 2 4  1  1 10.   1950200    NN62
D08SS      Gavin, Michael              90025245    AGBR0406201015MM  503103 UNOV11012025   31.40S   32.80S            33.18S 5 0 2 7 32 15       59503      NN61
D390025245                                                                                                                                                   N48
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 2003113 UNOV11012025 2:37.80S 2:38.59S                   4 9 0 0 28           9503      NN21
G08SS          Gavin, Michael              90025245    1 4  50C   34.59 1:13.87 1:55.65 2:38.59                                                P             N07
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 1003408 UNOV11022025 1:11.70S 1:12.13S          1:12.98S 4 0 1 1 24 19       99503      NN42
G08SS          Gavin, Michael              90025245    1 2  50C   33.93 1:12.13                                                                P             N45
G08SS          Gavin, Michael              90025245    1 2  50C   33.52 1:12.98                                                                F             N45
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 2005526 UNOV11022025 2:31.47S 2:27.66S                   2 1     14           9505      NN90
G08SS          Gavin, Michael              90025245    1 4  50C   31.36 1:11.59 1:53.01 2:27.66                                                P             N96
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 1004530 UNOV11022025 1:09.69S      DQS                   1 0      0           9504      NN50
G08SS          Gavin, Michael              90025245    1 2  50C   32.11 1:10.51                                                                P             N35
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 1001109 UNOV11012025   58.50S   59.20S                   5 7 0 0 55           9501      NN60
G08SS          Gavin, Michael              90025245    1 2  50C   28.02   59.20                                                                P             N25
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 2005406 UNOV11022025 2:31.47S 2:27.66S                   6 1 0 0 52           9505      NN11
G08SS          Gavin, Michael              90025245    1 4  50C   31.36 1:11.59 1:53.01 2:27.66                                                P             N96
D08SS      Gavin, Michael              90025245    AGBR0406201015MM 1004410 UNOV11022025 1:09.69S      DQS                   5 0 0 0  0           9504      NN70
G08SS          Gavin, Michael              90025245    1 2  50C   32.11 1:10.51                                                                P             N35
D08SS      Geddes, Corrin              90042277    AGBR1102201312FF 2004525 UNOV11022025 3:09.37S 2:57.20S                   1 5      2           9504      NN80
D390042277                                                                                                                                                   N58
G08SS          Geddes, Corrin              90042277    1 4  50C   39.34 1:23.74 2:10.69 2:57.20                                                P             N07
D08SS      Geddes, Corrin              90042277    AGBR1102201312FF 2004405 UNOV11022025 3:09.37S 2:57.20S                   5 5 0 0 32           9504      NN11
G08SS          Geddes, Corrin              90042277    1 4  50C   39.34 1:23.74 2:10.69 2:57.20                                                P             N07
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 2005526 UNOV11022025 2:31.57S 2:26.33S                   3 8     11           9505      NN80
D390036609                                                                                                                                                   N58
G08SS          Geddes, Glenn L             90036609    1 4  50C   30.91 1:08.64 1:53.81 2:26.33                                                P             N86
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 1002107 UNOV11012025 1:12.00S 1:08.05S                   7 9 0 0 47           9502      NN90
G08SS          Geddes, Glenn L             90036609    1 2  50C   33.45 1:08.05                                                                P             N35
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 4001101 UNOV11012025 4:36.29S 4:30.22S                   1 7 0 0 26           9501      NN90
G08SS          Geddes, Glenn L             90036609    1 8  50C   29.73 1:03.12 1:37.67 2:12.61 2:47.52 3:22.80 3:57.16 4:30.22                P             N79
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 2004105 UNOV11012025 2:33.06S 2:23.44S                   1 4 0 0 18           9504      NN90
G08SS          Geddes, Glenn L             90036609    1 4  50C   31.66 1:08.44 1:46.42 2:23.44                                                P             N86
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 4005201 UNOV11012025 5:15.28S                   5:03.21S     2 8    26       39505      NN90
G08SS          Geddes, Glenn L             90036609    1 8  50C   31.72 1:08.40 1:47.01 2:24.87 3:09.19 3:54.91 4:29.54 5:03.21                F             N79
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 8001502 UNOV11022025 9:41.20S                   9:16.03S     1 3    16       29501      NN90
G08SS          Geddes, Glenn L             90036609    116  50C   29.58 1:03.93 1:38.96 2:13.86 2:49.15 3:24.41 4:00.02 4:35.25 5:10.79 5:46.50F             N31
G08SS          Geddes, Glenn L             90036609    216  50C 6:21.96 6:57.84 7:33.17 8:08.27 8:43.12 9:16.03                                F             N78
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 1004530 UNOV11022025 1:07.10S 1:05.34S                   1 2      4           9504      NN60
G08SS          Geddes, Glenn L             90036609    1 2  50C   30.98 1:05.34                                                                P             N35
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 2005406 UNOV11022025 2:31.57S 2:26.33S                   7 8 0 0 48           9505      NN01
G08SS          Geddes, Glenn L             90036609    1 4  50C   30.91 1:08.64 1:53.81 2:26.33                                                P             N86
D08SS      Geddes, Glenn L             90036609    AGBR0314201213MM 1004410 UNOV11022025 1:07.10S 1:05.34S                   5 2 0 0 40           9504      NN90
G08SS          Geddes, Glenn L             90036609    1 2  50C   30.98 1:05.34                                                                P             N35
D08SS      Gibson, Adam                90021955    AGBR0131201114MM 4001101 UNOV11012025 4:18.67S      NSS                   3 1 0 0  0           9501      NN99
D390021955                                                                                                                                                   N58
G08SS          Gibson, Adam                90021955    1 8  50C                                                                                P             N53
D08SS      Gibson, Adam                90021955    AGBR0131201114MM 2003113 UNOV11012025 2:39.04S 2:42.63S                   3 9 0 0 37           9503      NN30
G08SS          Gibson, Adam                90021955    1 4  50C   35.71 1:16.46 2:00.68 2:42.63                                                P             N16
D08SS      Gibson, Adam                90021955    AGBR0131201114MM 2001402 UNOV11022025 2:04.60S 2:08.59S                   1 5 0 0 48           9501      NN30
G08SS          Gibson, Adam                90021955    1 4  50C   28.44 1:01.03 1:35.22 2:08.59                                                P             N16
D08SS      Gibson, Adam                90021955    AGBR0131201114MM 2005406 UNOV11022025 2:20.10S 2:24.33S                   2 8 0 0 40           9505      NN20
G08SS          Gibson, Adam                90021955    1 4  50C   31.64 1:10.65 1:52.10 2:24.33                                                P             N16
D08SS      Gibson, Adam                90021955    AGBR0131201114MM 8001502 UNOV11022025 9:02.40S                   9:20.23S     2 3    17       79501      NN20
G08SS          Gibson, Adam                90021955    116  50C   30.86 1:05.14 1:39.79 2:14.99 2:50.30 3:25.73 4:01.29 4:36.54 5:11.85 5:48.02F             N60
G08SS          Gibson, Adam                90021955    216  50C 6:24.05 7:01.51 7:36.76 8:12.45 8:48.08 9:20.23                                F             N08
D08SS      Gibson, Samuel J            90033121    AGBR0703201015MM 2004105 UNOV11012025 2:35.60S 2:34.34S                   1 2 0 0 30           9504      NN41
D390033121                                                                                                                                                   N48
G08SS          Gibson, Samuel J            90033121    1 4  50C   32.99 1:12.74 1:53.30 2:34.34                                                P             N27
D08SS      Gibson, Samuel J            90033121    AGBR0703201015MM 4001101 UNOV11012025 4:58.31S 4:53.24S                   5 2 0 0 42           9501      NN41
G08SS          Gibson, Samuel J            90033121    1 8  50C   31.91 1:08.50 1:45.82 2:23.29 3:00.63 3:37.92 4:16.04 4:53.24                P             N20
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF 2005106 UNOV11012025 2:32.16S 2:36.38S                   3 1 0 0 27           9505      NN42
D31231136                                                                                                                                                    N38
G08SS          Goodbrand, Alyssa E         1231136     1 4  50C   33.16 1:14.26 1:58.79 2:36.38                                                P             N38
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF 1003108 UNOV11012025 1:17.12S 1:19.24S                   3 2 0 0 18           9503      NN32
G08SS          Goodbrand, Alyssa E         1231136     1 2  50C   37.02 1:19.24                                                                P             N86
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF 1004110 UNOV11012025 1:08.73S 1:14.16S                   2 0 0 0 40           9504      NN32
G08SS          Goodbrand, Alyssa E         1231136     1 2  50C   34.82 1:14.16                                                                P             N86
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF  503403 UNOV11022025   35.40S   36.77S                   6 8 0 0 29           9503      NN91
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF 2004405 UNOV11022025 2:32.29S 2:39.98S                   3 2 0 0 17           9504      NN52
G08SS          Goodbrand, Alyssa E         1231136     1 4  50C   33.84 1:13.19 1:56.59 2:39.98                                                P             N48
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF  504411 UNOV11022025   30.70S   31.56S                   3 4 0 0 36           9504      NN81
D08SS      Goodbrand, Alyssa E         1231136     AGBR1121200619FF 2003413 UNOV11022025 2:46.18S 2:49.30S                   4 2 0 0 14           9503      NN42
G08SS          Goodbrand, Alyssa E         1231136     1 4  50C   37.72 1:20.43 2:04.43 2:49.30                                                P             N28
D08SS      Gray, Euan J                90009003    AGBR0919200619MM 1003408 UNOV11022025 1:09.54S 1:08.48S                   3 7 0 0 12           9503      NN00
D390009003      Euan                                                                                                                                         N89
G08SS          Gray, Euan J                90009003    1 2  50C   31.77 1:08.48                                                                P             N34
D08SS      Gray, Euan J                90009003    AGBR0919200619MM  501412 UNOV11022025   25.10S   25.32S                   5 9 0 0 18           9501      NN49
D08SS      Gunn, Julia M               90028895    AGBR0218201114FF 2004405 UNOV11022025 3:05.07S 3:18.19S                   1 0 0 0 41           9504      NN30
D390028895                                                                                                                                                   N58
G08SS          Gunn, Julia M               90028895    1 4  50C   41.37 1:29.90 2:24.22 3:18.19                                                P             N26
D08SS      Gunn, Ross                  90022687    AGBR0209200916MM 1003528 UNOV11022025 1:22.01S 1:21.78S                   2 3     35           9503      NN79
D390022687                                                                                                                                                   N58
G08SS          Gunn, Ross                  90022687    1 2  50C   37.61 1:21.78                                                                P             N34
D08SS      Gunn, Ross                  90022687    AGBR0209200916MM 1003408 UNOV11022025 1:22.01S 1:21.78S                   6 3 0 0 71           9503      NN99
G08SS          Gunn, Ross                  90022687    1 2  50C   37.61 1:21.78                                                                P             N34
D08SS      Harvey, Grace               513103      AGBR0831199827FF  503403 UNOV11022025   47.90S   46.93S                   1 6 0 0 60           9503      NN10
D3513103                                                                                                                                                     N28
D08SS      Harvey, Grace               513103      AGBR0831199827FF 2005106 UNOV11012025 3:02.20S 3:08.89S                   5 8 0 0 54           9505      NN70
G08SS          Harvey, Grace               513103      1 4  50C   42.51 1:33.29 2:26.34 3:08.89                                                P             N46
D08SS      Harvey, Grace               513103      AGBR0831199827FF 1003108 UNOV11012025 1:42.60S 1:39.42S                   5 8 0 0 53           9503      NN60
G08SS          Harvey, Grace               513103      1 2  50C   47.79 1:39.42                                                                P             N05
D08SS      Hawkins, Georgina           1246404     AGBR1128200619FF 2001102 UNOV11012025 2:07.69S 2:09.25S          2:08.41S 4 3 1 8  8  7  4.   7950100    NN83
D31246404                                                                                                                                                    N38
G08SS          Hawkins, Georgina           1246404     1 4  50C   29.89 1:02.81 1:36.35 2:09.25                                                P             N18
G08SS          Hawkins, Georgina           1246404     1 4  50C   28.66 1:00.27 1:33.69 2:08.41                                                F             N08
D08SS      Hawkins, Georgina           1246404     AGBR1128200619FF  501112 UNOV11012025   26.30S   26.55S            26.34S 7 5 2 2  4  2  9.   2950100    NN92
D08SS      Hawkins, Georgina           1246404     AGBR1128200619FF  503403 UNOV11022025   34.97S   35.14S                   5 7 0 0 12           9503      NN71
D08SS      Hawkins, Georgina           1246404     AGBR1128200619FF 1001409 UNOV11022025   57.50S   58.23S            57.96S 3 5 2 3  3  4  7.   4950100    NN13
G08SS          Hawkins, Georgina           1246404     1 2  50C   28.01   58.23                                                                P             N46
G08SS          Hawkins, Georgina           1246404     1 2  50C   27.47   57.96                                                                F             N46
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF 2005106 UNOV11012025 2:32.48S 2:33.76S                   4 8 0 0 21           9505      NN82
D390015294                                                                                                                                                   N48
G08SS          Higgins, Charlotte          90015294    1 4  50C   34.46 1:14.30 1:56.99 2:33.76                                                P             N78
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF 1003108 UNOV11012025 1:15.70S 1:18.91S          1:16.88S 3 3 1 6 14 15       59503      NN14
G08SS          Higgins, Charlotte          90015294    1 2  50C   37.27 1:18.91                                                                P             N27
G08SS          Higgins, Charlotte          90015294    1 2  50C   36.75 1:16.88                                                                F             N27
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF  503403 UNOV11022025   34.50S   36.70S                   5 6 0 0 27           9503      NN22
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF 1002407 UNOV11022025 1:13.18S 1:18.14S                   1 6 0 0 46           9502      NN72
G08SS          Higgins, Charlotte          90015294    1 2  50C   37.08 1:18.14                                                                P             N27
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF 2003413 UNOV11022025 2:42.37S 2:49.84S                   2 3 0 0 16           9503      NN82
G08SS          Higgins, Charlotte          90015294    1 4  50C   37.85 1:20.89 2:05.02 2:49.84                                                P             N78
D08SS      Higgins, Charlotte          90015294    AGBR0914201015FF 1004110 UNOV11012025 1:12.80S 1:14.97S                   6 5 0 0 46           9504      NN82
G08SS          Higgins, Charlotte          90015294    1 2  50C   34.37 1:14.97                                                                P             N27
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM 2003113 UNOV11012025 2:49.50S 2:47.00S                   6 2 0 0 47           9503      NN82
D390007527                                                                                                                                                   N48
G08SS          Hodgkinson, George          90007527    1 4  50C   37.37 1:19.53 2:02.68 2:47.00                                                P             N68
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM  503103 UNOV11012025   33.10S   33.91S                   3 3 0 0 47           9503      NN32
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM 2004105 UNOV11012025 2:32.26S 2:35.75S                   4 9 0 0 35           9504      NN92
G08SS          Hodgkinson, George          90007527    1 4  50C   34.07 1:12.66 1:52.96 2:35.75                                                P             N78
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM  501412 UNOV11022025   26.40S   26.56S                   2 8 0 0 45           9501      NN32
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM 1003528 UNOV11022025 1:15.69S 1:13.85S                   3 5      4           9503      NN62
G08SS          Hodgkinson, George          90007527    1 2  50C   35.01 1:13.85                                                                P             N17
D08SS      Hodgkinson, George          90007527    AGBR0612200817MM 1003408 UNOV11022025 1:15.69S 1:13.85S                   7 5 0 0 35           9503      NN92
G08SS          Hodgkinson, George          90007527    1 2  50C   35.01 1:13.85                                                                P             N17
D08SS      Hodgkinson, Megan B         90016518    AGBR1129201015FF 2004525 UNOV11022025 3:10.08S 3:07.35S                   1 7      4           9504      NN22
D390016518                                                                                                                                                   N48
G08SS          Hodgkinson, Megan B         90016518    1 4  50C   38.53 1:26.74 2:16.61 3:07.35                                                P             N48
D08SS      Hodgkinson, Megan B         90016518    AGBR1129201015FF 2004405 UNOV11022025 3:10.08S 3:07.35S                   5 7 0 0 37           9504      NN52
G08SS          Hodgkinson, Megan B         90016518    1 4  50C   38.53 1:26.74 2:16.61 3:07.35                                                P             N48
D08SS      Hodzic, Oliver              90027964    AGBR0621201015MM 2004105 UNOV11012025 2:18.69S 2:20.62S                   3 2 0 0 15           9504      NN31
D390027964                                                                                                                                                   N58
G08SS          Hodzic, Oliver              90027964    1 4  50C   30.05 1:05.24 1:42.46 2:20.62                                                P             N17
D08SS      Hodzic, Oliver              90027964    AGBR0621201015MM  504111 UNOV11012025   25.70S   26.88S            26.43S 5 2 1 4 12 12       29504      NN91
D08SS      Hodzic, Oliver              90027964    AGBR0621201015MM 2005406 UNOV11022025 2:21.20S 2:24.60S                   3 0 0 0 42           9505      NN31
G08SS          Hodzic, Oliver              90027964    1 4  50C   29.71 1:06.57 1:50.95 2:24.60                                                P             N27
D08SS      Hodzic, Oliver              90027964    AGBR0621201015MM 1004410 UNOV11022025   59.10S 1:00.86S            59.42S 3 2 1 4 15 12       29504      NN22
G08SS          Hodzic, Oliver              90027964    1 2  50C   28.09 1:00.86                                                                P             N75
G08SS          Hodzic, Oliver              90027964    1 2  50C   27.11   59.42                                                                F             N45
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM 1002107 UNOV11012025 1:06.52S 1:06.97S                   1 9 0 0 40           9502      NN41
D390021723                                                                                                                                                   N48
G08SS          Hopkins, Lewis              90021723    1 2  50C   31.75 1:06.97                                                                P             N85
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM 1001109 UNOV11012025   54.20S   55.65S            54.23S 3 1 1 8 25 14       49501      NN02
G08SS          Hopkins, Lewis              90021723    1 2  50C   26.68   55.65                                                                P             N65
G08SS          Hopkins, Lewis              90021723    1 2  50C   26.35   54.23                                                                F             N45
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM  504111 UNOV11012025   26.50S   27.62S            28.55S 4 0 1 7 27 18       89504      NN02
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM 2001402 UNOV11022025 2:03.10S 2:03.70S                   4 9 0 0 27           9501      NN31
G08SS          Hopkins, Lewis              90021723    1 4  50C   27.79   58.55 1:30.66 2:03.70                                                P             N07
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM  502404 UNOV11022025   29.52S   30.49S                   5 9 0 0 41           9502      NN90
D08SS      Hopkins, Lewis              90021723    AGBR0813200916MM  501412 UNOV11022025   25.00S   25.42S            25.21S 6 0 1 7 22 14       49501      NN81
D08SS      Houssen-Ibrahim, Amr        90037850    AGBR0411201114MM  503103 UNOV11012025   33.11S   33.88S                   3 6 0 0 46           9503      NN62
D390037850                                                                                                                                                   N58
D08SS      Jackson, Keira              90035034    AGBR1009201114FF 1002527 UNOV11022025 1:14.90S 1:16.11S                   1 1      7           9502      NN70
D390035034      Keira                                                                                                                                        N20
G08SS          Jackson, Keira              90035034    1 2  50C   36.54 1:16.11                                                                P             N55
D08SS      Jackson, Keira              90035034    AGBR1009201114FF 1002407 UNOV11022025 1:14.90S 1:16.11S                   5 1 0 0 43           9502      NN01
G08SS          Jackson, Keira              90035034    1 2  50C   36.54 1:16.11                                                                P             N55
D08SS      Jackson, Logan              90002043    AGBR0319200718MM 1002107 UNOV11012025   57.36S   57.92S            57.86S 4 5 2 2  5  5  6.   5950200    NN12
D390002043      Logan                                                                                                                                        N20
G08SS          Jackson, Logan              90002043    1 2  50C   27.83   57.92                                                                P             N35
G08SS          Jackson, Logan              90002043    1 2  50C   27.89   57.86                                                                F             N35
D08SS      Jackson, Logan              90002043    AGBR0319200718MM  504111 UNOV11012025   26.28S   26.96S                   3 1 0 0 13           9504      NN70
D08SS      Jackson, Logan              90002043    AGBR0319200718MM  502404 UNOV11022025   25.85S   26.58S            26.80S 6 5 2 7  6  7  4.   7950200    NN02
D08SS      Jackson, Logan              90002043    AGBR0319200718MM 1004410 UNOV11022025   59.12S 1:00.20S                   2 2 0 0 11           9504      NN80
G08SS          Jackson, Logan              90002043    1 2  50C   28.00 1:00.20                                                                P             N45
D08SS      Jackson, Logan              90002043    AGBR0319200718MM 2002414 UNOV11022025 2:06.45S 2:07.47S          2:07.25S 3 5 1 6  4  5  6.   5950200    NN72
G08SS          Jackson, Logan              90002043    1 4  50C   29.14 1:01.16 1:34.19 2:07.47                                                P             N96
G08SS          Jackson, Logan              90002043    1 4  50C   28.74 1:00.58 1:33.34 2:07.25                                                F             N96
D08SS      Jamison, Toni               90046552    AGBR0107200520FF 2001102 UNOV11012025 2:10.99S 2:12.83S                   3 7 0 0 14           9501      NN80
D390046552                                                                                                                                                   N58
G08SS          Jamison, Toni               90046552    1 4  50C   31.30 1:05.16 1:39.07 2:12.83                                                P             N76
D08SS      Jamison, Toni               90046552    AGBR0107200520FF 1004110 UNOV11012025 1:05.40S 1:06.40S                   2 2 0 0 10           9504      NN70
G08SS          Jamison, Toni               90046552    1 2  50C   31.20 1:06.40                                                                P             N25
D08SS      Jamison, Toni               90046552    AGBR0107200520FF 2004405 UNOV11022025 2:21.37S 2:22.46S          2:20.34S 4 4 1 4  1  1 10.   1950400    NN32
G08SS          Jamison, Toni               90046552    1 4  50C   32.29 1:08.60 1:44.94 2:22.46                                                P             N86
G08SS          Jamison, Toni               90046552    1 4  50C   31.23 1:07.06 1:43.41 2:20.34                                                F             N66
D08SS      Jenkinson, Jack             907378      AGBR0904200619MM 1001109 UNOV11012025   50.10S   50.78S            50.39S 4 5 2 3  3  3  8.   3950100    NN32
D3907378                                                                                                                                                     N38
G08SS          Jenkinson, Jack             907378      1 2  50C   24.16   50.78                                                                P             N65
G08SS          Jenkinson, Jack             907378      1 2  50C   24.31   50.39                                                                F             N55
D08SS      Jenkinson, Jack             907378      AGBR0904200619MM  504111 UNOV11012025   25.60S      NSS                   4 6 0 0  0           9504      NN90
D08SS      Jenkinson, Jack             907378      AGBR0904200619MM 2001402 UNOV11022025 1:51.00S 1:50.94S          1:50.03S 2 4 1 4  1  1 10.   1950100    NN92
G08SS          Jenkinson, Jack             907378      1 4  50C   25.13   52.89 1:21.62 1:50.94                                                P             N07
G08SS          Jenkinson, Jack             907378      1 4  50C   24.99   52.43 1:20.77 1:50.03                                                F             N07
D08SS      Jenkinson, Jack             907378      AGBR0904200619MM 2005406 UNOV11022025 2:08.80S 2:07.12S          2:08.71S 4 5 1 5  2  3  8.   3950500    NN03
G08SS          Jenkinson, Jack             907378      1 4  50C   26.82   59.64 1:37.79 2:07.12                                                P             N17
G08SS          Jenkinson, Jack             907378      1 4  50C   26.56   59.72 1:38.35 2:08.71                                                F             N17
D08SS      Johnson, Brendan            753537      AGBR0803199827MM  504111 UNOV11012025   25.90S   26.78S                   5 7 0 0 11           9504      NN51
D3753537                                                                                                                                                     N38
D08SS      Johnson, Brendan            753537      AGBR0803199827MM  502404 UNOV11022025   28.40S   27.51S            27.58S 4 1 2 0  9 10  1.   0950200    NN82
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM  503103 UNOV11012025   34.99S   36.16S                   1 5 0 0 61           9503      NN61
D390023514                                                                                                                                                   N48
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM  504111 UNOV11012025   27.40S   28.83S                   2 6 0 0 38           9504      NN61
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM  502404 UNOV11022025   30.60S   31.23S                   2 3 0 0 48           9502      NN61
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM  501412 UNOV11022025   26.20S   27.63S                   2 2 0 0 56           9501      NN61
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM 1004530 UNOV11022025 1:04.80S 1:08.33S                   2 5      8           9504      NN91
G08SS          Johnston, Finlay            90023514    1 2  50C   30.28 1:08.33                                                                P             N56
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM 1002107 UNOV11012025 1:09.90S 1:11.42S                   7 7 0 0 65           9502      NN22
G08SS          Johnston, Finlay            90023514    1 2  50C   33.11 1:11.42                                                                P             N46
D08SS      Johnston, Finlay            90023514    AGBR0327201015MM 1004410 UNOV11022025 1:04.80S 1:08.33S                   6 5 0 0 45           9504      NN12
G08SS          Johnston, Finlay            90023514    1 2  50C   30.28 1:08.33                                                                P             N56
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM  503103 UNOV11012025   31.30S   32.21S            31.94S 6 0 1 3 23 23       39503      NN71
D390015295                                                                                                                                                   N58
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM 2003113 UNOV11012025 2:33.40S 2:35.42S                   2 7 0 0 18           9503      NN31
G08SS          Jolly, Cameron              90015295    1 4  50C   34.39 1:13.12 1:54.67 2:35.42                                                P             N17
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM  502404 UNOV11022025   32.31S   31.71S                   1 8 0 0 54           9502      NN70
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM 1003408 UNOV11022025 1:09.30S 1:09.45S          1:08.83S 4 7 1 4 15 12       29503      NN62
G08SS          Jolly, Cameron              90015295    1 2  50C   32.67 1:09.45                                                                P             N75
G08SS          Jolly, Cameron              90015295    1 2  50C   32.58 1:08.83                                                                F             N65
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM  501412 UNOV11022025   26.20S   26.21S                   2 6 0 0 38           9501      NN70
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM 1001109 UNOV11012025   58.90S   58.79S                   6 0 0 0 52           9501      NN90
G08SS          Jolly, Cameron              90015295    1 2  50C   28.41   58.79                                                                P             N55
D08SS      Jolly, Cameron              90015295    AGBR0722201015MM 1002107 UNOV11012025 1:12.54S 1:11.38S                   5 3 0 0 64           9502      NN31
G08SS          Jolly, Cameron              90015295    1 2  50C   34.69 1:11.38                                                                P             N75
D08SS      Jupp, Cameron               90010514    AGBR0411201114MM 2003113 UNOV11012025 2:49.65S 2:48.67S                   7 7 0 0 50           9503      NN90
D390010514                                                                                                                                                   N48
G08SS          Jupp, Cameron               90010514    1 4  50C   37.46 1:21.50 2:05.47 2:48.67                                                P             N76
D08SS      Jupp, Cameron               90010514    AGBR0411201114MM  503103 UNOV11012025   35.00S   35.83S                   1 3 0 0 60           9503      NN20
D08SS      Jupp, Cameron               90010514    AGBR0411201114MM 4005201 UNOV11012025 5:09.46S                   5:06.48S     3 9    29       79505      NN90
G08SS          Jupp, Cameron               90010514    1 8  50C   31.33 1:08.80 1:48.57 2:26.58 3:11.30 3:56.41 4:32.92 5:06.48                F             N69
D08SS      Jupp, Cameron               90010514    AGBR0411201114MM 1002107 UNOV11012025 1:08.20S 1:06.30S                   7 2 0 0 37           9502      NN80
G08SS          Jupp, Cameron               90010514    1 2  50C   31.98 1:06.30                                                                P             N25
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM 1002107 UNOV11012025 1:03.37S 1:02.62S          1:03.35S 2 1 1 3 14 15       59502      NN05
D390014251      Sky                                                                                                                                          N59
G08SS          Khowboonchai, Rachata       90014251    1 2  50C   29.64 1:02.62                                                                P             N18
G08SS          Khowboonchai, Rachata       90014251    1 2  50C   29.70 1:03.35                                                                F             N18
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM  504111 UNOV11012025   28.30S   28.11S            28.44S 1 5 1 9 32 17       79504      NN34
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM 4005201 UNOV11012025 5:11.94S                   5:15.47S     2 5    35       69505      NN83
G08SS          Khowboonchai, Rachata       90014251    1 8  50C   30.44 1:09.56 1:50.08 2:31.19 3:14.77 4:00.78 4:38.82 5:15.47                F             N52
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM  502404 UNOV11022025   28.25S   28.23S            28.03S 5 7 1 5 15 13       39502      NN34
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM 2005406 UNOV11022025 2:22.59S 2:27.22S                   1 2 0 0 50           9505      NN83
G08SS          Khowboonchai, Rachata       90014251    1 4  50C   30.37 1:07.84 1:52.21 2:27.22                                                P             N69
D08SS      Khowboonchai, Rachata       90014251    AGBR0821201015MM 2002414 UNOV11022025 2:18.67S 2:23.38S                   3 7 0 0 29           9502      NN93
G08SS          Khowboonchai, Rachata       90014251    1 4  50C   32.14 1:08.44 1:45.11 2:23.38                                                P             N69
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF  502104 UNOV11012025   29.83S   30.15S            29.78S 3 3 2 1  7  5  6.   5950200    NN13
D390011236                                                                                                                                                   N48
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF  501112 UNOV11012025   26.80S   27.40S            27.18S 6 6 2 0  9  8  2.   8950150    NN13
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF 2002114 UNOV11012025 2:23.95S 2:24.75S          2:23.20S 2 3 1 8  8  6  5.   6950200    NN93
G08SS          Kirkwood, Jessica           90011236    1 4  50C   32.74 1:08.69 1:46.74 2:24.75                                                P             N38
G08SS          Kirkwood, Jessica           90011236    1 4  50C   32.56 1:08.49 1:46.08 2:23.20                                                F             N28
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF  503403 UNOV11022025   33.30S   34.80S            33.96S 7 5 2 1  7  5  6.   5950300    NN13
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF 1002407 UNOV11022025 1:04.56S 1:05.15S          1:03.77S 4 3 2 7  6  4  7.   4950200    NN93
G08SS          Kirkwood, Jessica           90011236    1 2  50C   31.10 1:05.15                                                                P             N76
G08SS          Kirkwood, Jessica           90011236    1 2  50C   30.53 1:03.77                                                                F             N76
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF 1001409 UNOV11022025   59.60S 1:00.83S            59.40S 2 7 1 2 18 13       39501      NN23
G08SS          Kirkwood, Jessica           90011236    1 2  50C   29.22 1:00.83                                                                P             N86
G08SS          Kirkwood, Jessica           90011236    1 2  50C   28.90   59.40                                                                F             N56
D08SS      Kirkwood, Jessica           90011236    AGBR0214200916FF  504411 UNOV11022025   28.70S   29.91S            29.91S 5 6 1 5 14 13       39504      NN03
D08SS      Kitton, Lewis               90044559    AGBR0721200817MM 1003528 UNOV11022025 1:40.23S 1:32.10S                   1 3     39           9503      NN90
D390044559      Lewis                                                                                                                                        N40
G08SS          Kitton, Lewis               90044559    1 2  50C   42.69 1:32.10                                                                P             N45
D08SS      Kitton, Lewis               90044559    AGBR0721200817MM 1003408 UNOV11022025 1:40.23S 1:32.10S                   5 3 0 0 75           9503      NN11
G08SS          Kitton, Lewis               90044559    1 2  50C   42.69 1:32.10                                                                P             N45
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 1002107 UNOV11012025 1:08.80S 1:06.93S                   6 2 0 0 39           9502      NN82
D390029968                                                                                                                                                   N58
G08SS          Kurmelovs, Artjom           90029968    1 2  50C   33.07 1:06.93                                                                P             N17
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 4001101 UNOV11012025 4:40.57S 4:34.57S                   1 0 0 0 31           9501      NN72
G08SS          Kurmelovs, Artjom           90029968    1 8  50C   30.35 1:04.14 1:38.66 2:13.70 2:49.09 3:24.68 4:00.18 4:34.57                P             N51
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM  503103 UNOV11012025   33.92S   34.25S                   3 9 0 0 52           9503      NN22
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 2003113 UNOV11012025 2:43.78S 2:36.34S                   1 8 0 0 21           9503      NN82
G08SS          Kurmelovs, Artjom           90029968    1 4  50C   35.18 1:15.47 1:55.82 2:36.34                                                P             N68
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM  502404 UNOV11022025   31.28S   31.38S                   2 0 0 0 51           9502      NN22
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 2001522 UNOV11022025 2:12.59S 2:06.58S                   3 7      5           9501      NN52
G08SS          Kurmelovs, Artjom           90029968    1 4  50C   28.41 1:00.54 1:33.79 2:06.58                                                P             N68
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 1003528 UNOV11022025 1:17.40S 1:13.34S                   5 2      2           9503      NN52
G08SS          Kurmelovs, Artjom           90029968    1 2  50C   34.26 1:13.34                                                                P             N17
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 1003408 UNOV11022025 1:17.40S 1:13.34S                   9 2 0 0 32           9503      NN72
G08SS          Kurmelovs, Artjom           90029968    1 2  50C   34.26 1:13.34                                                                P             N17
D08SS      Kurmelovs, Artjom           90029968    AGBR0624201114MM 2001402 UNOV11022025 2:12.59S 2:06.58S                   7 7 0 0 40           9501      NN82
G08SS          Kurmelovs, Artjom           90029968    1 4  50C   28.41 1:00.54 1:33.79 2:06.58                                                P             N68
D08SS      Lambley, Lucy               90024141    AGBR0527201015FF  501112 UNOV11012025   29.69S   29.33S                   2 7 0 0 39           9501      NN30
D390024141                                                                                                                                                   N48
D08SS      Lambley, Lucy               90024141    AGBR0527201015FF  504411 UNOV11022025   32.40S   31.87S                   1 5 0 0 38           9504      NN30
D08SS      Lau, Kyan T                 90035251    AGBR0415201213MM 1003528 UNOV11022025 1:22.00S 1:20.63S                   2 5     28           9503      NN39
D390035251                                                                                                                                                   N48
G08SS          Lau, Kyan T                 90035251    1 2  50C   37.37 1:20.63                                                                P             N93
D08SS      Lau, Kyan T                 90035251    AGBR0415201213MM 2003113 UNOV11012025 2:57.02S 2:55.16S                   7 0 0 0 59           9503      NN69
G08SS          Lau, Kyan T                 90035251    1 4  50C   38.93 1:23.32 2:09.80 2:55.16                                                P             N45
D08SS      Lau, Kyan T                 90035251    AGBR0415201213MM 1003408 UNOV11022025 1:22.00S 1:20.63S                   6 5 0 0 64           9503      NN59
G08SS          Lau, Kyan T                 90035251    1 2  50C   37.37 1:20.63                                                                P             N93
D08SS      Lava, Lily W                90035356    AGBR0611201114FF 2001102 UNOV11012025 2:24.30S 2:23.78S                   5 8 0 0 47           9501      NN99
D390035356                                                                                                                                                   N58
G08SS          Lava, Lily W                90035356    1 4  50C   32.59 1:09.78 1:46.90 2:23.78                                                P             N95
D08SS      Lava, Lily W                90035356    AGBR0611201114FF  503403 UNOV11022025   36.96S   36.67S                   4 5 0 0 25           9503      NN59
D08SS      Lava, Lily W                90035356    AGBR0611201114FF  504411 UNOV11022025   30.70S   31.48S                   3 5 0 0 33           9504      NN39
D08SS      Lava, Lily W                90035356    AGBR0611201114FF 1004110 UNOV11012025 1:13.63S 1:15.02S                   6 3 0 0 47           9504      NN89
G08SS          Lava, Lily W                90035356    1 2  50C   34.26 1:15.02                                                                P             N34
D08SS      Lava, Lily W                90035356    AGBR0611201114FF 1001529 UNOV11022025 1:02.88S 1:04.27S                   2 3     18           9501      NN79
G08SS          Lava, Lily W                90035356    1 2  50C   30.17 1:04.27                                                                P             N34
D08SS      Lava, Lily W                90035356    AGBR0611201114FF 1001409 UNOV11022025 1:02.88S 1:04.27S                   6 3 0 0 49           9501      NN99
G08SS          Lava, Lily W                90035356    1 2  50C   30.17 1:04.27                                                                P             N34
D08SS      Lennox, Kieran              1297331     AGBR0921200619MM 1001109 UNOV11012025   51.30S   54.96S                   4 3 0 0 19           9501      NN80
D31297331       Kieran                                                                                                                                       N50
G08SS          Lennox, Kieran              1297331     1 2  50C   25.19   54.96                                                                P             N45
D08SS      Lennox, Kieran              1297331     AGBR0921200619MM  504111 UNOV11012025   23.70S   24.15S            23.79S 4 4 2 4  1  1 10.   1950400    NN02
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 2001102 UNOV11012025 2:08.60S 2:08.11S          2:06.17S 3 3 1 2  5  4  7.   4950100    NN01
D390015843                                                                                                                                                   N48
G08SS          Leune, Mya                  90015843    1 4  50C   29.85 1:02.14 1:35.24 2:08.11                                                P             N55
G08SS          Leune, Mya                  90015843    1 4  50C   29.61 1:01.81 1:34.18 2:06.17                                                F             N45
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 2005106 UNOV11012025 2:26.50S 2:28.38S                   2 6 0 0 11           9505      NN69
G08SS          Leune, Mya                  90015843    1 4  50C   32.86 1:10.35 1:54.75 2:28.38                                                P             N65
D08SS      Leune, Mya                  90015843    AGBR0209201015FF  501112 UNOV11012025   27.50S   28.26S            28.22S 8 1 1 6 17 13       39501      NN20
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 2002114 UNOV11012025 2:28.92S 2:27.81S                   3 2 0 0 11           9502      NN69
G08SS          Leune, Mya                  90015843    1 4  50C   35.04 1:12.60 1:50.59 2:27.81                                                P             N55
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 4001401 UNOV11022025 4:37.60S 4:32.69S          4:29.97S 3 2 1 2  5  5  6.   5950100    NN21
G08SS          Leune, Mya                  90015843    1 8  50C   31.01 1:05.05 1:39.56 2:14.34 2:49.10 3:23.90 3:58.87 4:32.69                P             N58
G08SS          Leune, Mya                  90015843    1 8  50C   30.56 1:03.59 1:37.46 2:11.55 2:46.18 3:21.20 3:56.08 4:29.97                F             N48
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 1001409 UNOV11022025   59.20S 1:00.25S            59.21S 4 2 1 3 15 11       19501      NN40
G08SS          Leune, Mya                  90015843    1 2  50C   29.22 1:00.25                                                                P             N04
G08SS          Leune, Mya                  90015843    1 2  50C   28.73   59.21                                                                F             N83
D08SS      Leune, Mya                  90015843    AGBR0209201015FF 2003413 UNOV11022025 2:51.73S 2:53.31S                   3 8 0 0 24           9503      NN69
G08SS          Leune, Mya                  90015843    1 4  50C   39.77 1:24.08 2:09.06 2:53.31                                                P             N55
D08SS      MacPhie, Amy                90028823    AGBR0324201114FF 2005106 UNOV11012025 2:44.75S 2:41.69S                   5 7 0 0 40           9505      NN20
D390028823                                                                                                                                                   N58
G08SS          MacPhie, Amy                90028823    1 4  50C   33.76 1:14.40 2:04.50 2:41.69                                                P             N06
D08SS      MacPhie, Amy                90028823    AGBR0324201114FF  501112 UNOV11012025   29.37S   29.56S                   3 9 0 0 45           9501      NN69
D08SS      MacPhie, Amy                90028823    AGBR0324201114FF 4001401 UNOV11022025 5:08.55S 5:05.54S                   1 9 0 0 34           9501      NN20
G08SS          MacPhie, Amy                90028823    1 8  50C   32.12 1:08.41 1:46.78 2:25.96 3:05.95 3:45.99 4:26.51 5:05.54                P             N19
D08SS      MacPhie, Amy                90028823    AGBR0324201114FF 1004110 UNOV11012025 1:18.37S 1:18.73S                   7 8 0 0 51           9504      NN20
G08SS          MacPhie, Amy                90028823    1 2  50C   34.94 1:18.73                                                                P             N64
D08SS      McClelland, Daniel          90027997    AGBR0113201213MM 2004105 UNOV11012025 2:52.94S 2:45.40S                   5 6 0 0 43           9504      NN42
D390027997                                                                                                                                                   N58
G08SS          McClelland, Daniel          90027997    1 4  50C   35.97 1:19.03 2:02.57 2:45.40                                                P             N38
D08SS      McDonald, Alana             90018000    AGBR0710201015FF  503403 UNOV11022025   36.00S   36.28S            36.21S 7 9 1 7 19 17       79503      NN71
D390018000                                                                                                                                                   N48
D08SS      McDonald, Alana             90018000    AGBR0710201015FF 2004405 UNOV11022025 3:05.33S 3:16.09S                   1 9 0 0 40           9504      NN11
G08SS          McDonald, Alana             90018000    1 4  50C   37.45 1:25.04 2:16.50 3:16.09                                                P             N07
D08SS      McDonald, Alana             90018000    AGBR0710201015FF 2003413 UNOV11022025 2:57.98S 2:55.39S                   1 6 0 0 28           9503      NN21
G08SS          McDonald, Alana             90018000    1 4  50C   39.48 1:23.16 2:09.32 2:55.39                                                P             N07
D08SS      Mclean, Alexis              90013482    AGBR0622201213FF 2004405 UNOV11022025 2:57.30S      DQS                   1 5 0 0  0           9504      NN70
D390013482                                                                                                                                                   N48
G08SS          Mclean, Alexis              90013482    1 4  50C                                                                                P             N34
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF  502104 UNOV11012025   30.52S   30.47S            30.25S 4 2 2 9 10 10  1.   0950200    NN71
D390033780                                                                                                                                                   N48
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF 2005106 UNOV11012025 2:30.90S 2:36.57S                   3 7 0 0 28           9505      NN01
G08SS          McMahon, Sofia              90033780    1 4  50C   34.30 1:14.27 2:01.09 2:36.57                                                P             N86
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF 1004110 UNOV11012025 1:04.50S 1:09.65S          1:08.76S 3 6 1 7 22 18       89504      NN32
G08SS          McMahon, Sofia              90033780    1 2  50C   33.36 1:09.65                                                                P             N45
G08SS          McMahon, Sofia              90033780    1 2  50C   32.07 1:08.76                                                                F             N35
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF  503403 UNOV11022025   38.00S   38.55S                   3 2 0 0 44           9503      NN40
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF 1002407 UNOV11022025 1:06.80S 1:06.34S          1:05.01S 4 2 2 1  7  6  5.   6950200    NN32
G08SS          McMahon, Sofia              90033780    1 2  50C   32.11 1:06.34                                                                P             N35
G08SS          McMahon, Sofia              90033780    1 2  50C   31.57 1:05.01                                                                F             N35
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF 1001409 UNOV11022025 1:00.30S 1:05.10S                   3 0 0 0 59           9501      NN80
G08SS          McMahon, Sofia              90033780    1 2  50C   30.75 1:05.10                                                                P             N35
D08SS      McMahon, Sofia              90033780    AGBR0522201114FF  504411 UNOV11022025   28.60S   29.58S            28.92S 5 3 1 4 11 11       19504      NN51
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 2001102 UNOV11012025 2:03.30S 2:04.57S          2:03.04S 3 4 1 5  2  1 10.   1950100    NN14
D390039978      Mary                                                                                                                                         N00
G08SS          Mishchenko, Mariia          90039978    1 4  50C   29.06 1:00.70 1:32.99 2:04.57                                                P             N68
G08SS          Mishchenko, Mariia          90039978    1 4  50C   28.67 1:00.17 1:32.14 2:03.04                                                F             N58
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF  502104 UNOV11012025   29.88S   30.96S                   5 6 0 0 13           9502      NN32
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 2005106 UNOV11012025 2:20.18S 2:25.90S          2:26.84S 4 5 1 1  7  8  3.   8950500    NN34
G08SS          Mishchenko, Mariia          90039978    1 4  50C   32.12 1:08.91 1:52.70 2:25.90                                                P             N68
G08SS          Mishchenko, Mariia          90039978    1 4  50C   32.52 1:09.72 1:53.59 2:26.84                                                F             N68
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 1003108 UNOV11012025 1:15.04S 1:17.29S          1:19.37S 3 5 2 8  8 10  1.   0950300    NN34
G08SS          Mishchenko, Mariia          90039978    1 2  50C   36.39 1:17.29                                                                P             N27
G08SS          Mishchenko, Mariia          90039978    1 2  50C   36.72 1:19.37                                                                F             N17
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 1004110 UNOV11012025 1:07.38S 1:08.89S                   4 8 0 0 19           9504      NN82
G08SS          Mishchenko, Mariia          90039978    1 2  50C   31.96 1:08.89                                                                P             N27
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF  501112 UNOV11012025   25.90S   26.55S            26.53S 6 4 2 6  4  4  7.   4950100    NN53
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 4001401 UNOV11022025 4:27.81S 4:29.15S          4:27.12S 3 4 1 5  2  3  8.   3950100    NN24
G08SS          Mishchenko, Mariia          90039978    1 8  50C   30.38 1:04.20 1:38.25 2:12.37 2:46.73 3:21.01 3:55.34 4:29.15                P             N51
G08SS          Mishchenko, Mariia          90039978    1 8  50C   29.26 1:01.81 1:35.21 2:09.12 2:43.31 3:17.90 3:52.82 4:27.12                F             N41
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF  503403 UNOV11022025   34.61S   37.33S                   6 2 0 0 35           9503      NN22
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 1002407 UNOV11022025 1:04.31S 1:06.93S                   2 5 0 0  9  0       09502      NN82
G08SS          Mishchenko, Mariia          90039978    1 2  50C   32.00 1:06.93                                                                P             N17
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF 1001409 UNOV11022025   56.20S   58.36S               NSS 4 4 2 6  4  0       09501      NN23
G08SS          Mishchenko, Mariia          90039978    1 2  50C   28.11   58.36                                                                P             N96
G08SS          Mishchenko, Mariia          90039978    1 2  50C                                                                                F             N95
D08SS      Mishchenko, Mariia          90039978    AGBR0225200619FF  504411 UNOV11022025   29.76S   32.50S                   7 0 0 0 50           9504      NN22
D08SS      Mishchenko, Veronika        90043043    AGBR0421201114FF  501112 UNOV11012025   29.10S   28.75S                   3 3 0 0 28           9501      NN92
D390043043      Veronika                                                                                                                                     N41
D08SS      Mishchenko, Veronika        90043043    AGBR0421201114FF 2003533 UNOV11022025 3:08.74S 3:12.96S                   1 8     15           9503      NN43
G08SS          Mishchenko, Veronika        90043043    1 4  50C   42.51 1:31.49 2:22.13 3:12.96                                                P             N49
D08SS      Mishchenko, Veronika        90043043    AGBR0421201114FF 1001529 UNOV11022025 1:03.50S 1:02.86S                   2 2     10           9501      NN23
G08SS          Mishchenko, Veronika        90043043    1 2  50C   30.17 1:02.86                                                                P             N97
D08SS      Mishchenko, Veronika        90043043    AGBR0421201114FF 1001409 UNOV11022025 1:03.50S 1:02.86S                   6 2 0 0 38           9501      NN53
G08SS          Mishchenko, Veronika        90043043    1 2  50C   30.17 1:02.86                                                                P             N97
D08SS      Mishchenko, Veronika        90043043    AGBR0421201114FF 2003413 UNOV11022025 3:08.74S 3:12.96S                   5 8 0 0 51           9503      NN63
G08SS          Mishchenko, Veronika        90043043    1 4  50C   42.51 1:31.49 2:22.13 3:12.96                                                P             N49
D08SS      Mitchell, Jack              90001541    AGBR0422200619MM  503103 UNOV11012025   29.30S   30.53S                   6 3 0 0 13           9503      NN50
D390001541                                                                                                                                                   N48
D08SS      Mitchell, Jack              90001541    AGBR0422200619MM 2003113 UNOV11012025 2:22.76S 2:33.01S                   3 3 0 0 15           9503      NN01
G08SS          Mitchell, Jack              90001541    1 4  50C   33.47 1:11.92 1:51.82 2:33.01                                                P             N86
D08SS      Mitchell, Jack              90001541    AGBR0422200619MM 1003408 UNOV11022025 1:04.30S 1:06.97S          1:06.53S 2 5 2 8  8  8  3.   8950300    NN62
G08SS          Mitchell, Jack              90001541    1 2  50C   31.15 1:06.97                                                                P             N45
G08SS          Mitchell, Jack              90001541    1 2  50C   30.76 1:06.53                                                                F             N45
D08SS      Mitchell, Jack              90001541    AGBR0422200619MM  501412 UNOV11022025   24.80S   25.95S                   5 1 0 0 32           9501      NN50
D08SS      Mitchell, Jack              90001541    AGBR0422200619MM  503103SUNOV11012025   30.53S            30.65S              1 4     2       2  03      NN30
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF  502104 UNOV11012025   32.21S   31.37S                   4 8 0 0 16           9502      NN11
D31786377                                                                                                                                                    N48
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF 1004110 UNOV11012025 1:05.32S 1:06.35S          1:05.89S 3 2 2 0  9  9  2.   9950400    NN13
G08SS          Miti, Tamenji Ada           1786377     1 2  50C   30.56 1:06.35                                                                P             N06
G08SS          Miti, Tamenji Ada           1786377     1 2  50C   30.67 1:05.89                                                                F             N06
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF  501112 UNOV11012025   28.38S   28.38S                   5 5 0 0 20           9501      NN11
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF  503403 UNOV11022025   35.65S   36.53S                   6 0 0 0 21           9503      NN11
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF 2004405 UNOV11022025 2:29.82S 2:36.40S                   3 6 0 0 14           9504      NN71
G08SS          Miti, Tamenji Ada           1786377     1 4  50C   33.98 1:12.01 1:53.59 2:36.40                                                P             N57
D08SS      Miti, Tamenji Ada           1786377     AGBR1230200718FF  504411 UNOV11022025   29.31S   29.62S                   5 7 0 0 12           9504      NN11
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 2005526 UNOV11022025 2:34.82S 2:28.80S                   2 9     17           9505      NN80
D390029093                                                                                                                                                   N58
G08SS          Morgan, Lewis               90029093    1 4  50C   32.46 1:10.73 1:53.49 2:28.80                                                P             N86
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 2004105 UNOV11012025 2:32.72S 2:29.53S                   2 9 0 0 27           9504      NN90
G08SS          Morgan, Lewis               90029093    1 4  50C   33.07 1:10.33 1:48.42 2:29.53                                                P             N76
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 4005201 UNOV11012025 5:16.47S                   5:14.70S     2 0    34       59505      NN80
G08SS          Morgan, Lewis               90029093    1 8  50C   34.14 1:11.58 1:52.12 2:33.72 3:17.83 4:02.04 4:38.86 5:14.70                F             N69
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 8001502 UNOV11022025 9:58.70S                   9:38.90S     1 2    21       39501      NN90
G08SS          Morgan, Lewis               90029093    116  50C   31.13 1:06.16 1:41.84 2:18.07 2:54.22 3:31.05 4:07.98 4:44.95 5:21.15 5:57.75F             N21
G08SS          Morgan, Lewis               90029093    216  50C 6:34.63 7:11.86 7:48.95 8:25.80 9:02.93 9:38.90                                F             N78
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 1002107 UNOV11012025 1:11.30S 1:12.54S                   8 0 0 0 68           9502      NN80
G08SS          Morgan, Lewis               90029093    1 2  50C   35.13 1:12.54                                                                P             N35
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 1004530 UNOV11022025 1:09.00S 1:09.41S                   1 8     11           9504      NN70
G08SS          Morgan, Lewis               90029093    1 2  50C   32.71 1:09.41                                                                P             N35
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 2001522 UNOV11022025 2:15.53S 2:20.71S                   3 8     18           9501      NN70
G08SS          Morgan, Lewis               90029093    1 4  50C   30.73 1:06.37 1:43.52 2:20.71                                                P             N76
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 2001402 UNOV11022025 2:15.53S 2:20.71S                   7 8 0 0 56           9501      NN90
G08SS          Morgan, Lewis               90029093    1 4  50C   30.73 1:06.37 1:43.52 2:20.71                                                P             N76
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 2005406 UNOV11022025 2:34.82S 2:28.80S                   6 9 0 0 55           9505      NN01
G08SS          Morgan, Lewis               90029093    1 4  50C   32.46 1:10.73 1:53.49 2:28.80                                                P             N86
D08SS      Morgan, Lewis               90029093    AGBR1102201114MM 1004410 UNOV11022025 1:09.00S 1:09.41S                   5 8 0 0 48           9504      NN90
G08SS          Morgan, Lewis               90029093    1 2  50C   32.71 1:09.41                                                                P             N35
D08SS      Morgan, Lucy                90005547    AGBR0204200817FF  504411 UNOV11022025   31.20S   32.42S                   3 1 0 0 47           9504      NN99
D390005547                                                                                                                                                   N48
D08SS      Mydliar, Matus              1294585     AGBR0421200520MM  503103 UNOV11012025   29.96S   30.00S            30.70S 5 6 3 1  7  9  2.   9950300    NN02
D31294585                                                                                                                                                    N48
D08SS      Mydliar, Matus              1294585     AGBR0421200520MM 1001109 UNOV11012025   52.94S   53.66S            53.88S 2 6 2 9 10  9  2.   9950100    NN32
G08SS          Mydliar, Matus              1294585     1 2  50C   25.72   53.66                                                                P             N55
G08SS          Mydliar, Matus              1294585     1 2  50C   25.69   53.88                                                                F             N55
D08SS      Mydliar, Matus              1294585     AGBR0421200520MM  504111 UNOV11012025   24.94S   25.69S            26.23S 4 3 2 7  6  5  6.   5950400    NN12
D08SS      Mydliar, Matus              1294585     AGBR0421200520MM 1004410 UNOV11022025   56.42S   59.13S                   4 3 0 0  9           9504      NN80
G08SS          Mydliar, Matus              1294585     1 2  50C   26.90   59.13                                                                P             N55
D08SS      Mydliar, Matus              1294585     AGBR0421200520MM  501412 UNOV11022025   23.96S   24.50S                   6 6 0 0 12           9501      NN70
D08SS      Naumovich, Mikhail          1444701     AGBR0921200619MM 2004105 UNOV11012025 2:06.70S 2:13.90S          2:13.41S 4 5 1 0  9  7  4.   7950400    NN24
D31444701                                                                                                                                                    N38
G08SS          Naumovich, Mikhail          1444701     1 4  50C   29.52 1:05.43 1:40.13 2:13.90                                                P             N48
G08SS          Naumovich, Mikhail          1444701     1 4  50C   29.26 1:03.95 1:39.33 2:13.41                                                F             N48
D08SS      Naumovich, Mikhail          1444701     AGBR0921200619MM  504111 UNOV11012025   25.70S   27.02S                   4 2 0 0 16           9504      NN12
D08SS      Naumovich, Mikhail          1444701     AGBR0921200619MM 1004410 UNOV11022025   57.14S   58.50S                   3 6 0 0  8           9504      NN22
G08SS          Naumovich, Mikhail          1444701     1 2  50C   27.67   58.50                                                                P             N86
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 4001101 UNOV11012025 4:36.09S 4:29.79S                   1 2 0 0 24           9501      NN90
D390014336      Josh                                                                                                                                         N99
G08SS          Nicol, Joshua               90014336    1 8  50C   29.63 1:02.81 1:37.75 2:13.01 2:48.02 3:22.65 3:57.18 4:29.79                P             N79
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 4005201 UNOV11012025 5:15.20S                        NSS     2 1     0       09505      NN50
G08SS          Nicol, Joshua               90014336    1 8  50C                                                                                F             N04
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 2001402 UNOV11022025 2:05.90S 2:05.98S                   1 9 0 0 37           9501      NN90
G08SS          Nicol, Joshua               90014336    1 4  50C   28.96 1:00.93 1:32.96 2:05.98                                                P             N86
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 2002414 UNOV11022025 2:22.34S 2:28.05S                   4 9 0 0 38           9502      NN90
G08SS          Nicol, Joshua               90014336    1 4  50C   34.77 1:12.08 1:50.34 2:28.05                                                P             N76
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 1001109 UNOV11012025   57.69S   57.77S                   7 6 0 0 48           9501      NN60
G08SS          Nicol, Joshua               90014336    1 2  50C   27.82   57.77                                                                P             N15
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 1002107 UNOV11012025 1:07.25S 1:09.60S                   8 3 0 0 56           9502      NN90
G08SS          Nicol, Joshua               90014336    1 2  50C   33.95 1:09.60                                                                P             N25
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 2005526 UNOV11022025 2:25.94S 2:27.84S                   3 3     15           9505      NN80
G08SS          Nicol, Joshua               90014336    1 4  50C   32.77 1:10.72 1:54.00 2:27.84                                                P             N76
D08SS      Nicol, Joshua               90014336    AGBR0508200916MM 2005406 UNOV11022025 2:25.94S 2:27.84S                   7 3 0 0 53           9505      NN01
G08SS          Nicol, Joshua               90014336    1 4  50C   32.77 1:10.72 1:54.00 2:27.84                                                P             N76
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 4001521 UNOV11022025 5:23.50S 5:12.63S                   1 6      3           9501      NN02
D390032240      Olivia                                                                                                                                       N60
G08SS          Paterson, Olivia M          90032240    1 8  50C   35.34 1:15.15 1:54.49 2:34.57 3:14.30 3:54.11 4:34.03 5:12.63                P             N01
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF  501112 UNOV11012025   33.70S   31.79S                   1 6 0 0 66           9501      NN71
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 2005106 UNOV11012025 3:07.76S 3:02.36S                   6 0 0 0 53           9505      NN32
G08SS          Paterson, Olivia M          90032240    1 4  50C   42.72 1:25.55 2:23.69 3:02.36                                                P             N28
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 1002527 UNOV11022025 1:22.20S 1:17.54S                   1 9      8           9502      NN02
G08SS          Paterson, Olivia M          90032240    1 2  50C   38.10 1:17.54                                                                P             N76
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 1001529 UNOV11022025 1:12.20S 1:10.53S                   1 2     33           9501      NN02
G08SS          Paterson, Olivia M          90032240    1 2  50C   34.18 1:10.53                                                                P             N76
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 4001401 UNOV11022025 5:23.50S 5:12.63S                   5 6 0 0 40           9501      NN32
G08SS          Paterson, Olivia M          90032240    1 8  50C   35.34 1:15.15 1:54.49 2:34.57 3:14.30 3:54.11 4:34.03 5:12.63                P             N01
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 2001102 UNOV11012025 2:34.80S 2:29.04S                   6 9 0 0 52           9501      NN32
G08SS          Paterson, Olivia M          90032240    1 4  50C   34.26 1:12.37 1:50.81 2:29.04                                                P             N18
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 1002407 UNOV11022025 1:22.20S 1:17.54S                   5 9 0 0 45           9502      NN32
G08SS          Paterson, Olivia M          90032240    1 2  50C   38.10 1:17.54                                                                P             N76
D08SS      Paterson, Olivia M          90032240    AGBR0809201114FF 1001409 UNOV11022025 1:12.20S 1:10.53S                   5 2 0 0 67           9501      NN22
G08SS          Paterson, Olivia M          90032240    1 2  50C   34.18 1:10.53                                                                P             N76
D08SS      Paton, Struan               90011727    AGBR0207200916MM 1004530 UNOV11022025 1:06.41S 1:04.88S                   2 6      3           9504      NN80
D390011727                                                                                                                                                   N48
G08SS          Paton, Struan               90011727    1 2  50C   30.92 1:04.88                                                                P             N45
D08SS      Paton, Struan               90011727    AGBR0207200916MM 1001109 UNOV11012025   55.40S   56.24S                   3 9 0 0 32           9501      NN60
G08SS          Paton, Struan               90011727    1 2  50C   26.98   56.24                                                                P             N25
D08SS      Paton, Struan               90011727    AGBR0207200916MM 2001402 UNOV11022025 2:05.15S 2:06.34S                   1 7 0 0 39           9501      NN01
G08SS          Paton, Struan               90011727    1 4  50C   28.74 1:00.86 1:34.19 2:06.34                                                P             N96
D08SS      Paton, Struan               90011727    AGBR0207200916MM 2005526 UNOV11022025 2:26.00S 2:22.02S                   2 3      1           9505      NN70
G08SS          Paton, Struan               90011727    1 4  50C   30.74 1:08.48 1:51.52 2:22.02                                                P             N86
D08SS      Paton, Struan               90011727    AGBR0207200916MM 1002107 UNOV11012025 1:06.80S 1:05.16S                   8 5 0 0 29           9502      NN11
G08SS          Paton, Struan               90011727    1 2  50C   31.57 1:05.16                                                                P             N45
D08SS      Paton, Struan               90011727    AGBR0207200916MM 2005406 UNOV11022025 2:26.00S 2:22.02S                   6 3 0 0 31           9505      NN01
G08SS          Paton, Struan               90011727    1 4  50C   30.74 1:08.48 1:51.52 2:22.02                                                P             N86
D08SS      Paton, Struan               90011727    AGBR0207200916MM 1004410 UNOV11022025 1:06.41S 1:04.88S                   6 6 0 0 38           9504      NN11
G08SS          Paton, Struan               90011727    1 2  50C   30.92 1:04.88                                                                P             N45
D08SS      Perry, Yasmin               769348      AGBR0326200124FF 1004110 UNOV11012025 1:00.99S 1:00.17S            59.77S 4 4 2 4  1  1 10.   1950400    NN12
D3769348        Yasmin                                                                                                                                       N60
G08SS          Perry, Yasmin               769348      1 2  50C   28.29 1:00.17                                                                P             N35
G08SS          Perry, Yasmin               769348      1 2  50C   28.07   59.77                                                                F             N15
D08SS      Perry, Yasmin               769348      AGBR0326200124FF  501112 UNOV11012025   26.75S   26.34S            26.84S 8 6 2 5  2  5  6.   5950100    NN61
D08SS      Perry, Yasmin               769348      AGBR0326200124FF  504411 UNOV11022025   27.75S   27.61S            27.34S 7 5 2 4  1  1 10.   1950400    NN71
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM 2004105 UNOV11012025 2:17.69S 2:24.60S                   2 6 0 0 22           9504      NN71
D390020418      Matthew                                                                                                                                      N11
G08SS          Piatek, Mateusz             90020418    1 4  50C   30.36 1:05.70 1:43.86 2:24.60                                                P             N57
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM  504111 UNOV11012025   27.00S   27.91S               NSS 3 9 1 0 30  0       09504      NN12
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM 2001402 UNOV11022025 2:05.70S 2:06.29S                   1 0 0 0 38           9501      NN71
G08SS          Piatek, Mateusz             90020418    1 4  50C   28.30 1:00.08 1:33.51 2:06.29                                                P             N57
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM 1004410 UNOV11022025 1:01.50S 1:01.55S          1:01.25S 2 0 1 6 21 15       59504      NN92
G08SS          Piatek, Mateusz             90020418    1 2  50C   28.48 1:01.55                                                                P             N16
G08SS          Piatek, Mateusz             90020418    1 2  50C   27.94 1:01.25                                                                F             N06
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM  501412 UNOV11022025   25.90S   27.03S                   3 8 0 0 53           9501      NN21
D08SS      Piatek, Mateusz             90020418    AGBR0220200916MM 1001109 UNOV11012025   57.30S   57.63S                   6 3 0 0 46           9501      NN31
G08SS          Piatek, Mateusz             90020418    1 2  50C   27.32   57.63                                                                P             N95
D08SS      Reid, Libby                 90018570    AGBR0507201114FF  501112 UNOV11012025   29.42S   29.58S                   2 5 0 0 47           9501      NN49
D390018570                                                                                                                                                   N48
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 4001401 UNOV11022025 5:01.65S 4:58.75S                   1 3 0 0 28           9501      NN00
G08SS          Reid, Libby                 90018570    1 8  50C   33.00 1:09.54 1:47.15 2:25.77 3:04.58 3:43.62 4:22.22 4:58.75                P             N88
D08SS      Reid, Libby                 90018570    AGBR0507201114FF  503403 UNOV11022025   39.41S   40.13S                   1 4 0 0 57           9503      NN49
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 1003108 UNOV11012025 1:27.11S 1:28.09S                   6 7 0 0 47           9503      NN00
G08SS          Reid, Libby                 90018570    1 2  50C   41.42 1:28.09                                                                P             N34
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 1001529 UNOV11022025 1:04.90S 1:04.50S                   3 9     20           9501      NN79
G08SS          Reid, Libby                 90018570    1 2  50C   31.60 1:04.50                                                                P             N34
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 2001102 UNOV11012025 2:21.88S 2:19.76S                   5 2 0 0 40           9501      NN99
G08SS          Reid, Libby                 90018570    1 4  50C   32.00 1:07.45 1:43.61 2:19.76                                                P             N85
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 1002527 UNOV11022025 1:13.67S 1:13.20S                   1 5      3           9502      NN69
G08SS          Reid, Libby                 90018570    1 2  50C   35.58 1:13.20                                                                P             N34
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 1002407 UNOV11022025 1:13.67S 1:13.20S                   5 5 0 0 33           9502      NN99
G08SS          Reid, Libby                 90018570    1 2  50C   35.58 1:13.20                                                                P             N34
D08SS      Reid, Libby                 90018570    AGBR0507201114FF 1001409 UNOV11022025 1:04.90S 1:04.50S                   7 9 0 0 51           9501      NN99
G08SS          Reid, Libby                 90018570    1 2  50C   31.60 1:04.50                                                                P             N34
D08SS      Rogers, Ben                 869799      AGBR0131200520MM 4001101 UNOV11012025 4:16.30S 4:08.37S          4:06.40S 3 2 1 6  4  3  8.   3950100    NN41
D3869799                                                                                                                                                     N48
G08SS          Rogers, Ben                 869799      1 8  50C   27.92   58.60 1:30.16 2:01.93 2:33.93 3:05.86 3:37.64 4:08.37                P             N68
G08SS          Rogers, Ben                 869799      1 8  50C   27.88   58.62 1:29.95 2:01.47 2:33.03 3:04.86 3:36.41 4:06.40                F             N58
D08SS      Rogers, Ben                 869799      AGBR0131200520MM  503103 UNOV11012025   29.80S   30.56S                   7 6 0 0 14           9503      NN49
D08SS      Rogers, Ben                 869799      AGBR0131200520MM 2003113 UNOV11012025 2:20.34S 2:23.20S          2:24.86S 4 5 1 6  4  6  5.   6950300    NN41
G08SS          Rogers, Ben                 869799      1 4  50C   31.53 1:08.20 1:45.64 2:23.20                                                P             N75
G08SS          Rogers, Ben                 869799      1 4  50C   32.06 1:09.10 1:46.80 2:24.86                                                F             N75
D08SS      Rogers, Ben                 869799      AGBR0131200520MM 4005201 UNOV11012025 4:45.46S                   4:40.06S     5 9     5  6.   5950500    NN20
G08SS          Rogers, Ben                 869799      1 8  50C   29.07 1:03.49 1:41.72 2:19.18 2:58.44 3:36.82 4:09.35 4:40.06                F             N88
D08SS      Rogers, Ben                 869799      AGBR0131200520MM 2005406 UNOV11022025 2:14.20S 2:10.28S                   2 3 0 0  6           9505      NN89
G08SS          Rogers, Ben                 869799      1 4  50C   28.21 1:03.29 1:39.95 2:10.28                                                P             N85
D08SS      Rogers, Ben                 869799      AGBR0131200520MM 1003408 UNOV11022025 1:04.00S 1:05.39S          1:05.27S 3 5 2 2  5  6  5.   6950300    NN41
G08SS          Rogers, Ben                 869799      1 2  50C   30.52 1:05.39                                                                P             N34
G08SS          Rogers, Ben                 869799      1 2  50C   30.49 1:05.27                                                                F             N34
D08SS      Scally, Logan               90002260    AGBR0928200718MM 2004105 UNOV11012025 2:21.90S 2:20.60S                   2 7 0 0 14           9504      NN80
D390002260                                                                                                                                                   N48
G08SS          Scally, Logan               90002260    1 4  50C   30.74 1:06.42 1:42.20 2:20.60                                                P             N56
D08SS      Scally, Logan               90002260    AGBR0928200718MM 1002107 UNOV11012025 1:05.32S 1:07.04S                   3 0 0 0 41           9502      NN80
G08SS          Scally, Logan               90002260    1 2  50C   31.64 1:07.04                                                                P             N15
D08SS      Scally, Logan               90002260    AGBR0928200718MM 2003113 UNOV11012025 2:44.00S 2:37.64S                   1 0 0 0 24           9503      NN80
G08SS          Scally, Logan               90002260    1 4  50C   36.28 1:16.33 1:56.94 2:37.64                                                P             N76
D08SS      Scally, Logan               90002260    AGBR0928200718MM  502404 UNOV11022025   28.19S   28.33S                   6 7 0 0 17           9502      NN40
D08SS      Scally, Logan               90002260    AGBR0928200718MM 2005406 UNOV11022025 2:20.08S 2:21.75S                   3 8 0 0 29           9505      NN90
G08SS          Scally, Logan               90002260    1 4  50C   29.51 1:07.71 1:48.85 2:21.75                                                P             N76
D08SS      Scally, Logan               90002260    AGBR0928200718MM 1004410 UNOV11022025 1:00.50S 1:01.69S                   4 8 0 0 23           9504      NN80
G08SS          Scally, Logan               90002260    1 2  50C   28.56 1:01.69                                                                P             N25
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF 2001102 UNOV11012025 2:12.40S 2:12.73S                   4 1 0 0 13           9501      NN33
D31305294       AnnaB                                                                                                                                        N89
G08SS          Scatterty, Annabella        1305294     1 4  50C   30.48 1:03.76 1:38.13 2:12.73                                                P             N39
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF  502104 UNOV11012025   33.88S   35.09S                   2 8 0 0 41           9502      NN92
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF  501112 UNOV11012025   28.50S   29.56S                   5 8 0 0 45           9501      NN92
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF 8001202 UNOV11012025 9:48.40S                   9:42.83S     2 5     9  2.   2950100    NN73
G08SS          Scatterty, Annabella        1305294     116  50C   31.95 1:07.83 1:44.20 2:20.68 2:57.34 3:33.93 4:10.49 4:47.44 5:24.51 6:01.83F             N73
G08SS          Scatterty, Annabella        1305294     216  50C 6:38.95 7:16.06 7:53.10 8:30.40 9:07.70 9:42.83                                F             N21
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF 4001401 UNOV11022025 4:40.80S 4:40.28S          4:43.20S 4 7 1 8  8  8  3.   8950100    NN94
G08SS          Scatterty, Annabella        1305294     1 8  50C   30.92 1:05.03 1:40.09 2:15.87 2:51.93 3:28.09 4:04.54 4:40.28                P             N22
G08SS          Scatterty, Annabella        1305294     1 8  50C   31.25 1:05.62 1:41.13 2:16.90 2:53.20 3:29.92 4:07.01 4:43.20                F             N02
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF 1001529 UNOV11022025 1:02.30S 1:02.15S                   4 5      6           9501      NN13
G08SS          Scatterty, Annabella        1305294     1 2  50C   29.44 1:02.15                                                                P             N87
D08SS      Scatterty, Annabella        1305294     AGBR0610200916FF 1001409 UNOV11022025 1:02.30S 1:02.15S                   8 5 0 0 31           9501      NN33
G08SS          Scatterty, Annabella        1305294     1 2  50C   29.44 1:02.15                                                                P             N87
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 4001101 UNOV11012025 4:19.35S 4:15.63S          4:11.01S 3 8 1 8  8  5  6.   5950100    NN73
D390013913                                                                                                                                                   N48
G08SS          Sinclair, Taylor            90013913    1 8  50C   28.80   59.90 1:31.88 2:04.53 2:37.07 3:09.98 3:42.85 4:15.63                P             N80
G08SS          Sinclair, Taylor            90013913    1 8  50C   28.67   59.73 1:31.65 2:03.54 2:35.51 3:07.56 3:39.85 4:11.01                F             N60
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 1001109 UNOV11012025   56.00S   55.67S                   1 8 0 0 26           9501      NN71
G08SS          Sinclair, Taylor            90013913    1 2  50C   27.11   55.67                                                                P             N36
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 2003113 UNOV11012025 2:34.44S 2:38.11S                   3 1 0 0 26           9503      NN12
G08SS          Sinclair, Taylor            90013913    1 4  50C   35.21 1:14.89 1:56.31 2:38.11                                                P             N97
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 4005201 UNOV11012025 4:57.80S                   4:48.20S     4 8    13       49505      NN22
G08SS          Sinclair, Taylor            90013913    1 8  50C   30.00 1:04.83 1:44.00 2:21.66 3:02.93 3:43.92 4:17.10 4:48.20                F             N70
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 2001402 UNOV11022025 2:00.59S 1:59.84S                   3 1 0 0 13           9501      NN12
G08SS          Sinclair, Taylor            90013913    1 4  50C   27.98   57.99 1:29.28 1:59.84                                                P             N97
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 2005406 UNOV11022025 2:16.40S 2:16.29S                   2 2 0 0 13           9505      NN22
G08SS          Sinclair, Taylor            90013913    1 4  50C   28.96 1:04.46 1:44.90 2:16.29                                                P             N08
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 1004410 UNOV11022025 1:01.10S 1:01.56S                   4 0 0 0 22           9504      NN02
G08SS          Sinclair, Taylor            90013913    1 2  50C   28.67 1:01.56                                                                P             N56
D08SS      Sinclair, Taylor            90013913    AGBR0109200718MM 8001502 UNOV11022025 8:52.94S                   8:39.51S     2 5     4  7.   1950100    NN52
G08SS          Sinclair, Taylor            90013913    116  50C   29.27 1:00.42 1:32.79 2:05.64 2:38.51 3:11.46 3:44.31 4:17.49 4:50.05 5:22.72F             N32
G08SS          Sinclair, Taylor            90013913    216  50C 5:56.00 6:28.92 7:01.89 7:35.46 8:08.25 8:39.51                                F             N99
D08SS      Smith, Eve Marie            90027963    AGBR0116201015FF 1004110 UNOV11012025 1:11.90S 1:11.82S                   7 4 0 0 32           9504      NN41
D390027963      Eve Marie                                                                                                                                    N21
G08SS          Smith, Eve Marie            90027963    1 2  50C   33.14 1:11.82                                                                P             N85
D08SS      Smith, Eve Marie            90027963    AGBR0116201015FF 2004405 UNOV11022025 2:40.10S 2:39.52S                   3 8 0 0 16           9504      NN41
G08SS          Smith, Eve Marie            90027963    1 4  50C   34.58 1:14.47 1:56.51 2:39.52                                                P             N47
D08SS      Smith, Eve Marie            90027963    AGBR0116201015FF  504411 UNOV11022025   32.20S   32.68S                   2 1 0 0 53           9504      NN90
D08SS      Smith, Eve Marie            90027963    AGBR0116201015FF 2002114 UNOV11012025 2:42.18S 2:40.00S                   5 5 0 0 37           9502      NN41
G08SS          Smith, Eve Marie            90027963    1 4  50C   37.31 1:17.82 1:59.28 2:40.00                                                P             N37
D08SS      Smith, Jessica              90015834    AGBR1007200718FF 2005106 UNOV11012025 2:30.00S 2:32.80S                   4 7 0 0 18           9505      NN21
D390015834      Jessica                                                                                                                                      N01
G08SS          Smith, Jessica              90015834    1 4  50C   33.10 1:11.85 1:57.52 2:32.80                                                P             N07
D08SS      Smith, Jessica              90015834    AGBR1007200718FF 1003108 UNOV11012025 1:21.20S 1:20.57S                   2 0 0 0 22           9503      NN11
G08SS          Smith, Jessica              90015834    1 2  50C   39.33 1:20.57                                                                P             N65
D08SS      Smith, Jessica              90015834    AGBR1007200718FF 2002114 UNOV11012025 2:34.08S 2:33.25S                   4 9 0 0 20           9502      NN21
G08SS          Smith, Jessica              90015834    1 4  50C   35.39 1:14.62 1:54.84 2:33.25                                                P             N17
D08SS      Smith, Jessica              90015834    AGBR1007200718FF 4005501 UNOV11022025 5:22.60S                   5:18.95S     4 2     9  2.   1950500    NN51
G08SS          Smith, Jessica              90015834    1 8  50C   34.25 1:13.45 1:54.44 2:34.90 3:20.15 4:05.48 4:42.96 5:18.95                F             N00
D08SS      Sommerville, Rebecca L      1250970     AGBR1117200619FF 2005106 UNOV11012025 2:34.20S 2:42.49S                   2 0 0 0 45           9505      NN63
D31250970       Rebecca                                                                                                                                      N70
G08SS          Sommerville, Rebecca L      1250970     1 4  50C   35.83 1:15.38 2:07.44 2:42.49                                                P             N59
D08SS      Sommerville, Rebecca L      1250970     AGBR1117200619FF 2002114 UNOV11012025 2:28.96S 2:37.84S                   2 2 0 0 32           9502      NN63
G08SS          Sommerville, Rebecca L      1250970     1 4  50C   37.63 1:17.50 1:57.63 2:37.84                                                P             N59
D08SS      Sommerville, Rebecca L      1250970     AGBR1117200619FF 8001202 UNOV11012025 9:36.40S                   9:50.30S     3 1    15       99501      NN53
G08SS          Sommerville, Rebecca L      1250970     116  50C   33.39 1:09.75 1:47.30 2:24.80 3:02.21 3:39.85 4:17.33 4:54.95 5:32.59 6:09.42F             N04
G08SS          Sommerville, Rebecca L      1250970     216  50C 6:46.29 7:23.61 8:00.36 8:37.50 9:14.33 9:50.30                                F             N31
D08SS      Sommerville, Rebecca L      1250970     AGBR1117200619FF 4001401 UNOV11022025 4:43.28S 4:49.09S                   4 1 0 0 17           9501      NN63
G08SS          Sommerville, Rebecca L      1250970     1 8  50C   33.27 1:09.65 1:46.71 2:23.67 2:59.87 3:36.50 4:13.38 4:49.09                P             N52
D08SS      Sommerville, Rebecca L      1250970     AGBR1117200619FF 4005501 UNOV11022025 5:19.95S                   5:24.27S     4 3    16       49505      NN63
G08SS          Sommerville, Rebecca L      1250970     1 8  50C   35.50 1:15.75 1:56.09 2:35.02 3:23.41 4:12.92 4:49.11 5:24.27                F             N32
D08SS      Steele, Sophie M            1293413     AGBR1113200718FF 2005106 UNOV11012025 2:26.12S 2:28.19S          2:31.93S 4 6 1 9 10 10  1.   0950500    NN03
D31293413                                                                                                                                                    N38
G08SS          Steele, Sophie M            1293413     1 4  50C   32.41 1:10.37 1:54.04 2:28.19                                                P             N27
G08SS          Steele, Sophie M            1293413     1 4  50C   31.65 1:09.17 1:57.03 2:31.93                                                F             N27
D08SS      Steele, Sophie M            1293413     AGBR1113200718FF 1004110 UNOV11012025 1:06.88S 1:07.79S                   3 1 0 0 14           9504      NN31
G08SS          Steele, Sophie M            1293413     1 2  50C   32.29 1:07.79                                                                P             N85
D08SS      Steele, Sophie M            1293413     AGBR1113200718FF  501112 UNOV11012025   27.20S      DQS                   6 2 0 0  0           9501      NN60
D08SS      Steele, Sophie M            1293413     AGBR1113200718FF 1001409 UNOV11022025   59.45S   59.67S            59.98S 2 2 2 0 10  8  3.   8950100    NN42
G08SS          Steele, Sophie M            1293413     1 2  50C   28.88   59.67                                                                P             N65
G08SS          Steele, Sophie M            1293413     1 2  50C   28.78   59.98                                                                F             N65
D08SS      Steele, Sophie M            1293413     AGBR1113200718FF  504411 UNOV11022025   29.90S   30.48S                   6 9 0 0 20           9504      NN80
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 4001101 UNOV11012025 4:57.42S 4:43.22S                   6 2 0 0 36           9501      NN71
D390012798                                                                                                                                                   N58
G08SS          Strachan, Aedan J           90012798    1 8  50C   30.94 1:05.83 1:42.29 2:19.32 2:55.92 3:32.64 4:08.72 4:43.22                P             N50
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 1003528 UNOV11022025 1:20.60S 1:18.22S                   5 9     16           9503      NN51
G08SS          Strachan, Aedan J           90012798    1 2  50C   36.92 1:18.22                                                                P             N16
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 2003113 UNOV11012025 2:51.38S 2:48.45S                   7 8 0 0 49           9503      NN81
G08SS          Strachan, Aedan J           90012798    1 4  50C   37.80 1:21.47 2:05.52 2:48.45                                                P             N57
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 2005526 UNOV11022025 2:30.49S 2:29.70S                   2 7     20           9505      NN61
G08SS          Strachan, Aedan J           90012798    1 4  50C   33.70 1:12.78 1:55.77 2:29.70                                                P             N67
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 2005406 UNOV11022025 2:30.49S 2:29.70S                   6 7 0 0 58           9505      NN81
G08SS          Strachan, Aedan J           90012798    1 4  50C   33.70 1:12.78 1:55.77 2:29.70                                                P             N67
D08SS      Strachan, Aedan J           90012798    AGBR0320201114MM 1003408 UNOV11022025 1:20.60S 1:18.22S                   9 9 0 0 52           9503      NN71
G08SS          Strachan, Aedan J           90012798    1 2  50C   36.92 1:18.22                                                                P             N16
D08SS      Strachan, Alexx C           90020602    AGBR0402201213FF 2001102 UNOV11012025 2:24.50S 2:21.91S                   5 0 0 0 43           9501      NN61
D390020602                                                                                                                                                   N48
G08SS          Strachan, Alexx C           90020602    1 4  50C   32.68 1:08.66 1:45.40 2:21.91                                                P             N67
D08SS      Strachan, Alexx C           90020602    AGBR0402201213FF 4001521 UNOV11022025 5:10.50S 4:58.70S                   1 4      1           9501      NN41
G08SS          Strachan, Alexx C           90020602    1 8  50C   32.44 1:08.76 1:47.00 2:26.01 3:04.56 3:43.61 4:22.27 4:58.70                P             N50
D08SS      Strachan, Alexx C           90020602    AGBR0402201213FF 1001529 UNOV11022025 1:05.30S 1:05.59S                   1 5     28           9501      NN51
G08SS          Strachan, Alexx C           90020602    1 2  50C   31.54 1:05.59                                                                P             N26
D08SS      Strachan, Alexx C           90020602    AGBR0402201213FF 4001401 UNOV11022025 5:10.50S 4:58.70S                   5 4 0 0 27           9501      NN71
G08SS          Strachan, Alexx C           90020602    1 8  50C   32.44 1:08.76 1:47.00 2:26.01 3:04.56 3:43.61 4:22.27 4:58.70                P             N50
D08SS      Strachan, Alexx C           90020602    AGBR0402201213FF 1001409 UNOV11022025 1:05.30S 1:05.59S                   5 5 0 0 61           9501      NN71
G08SS          Strachan, Alexx C           90020602    1 2  50C   31.54 1:05.59                                                                P             N26
D08SS      Strachan, Lexie             90021550    AGBR0602201213FF 2001102 UNOV11012025 2:23.39S 2:22.46S                   6 1 0 0 44           9501      NN41
D390021550                                                                                                                                                   N48
G08SS          Strachan, Lexie             90021550    1 4  50C   32.65 1:08.66 1:46.40 2:22.46                                                P             N47
D08SS      Strachan, Lexie             90021550    AGBR0602201213FF 2002114 UNOV11012025 2:40.41S 2:37.66S                   1 1 0 0 31           9502      NN41
G08SS          Strachan, Lexie             90021550    1 4  50C   37.63 1:17.94 1:58.64 2:37.66                                                P             N57
D08SS      Strachan, Lexie             90021550    AGBR0602201213FF 4001401 UNOV11022025 5:02.65S 4:58.24S                   1 6 0 0 25           9501      NN51
G08SS          Strachan, Lexie             90021550    1 8  50C   33.73 1:10.62 1:48.52 2:26.47 3:04.80 3:43.07 4:21.87 4:58.24                P             N30
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF 2001102 UNOV11012025 2:17.00S 2:16.21S                   1 0 0 0 25           9501      NN61
D390017726                                                                                                                                                   N58
G08SS          Stuart, Madisyn             90017726    1 4  50C   29.88 1:04.41 1:40.07 2:16.21                                                P             N67
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF 1004110 UNOV11012025 1:11.10S 1:08.89S          1:08.30S 1 0 1 6 19 16       69504      NN03
G08SS          Stuart, Madisyn             90017726    1 2  50C   32.54 1:08.89                                                                P             N36
G08SS          Stuart, Madisyn             90017726    1 2  50C   31.48 1:08.30                                                                F             N16
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF  501112 UNOV11012025   27.90S   28.06S            28.23S 6 8 1 3 15 14       49501      NN32
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF  503403 UNOV11022025   37.90S   37.22S                   3 3 0 0 34           9503      NN31
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF 1001409 UNOV11022025 1:00.60S 1:01.06S          1:01.17S 4 9 1 7 21 16       69501      NN03
G08SS          Stuart, Madisyn             90017726    1 2  50C   28.92 1:01.06                                                                P             N26
G08SS          Stuart, Madisyn             90017726    1 2  50C   28.97 1:01.17                                                                F             N26
D08SS      Stuart, Madisyn             90017726    AGBR0103200916FF  504411 UNOV11022025   29.70S   30.23S            30.09S 5 8 1 3 16 14       49504      NN32
D08SS      Taylor, Jon                 743734      AGBR0908200421MM 4001101 UNOV11012025 4:04.59S 4:13.28S          4:12.43S 3 5 1 1  7  6  5.   6950100    NN51
D3743734                                                                                                                                                     N38
G08SS          Taylor, Jon                 743734      1 8  50C   28.41   59.31 1:30.84 2:02.96 2:35.45 3:08.75 3:41.37 4:13.28                P             N68
G08SS          Taylor, Jon                 743734      1 8  50C   28.55   59.78 1:31.54 2:03.67 2:35.67 3:08.09 3:40.50 4:12.43                F             N68
D08SS      Taylor, Jon                 743734      AGBR0908200421MM 1001109 UNOV11012025   54.90S   56.35S                   4 9 0 0 33           9501      NN69
G08SS          Taylor, Jon                 743734      1 2  50C   26.65   56.35                                                                P             N24
D08SS      Taylor, Jon                 743734      AGBR0908200421MM 8001502 UNOV11022025 8:31.86S                   8:47.85S     3 6     7  4.   6950100    NN40
G08SS          Taylor, Jon                 743734      116  50C   29.30 1:01.55 1:34.64 2:07.59 2:40.40 3:13.31 3:46.50 4:20.03 4:53.41 5:26.83F             N20
G08SS          Taylor, Jon                 743734      216  50C 6:00.13 6:33.64 7:07.65 7:41.53 8:15.36 8:47.85                                F             N77
D08SS      Taylor, Summer C            90040684    AGBR0522201213FF 2004405 UNOV11022025 3:05.01S 2:57.12S                   1 8 0 0 31           9504      NN61
D390040684                                                                                                                                                   N58
G08SS          Taylor, Summer C            90040684    1 4  50C   38.35 1:23.89 2:11.09 2:57.12                                                P             N57
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 2004105 UNOV11012025 2:04.20S 2:09.58S          2:05.97S 3 4 1 6  4  3  8.   3950400    NN23
D390004899                                                                                                                                                   N58
G08SS          Tetlow, Fraser A            90004899    1 4  50C   27.84 1:00.83 1:35.49 2:09.58                                                P             N57
G08SS          Tetlow, Fraser A            90004899    1 4  50C   28.06   59.78 1:32.98 2:05.97                                                F             N37
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM  504111 UNOV11012025   26.20S   26.68S            26.45S 4 1 2 9 10  8  3.   8950400    NN52
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 2003113 UNOV11012025 2:22.10S 2:26.30S          2:33.34S 3 5 1 1  7 10  1.   0950300    NN13
G08SS          Tetlow, Fraser A            90004899    1 4  50C   32.67 1:10.11 1:48.23 2:26.30                                                P             N47
G08SS          Tetlow, Fraser A            90004899    1 4  50C   32.94 1:11.24 1:52.44 2:33.34                                                F             N37
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 4005201 UNOV11012025 4:34.56S                   4:39.76S     5 6     4  7.   4950500    NN02
G08SS          Tetlow, Fraser A            90004899    1 8  50C   28.71 1:01.83 1:38.69 2:14.98 2:55.23 3:35.41 4:08.73 4:39.76                F             N50
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 2005406 UNOV11022025 2:08.60S 2:11.49S          2:09.44S 2 4 1 7  7  4  7.   4950500    NN23
G08SS          Tetlow, Fraser A            90004899    1 4  50C   27.21 1:01.22 1:39.87 2:11.49                                                P             N47
G08SS          Tetlow, Fraser A            90004899    1 4  50C   27.26 1:01.45 1:39.41 2:09.44                                                F             N47
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 1004410 UNOV11022025   56.40S   57.40S            56.90S 2 5 2 6  4  5  6.   5950400    NN52
G08SS          Tetlow, Fraser A            90004899    1 2  50C   26.69   57.40                                                                P             N85
G08SS          Tetlow, Fraser A            90004899    1 2  50C   26.23   56.90                                                                F             N75
D08SS      Tetlow, Fraser A            90004899    AGBR0810200619MM 2002414 UNOV11022025 2:15.30S 2:13.99S          2:20.20S 3 6 1 0  9 10  1.   0950200    NN13
G08SS          Tetlow, Fraser A            90004899    1 4  50C   29.88 1:03.82 1:39.03 2:13.99                                                P             N57
G08SS          Tetlow, Fraser A            90004899    1 4  50C   31.22 1:06.67 1:43.92 2:20.20                                                F             N37
D08SS      Thomson, Fergus             1231394     AGBR0206200718MM 4005201 UNOV11012025 4:25.32S                   4:31.03S     5 4     1 10.   1950500    NN91
D31231394                                                                                                                                                    N38
G08SS          Thomson, Fergus             1231394     1 8  50C   28.10 1:00.52 1:33.40 2:05.55 2:44.90 3:25.51 3:59.18 4:31.03                F             N30
D08SS      Thomson, Fergus             1231394     AGBR0206200718MM 2005406 UNOV11022025 2:10.10S 2:07.10S          2:07.02S 4 3 1 4  1  1 10.   1950500    NN13
G08SS          Thomson, Fergus             1231394     1 4  50C   27.00   58.21 1:36.26 2:07.10                                                P             N27
G08SS          Thomson, Fergus             1231394     1 4  50C   27.62   58.64 1:37.09 2:07.02                                                F             N37
D08SS      Thomson, Fergus             1231394     AGBR0206200718MM 2002414 UNOV11022025 2:05.00S 2:00.22S          2:00.10S 2 4 1 4  1  1 10.   1950200    NN03
G08SS          Thomson, Fergus             1231394     1 4  50C   27.74   57.67 1:28.14 2:00.22                                                P             N37
G08SS          Thomson, Fergus             1231394     1 4  50C   27.88   58.26 1:29.57 2:00.10                                                F             N37
D08SS      Travis, Cameron             930076      AGBR0121200421MM 4001101 UNOV11012025 3:55.30S 4:07.44S          4:04.32S 4 4 1 3  3  2  9.   2950100    NN92
D3930076                                                                                                                                                     N38
G08SS          Travis, Cameron             930076      1 8  50C   27.49   57.40 1:27.92 1:59.25 2:30.29 3:01.97 3:34.44 4:07.44                P             N10
G08SS          Travis, Cameron             930076      1 8  50C   27.06   56.70 1:26.91 1:58.14 2:29.14 3:00.78 3:32.83 4:04.32                F             N00
D08SS      Travis, Cameron             930076      AGBR0121200421MM 1001109 UNOV11012025   51.30S   53.68S                   2 5 0 0 11           9501      NN01
G08SS          Travis, Cameron             930076      1 2  50C   25.52   53.68                                                                P             N75
D08SS      Travis, Cameron             930076      AGBR0121200421MM 2001402 UNOV11022025 1:50.10S 1:59.02S                   3 4 0 0 11           9501      NN41
G08SS          Travis, Cameron             930076      1 4  50C   26.73   56.59 1:27.98 1:59.02                                                P             N27
D08SS      Travis, Cameron             930076      AGBR0121200421MM 8001502 UNOV11022025 8:08.15S                   8:35.66S     3 4     3  8.   3950100    NN81
G08SS          Travis, Cameron             930076      116  50C   28.88 1:01.65 1:34.35 2:07.35 2:39.99 3:11.96 3:43.88 4:16.16 4:48.41 5:20.89F             N91
G08SS          Travis, Cameron             930076      216  50C 5:53.53 6:26.60 6:59.67 7:32.19 8:04.87 8:35.66                                F             N39
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 2005526 UNOV11022025 2:26.92S 2:25.73S                   3 6      9           9505      NN21
D390021548                                                                                                                                                   N48
G08SS          Valcov, Daniel A            90021548    1 4  50C   29.67 1:07.85 1:52.63 2:25.73                                                P             N27
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 1002107 UNOV11012025 1:05.00S 1:04.64S                   2 8 0 0 27           9502      NN31
G08SS          Valcov, Daniel A            90021548    1 2  50C   30.85 1:04.64                                                                P             N75
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM  504111 UNOV11012025   28.00S   27.27S            27.72S 2 1 1 6 20 16       69504      NN91
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 2001522 UNOV11022025 2:08.77S 2:05.78S                   1 5      3           9501      NN11
G08SS          Valcov, Daniel A            90021548    1 4  50C   28.39 1:00.37 1:33.06 2:05.78                                                P             N27
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 1001109 UNOV11012025   56.20S   56.36S                   5 4 0 0 34           9501      NN90
G08SS          Valcov, Daniel A            90021548    1 2  50C   26.74   56.36                                                                P             N55
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 2002414 UNOV11022025 2:28.42S 2:21.82S                   1 9 0 0 25           9502      NN31
G08SS          Valcov, Daniel A            90021548    1 4  50C   32.54 1:08.29 1:45.36 2:21.82                                                P             N27
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 2001402 UNOV11022025 2:08.77S 2:05.78S                   5 5 0 0 34           9501      NN41
G08SS          Valcov, Daniel A            90021548    1 4  50C   28.39 1:00.37 1:33.06 2:05.78                                                P             N27
D08SS      Valcov, Daniel A            90021548    AGBR0505201114MM 2005406 UNOV11022025 2:26.92S 2:25.73S                   7 6 0 0 46           9505      NN41
G08SS          Valcov, Daniel A            90021548    1 4  50C   29.67 1:07.85 1:52.63 2:25.73                                                P             N27
D08SS      Van Blerk, Micah            1178632     AGBR0806200520MM  503103 UNOV11012025   28.30S   29.87S            29.75S 5 4 3 7  6  6  5.   6950300    NN12
D31178632                                                                                                                                                    N48
D08SS      Van Blerk, Micah            1178632     AGBR0806200520MM  504111 UNOV11012025   25.60S   26.33S            26.14S 5 6 2 0  9  4  7.   4950400    NN02
D08SS      Van Blerk, Micah            1178632     AGBR0806200520MM 1003408 UNOV11022025 1:05.10S 1:07.07S          1:04.84S 3 3 2 0  9  5  6.   5950300    NN72
G08SS          Van Blerk, Micah            1178632     1 2  50C   30.96 1:07.07                                                                P             N65
G08SS          Van Blerk, Micah            1178632     1 2  50C   30.29 1:04.84                                                                F             N55
D08SS      Van Blerk, Micah            1178632     AGBR0806200520MM  501412 UNOV11022025   24.20S   24.37S            23.79S 5 2 2 0  9  6  5.   6950100    NN02
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 4001101 UNOV11012025 4:35.46S 4:32.84S                   1 6 0 0 30           9501      NN24
D390020141      Tim                                                                                                                                          N49
G08SS          Veyron La Croix, Timothe    90020141    1 8  50C   29.58 1:02.92 1:37.28 2:12.69 2:47.68 3:22.95 3:58.59 4:32.84                P             N23
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 4005201 UNOV11012025 5:24.20S                   5:11.39S     1 3    33       19505      NN14
G08SS          Veyron La Croix, Timothe    90020141    1 8  50C   31.17 1:09.92 1:49.65 2:28.22 3:16.31 4:03.51 4:38.11 5:11.39                F             N92
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM  502404 UNOV11022025   30.44S   29.58S            29.78S 2 4 1 9 26 19       99502      NN94
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 2002414 UNOV11022025 2:21.93S 2:23.87S                   3 0 0 0 31           9502      NN24
G08SS          Veyron La Croix, Timothe    90020141    1 4  50C   33.12 1:09.28 1:46.72 2:23.87                                                P             N10
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 2005526 UNOV11022025 2:28.60S 2:26.69S                   2 2     12           9505      NN14
G08SS          Veyron La Croix, Timothe    90020141    1 4  50C   29.73 1:07.47 1:53.70 2:26.69                                                P             N20
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 1002107 UNOV11012025 1:07.90S 1:05.35S                   8 6 0 0 33           9502      NN24
G08SS          Veyron La Croix, Timothe    90020141    1 2  50C   31.65 1:05.35                                                                P             N68
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 1001109 UNOV11012025   58.90S 1:00.02S                   7 0 0 0 56           9501      NN04
G08SS          Veyron La Croix, Timothe    90020141    1 2  50C   28.30 1:00.02                                                                P             N58
D08SS      Veyron La Croix, Timothe    90020141    AGBR0413201015MM 2005406 UNOV11022025 2:28.60S 2:26.69S                   6 2 0 0 49           9505      NN44
G08SS          Veyron La Croix, Timothe    90020141    1 4  50C   29.73 1:07.47 1:53.70 2:26.69                                                P             N20
D08SS      Wallace, Jack E             90034137    AGBR0928200619MM  503103 UNOV11012025   30.00S   30.83S                   7 2 0 0 16           9503      NN30
D390034137                                                                                                                                                   N48
D08SS      Wallace, Jack E             90034137    AGBR0928200619MM 2003113 UNOV11012025 2:33.80S 2:39.33S                   4 1 0 0 29           9503      NN90
G08SS          Wallace, Jack E             90034137    1 4  50C   35.00 1:15.73 1:57.34 2:39.33                                                P             N66
D08SS      Wallace, Jack E             90034137    AGBR0928200619MM 1003408 UNOV11022025 1:07.61S 1:09.05S                   4 6 0 0 14           9503      NN90
G08SS          Wallace, Jack E             90034137    1 2  50C   31.93 1:09.05                                                                P             N25
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 1004110 UNOV11012025 1:17.48S 1:22.88S                   7 1 0 0 56           9504      NN03
D390018983                                                                                                                                                   N58
G08SS          Walters, Charlotte          90018983    1 2  50C   37.86 1:22.88                                                                P             N47
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 4001521 UNOV11022025 5:11.16S      NSS                   1 3      0           9501      NN42
G08SS          Walters, Charlotte          90018983    1 8  50C                                                                                P             N26
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF  503403 UNOV11022025   38.46S   41.69S                   2 3 0 0 58           9503      NN52
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 2001102 UNOV11012025 2:24.31S 2:37.38S                   6 0 0 0 53           9501      NN92
G08SS          Walters, Charlotte          90018983    1 4  50C   34.57 1:14.24 1:55.87 2:37.38                                                P             N98
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 1003108 UNOV11012025 1:24.28S 1:32.17S                   6 4 0 0 52           9503      NN92
G08SS          Walters, Charlotte          90018983    1 2  50C   42.70 1:32.17                                                                P             N37
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 2002114 UNOV11012025 2:43.93S 3:01.95S                   5 0 0 0 46           9502      NN92
G08SS          Walters, Charlotte          90018983    1 4  50C   40.67 1:26.76 2:14.11 3:01.95                                                P             N88
D08SS      Walters, Charlotte          90018983    AGBR0516201015FF 4001401 UNOV11022025 5:11.16S      NSS                   5 3 0 0  0           9501      NN52
G08SS          Walters, Charlotte          90018983    1 8  50C                                                                                P             N26
D08SS      Weatherhead, Zachary        90015057    AGBR1018201015MM 1002107 UNOV11012025 1:02.70S 1:00.89S          1:02.28S 2 2 2 0  9 10  1.   0950200    NN94
D390015057      Zach                                                                                                                                         N89
G08SS          Weatherhead, Zachary        90015057    1 2  50C   29.57 1:00.89                                                                P             N97
G08SS          Weatherhead, Zachary        90015057    1 2  50C   30.14 1:02.28                                                                F             N77
D08SS      Weatherhead, Zachary        90015057    AGBR1018201015MM 4005201 UNOV11012025 5:04.58S                   5:06.93S     3 1    30       89505      NN53
G08SS          Weatherhead, Zachary        90015057    1 8  50C   30.69 1:08.24 1:47.24 2:25.47 3:10.84 3:56.52 4:30.84 5:06.93                F             N22
D08SS      Weatherhead, Zachary        90015057    AGBR1018201015MM 2005406 UNOV11022025 2:21.84S 2:17.77S                   1 5 0 0 16           9505      NN63
G08SS          Weatherhead, Zachary        90015057    1 4  50C   30.51 1:04.23 1:46.53 2:17.77                                                P             N39
D08SS      Weatherhead, Zachary        90015057    AGBR1018201015MM 1004410 UNOV11022025 1:02.44S 1:02.82S          1:01.11S 1 5 1 8 29 14       49504      NN74
G08SS          Weatherhead, Zachary        90015057    1 2  50C   29.35 1:02.82                                                                P             N97
G08SS          Weatherhead, Zachary        90015057    1 2  50C   28.95 1:01.11                                                                F             N87
D08SS      Weatherhead, Zachary        90015057    AGBR1018201015MM  501412 UNOV11022025   26.10S   25.91S            25.90S 2 3 1 9 30 19       99501      NN04
D08SS      Wilson, Joshua              90022629    AGBR0326201213MM 2003113 UNOV11012025 3:02.51S 2:57.43S                   5 3 0 0 60           9503      NN41
D390022629      Josh                                                                                                                                         N99
G08SS          Wilson, Joshua              90022629    1 4  50C   40.55 1:25.77 2:12.34 2:57.43                                                P             N27
D08SS      Wilson, Joshua              90022629    AGBR0326201213MM 1003528 UNOV11022025 1:23.68S 1:21.91S                   2 1     36           9503      NN31
G08SS          Wilson, Joshua              90022629    1 2  50C   38.97 1:21.91                                                                P             N85
D08SS      Wilson, Joshua              90022629    AGBR0326201213MM 1003408 UNOV11022025 1:23.68S 1:21.91S                   6 1 0 0 72           9503      NN41
G08SS          Wilson, Joshua              90022629    1 2  50C   38.97 1:21.91                                                                P             N85
D08SS      Wong, Maslin                90026758    AGBR0502200817MM  503103 UNOV11012025   31.20S   31.24S                   7 8 0 0 18           9503      NN00
D390026758                                                                                                                                                   N58
D08SS      Wong, Maslin                90026758    AGBR0502200817MM 1003408 UNOV11022025 1:09.60S 1:10.13S                   2 7 0 0 17           9503      NN60
G08SS          Wong, Maslin                90026758    1 2  50C   33.13 1:10.13                                                                P             N94
D08SS      Wood, Alison                1266640     AGBR0625200718FF  502104 UNOV11012025   29.96S   30.37S            30.00S 4 6 2 0  9  8  3.   8950200    NN11
D31266640                                                                                                                                                    N38
D08SS      Wood, Alison                1266640     AGBR0625200718FF 2002114 UNOV11012025 2:23.19S 2:22.43S          2:20.94S 2 5 1 6  4  3  8.   3950200    NN91
G08SS          Wood, Alison                1266640     1 4  50C   32.34 1:08.78 1:45.91 2:22.43                                                P             N36
G08SS          Wood, Alison                1266640     1 4  50C   32.17 1:07.98 1:44.65 2:20.94                                                F             N26
D08SS      Wood, Alison                1266640     AGBR0625200718FF 1002407 UNOV11022025 1:05.90S 1:06.37S          1:06.00S 3 6 2 8  8  8  2.   8950250    NN91
G08SS          Wood, Alison                1266640     1 2  50C   31.32 1:06.37                                                                P             N84
G08SS          Wood, Alison                1266640     1 2  50C   31.52 1:06.00                                                                F             N74
D08SS      Wood, Alison                1266640     AGBR0625200718FF  504411 UNOV11022025   28.83S   28.99S            28.82S 7 2 2 7  6  7  4.   7950400    NN31
D08SS      Wood, Maree E               900916      AGBR0322200322FF  502104 UNOV11012025   28.72S   29.02S            28.90S 3 4 2 5  2  3  8.   3950200    NN70
D3900916                                                                                                                                                     N38
D08SS      Wood, Maree E               900916      AGBR0322200322FF  501112 UNOV11012025   26.66S   27.41S                   7 3 0 0 10           9501      NN49
D08SS      Wood, Maree E               900916      AGBR0322200322FF 1002407 UNOV11022025 1:04.10S 1:03.53S          1:03.18S 3 5 2 3  3  3  8.   3950200    NN31
G08SS          Wood, Maree E               900916      1 2  50C   30.64 1:03.53                                                                P             N44
G08SS          Wood, Maree E               900916      1 2  50C   30.68 1:03.18                                                                F             N44
D08SS      Wood, Maree E               900916      AGBR0322200322FF  504411 UNOV11022025   28.12S   28.65S            28.59S 5 5 2 2  5  5  5.   5950450    NN80
D08SS      Wood, Rachel                70689       AGBR0124199332FF 1004110 UNOV11012025 1:10.23S 1:08.87S                   1 7 0 0 18           9504      NN10
D370689                                                                                                                                                      N28
G08SS          Wood, Rachel                70689       1 2  50C   31.78 1:08.87                                                                P             N64
D08SS      Wood, Rachel                70689       AGBR0124199332FF 2004405 UNOV11022025 2:39.94S 2:42.24S                   2 1 0 0 20           9504      NN20
G08SS          Wood, Rachel                70689       1 4  50C   33.62 1:12.75 1:56.59 2:42.24                                                P             N06
D08SS      Wood, Rachel                70689       AGBR0124199332FF  504411 UNOV11022025   29.40S   29.96S                   7 1 0 0 15           9504      NN79
D08SS      Wright, Logan               90022428    AGBR1031201015MM 4001101 UNOV11012025 4:26.80S 4:28.11S                   2 8 0 0 22           9501      NN80
D390022428                                                                                                                                                   N48
G08SS          Wright, Logan               90022428    1 8  50C   29.17 1:01.65 1:35.29 2:09.21 2:43.43 3:18.04 3:53.42 4:28.11                P             N69
D08SS      Wright, Logan               90022428    AGBR1031201015MM 1002107 UNOV11012025 1:06.47S 1:06.16S                   1 0 0 0 36           9502      NN80
G08SS          Wright, Logan               90022428    1 2  50C   31.98 1:06.16                                                                P             N35
D08SS      Wright, Logan               90022428    AGBR1031201015MM 4005201 UNOV11012025 5:12.80S                   4:59.18S     2 3    22       29505      NN80
G08SS          Wright, Logan               90022428    1 8  50C   31.32 1:08.43 1:45.75 2:22.75 3:07.27 3:52.92 4:26.75 4:59.18                F             N79
D08SS      Wright, Logan               90022428    AGBR1031201015MM 2001402 UNOV11022025 2:05.51S 2:04.34S                   1 1 0 0 32           9501      NN80
G08SS          Wright, Logan               90022428    1 4  50C   28.65   59.98 1:32.92 2:04.34                                                P             N66
D08SS      Wright, Logan               90022428    AGBR1031201015MM 2005406 UNOV11022025 2:23.80S 2:21.67S                   1 0 0 0 28           9505      NN90
G08SS          Wright, Logan               90022428    1 4  50C   30.41 1:06.42 1:49.97 2:21.67                                                P             N76
D08SS      Wright, Logan               90022428    AGBR1031201015MM 2002414 UNOV11022025 2:18.36S 2:17.65S                   4 7 0 0 14           9502      NN90
G08SS          Wright, Logan               90022428    1 4  50C   32.66 1:08.09 1:43.46 2:17.65                                                P             N86
D08SS      Wright, Logan               90022428    AGBR1031201015MM 8001502 UNOV11022025 9:16.53S                   9:22.01S     2 8    19       99501      NN90
G08SS          Wright, Logan               90022428    116  50C   30.87 1:05.76 1:40.90 2:16.54 2:51.71 3:27.05 4:02.77 4:38.34 5:13.89 5:49.79F             N31
G08SS          Wright, Logan               90022428    216  50C 6:25.82 7:01.28 7:37.00 8:12.58 8:47.83 9:22.01                                F             N68
D08SS      Wright, Logan               90022428    AGBR1031201015MM 1001109 UNOV11012025   58.00S   57.44S                   7 2 0 0 43           9501      NN40
G08SS          Wright, Logan               90022428    1 2  50C   28.22   57.44                                                                P             N05
D08SS      Yau, Hannah                 90034117    AGBR0124200916FF  502104 UNOV11012025   32.52S   33.21S                   4 0 0 0 30           9502      NN39
D390034117                                                                                                                                                   N48
E08SS      ASSNUAX  X 2006301 UNOV  011012025 1:39.50S                   1:38.88S     2 4     1                                                1N13001  X    N26
F08SS          SSNUAXALennox, Kieran              1297331     GBR0921200619M  1             1297331       Kieran                                             N10
G08SS          Lennox, Kieran              1297331     1 4  50C   22.69                                                                        F             N84
F08SS          SSNUAXABeeley, Tom                 820745      GBR0602199926M  2             820745                                                           N66
G08SS          Beeley, Tom                 820745      1 4  50C   46.50                                                                        F             N53
F08SS          SSNUAXAHawkins, Georgina           1246404     GBR1128200619F  3             1246404                                                          N98
G08SS          Hawkins, Georgina           1246404     1 4  50C 1:13.05                                                                        F             N16
F08SS          SSNUAXAPerry, Yasmin               769348      GBR0326200124F  4             769348        Yasmin                                             N89
G08SS          Perry, Yasmin               769348      1 4  50C 1:38.88                                                                        F             N84
E08SS      BSSNUAX  X 2006301 UNOV  011012025 1:41.19S                   1:39.86S     2 5     2                                                2N13001  X    N26
F08SS          SSNUAXBJenkinson, Jack             907378      GBR0904200619M  1             907378                                                           N18
G08SS          Jenkinson, Jack             907378      1 4  50C   23.47                                                                        F             N15
F08SS          SSNUAXBBatey, Ewan                 1310030     GBR0517200520M  2             1310030                                                          N46
G08SS          Batey, Ewan                 1310030     1 4  50C   46.90                                                                        F             N53
F08SS          SSNUAXBMishchenko, Mariia          90039978    GBR0225200619F  3             90039978      Mary                                               N11
G08SS          Mishchenko, Mariia          90039978    1 4  50C 1:13.09                                                                        F             N66
F08SS          SSNUAXBWood, Maree E               900916      GBR0322200322F  4             900916                                                           N66
G08SS          Wood, Maree E               900916      1 4  50C 1:39.86                                                                        F             N93
E08SS      CSSNUAX  X 2006301 UNOV  011012025 1:42.48S                   1:43.64S     2 3     3                                                3N13001  X    N26
F08SS          SSNUAXCMydliar, Matus              1294585     GBR0421200520M  1             1294585                                                          N08
G08SS          Mydliar, Matus              1294585     1 4  50C   24.54                                                                        F             N94
F08SS          SSNUAXCTravis, Cameron             930076      GBR0121200421M  2             930076                                                           N18
G08SS          Travis, Cameron             930076      1 4  50C   48.40                                                                        F             N15
F08SS          SSNUAXCMiti, Tamenji Ada           1786377     GBR1230200718F  3             1786377                                                          N48
G08SS          Miti, Tamenji Ada           1786377     1 4  50C 1:16.54                                                                        F             N55
F08SS          SSNUAXCSteele, Sophie M            1293413     GBR1113200718F  4             1293413                                                          N18
G08SS          Steele, Sophie M            1293413     1 4  50C 1:43.64                                                                        F             N25
E08SS      DSSNUAX  X 2006301 UNOV  011012025 1:44.22S                   1:45.66S     2 1     7                                                6N13001  X    N26
F08SS          SSNUAXDHopkins, Lewis              90021723    GBR0813200916M  1             90021723                                                         N28
G08SS          Hopkins, Lewis              90021723    1 4  50C   25.38                                                                        F             N05
F08SS          SSNUAXDCantley, Alex               90019608    GBR0721201015M  2             90019608                                                         N77
G08SS          Cantley, Alex               90019608    1 4  50C   50.59                                                                        F             N54
F08SS          SSNUAXDKirkwood, Jessica           90011236    GBR0214200916F  3             90011236                                                         N29
G08SS          Kirkwood, Jessica           90011236    1 4  50C 1:18.38                                                                        F             N36
F08SS          SSNUAXDLeune, Mya                  90015843    GBR0209201015F  4             90015843                                                         N56
G08SS          Leune, Mya                  90015843    1 4  50C 1:45.66                                                                        F             N63
E08SS      ASSNUAX  X 2007601 UNOV  011022025 1:46.62S                   1:47.39S     2 4     1                                                1N13005  X    N26
F08SS          SSNUAXAFerguson, Jamie W           946980      GBR1019200322M  1             946980        Jamie                                              N10
G08SS          Ferguson, Jamie W           946980      1 4  50C   24.72                                                                        F             N45
F08SS          SSNUAXAVan Blerk, Micah            1178632     GBR0806200520M  2             1178632                                                          N08
G08SS          Van Blerk, Micah            1178632     1 4  50C   53.65                                                                        F             N94
F08SS          SSNUAXAPerry, Yasmin               769348      GBR0326200124F  3             769348        Yasmin                                             N89
G08SS          Perry, Yasmin               769348      1 4  50C 1:21.02                                                                        F             N74
F08SS          SSNUAXAHawkins, Georgina           1246404     GBR1128200619F  4             1246404                                                          N09
G08SS          Hawkins, Georgina           1246404     1 4  50C 1:47.39                                                                        F             N16
E08SS      BSSNUAX  X 2007601 UNOV  011022025 1:49.61S                   1:50.20S     2 5     2                                                2N13005  X    N26
F08SS          SSNUAXBWood, Maree E               900916      GBR0322200322F  1             900916                                                           N66
G08SS          Wood, Maree E               900916      1 4  50C   28.83                                                                        F             N73
F08SS          SSNUAXBArthur, Andrew              894228      GBR0604200223M  2             894228        Andrew                                             N00
G08SS          Arthur, Andrew              894228      1 4  50C   56.88                                                                        F             N84
F08SS          SSNUAXBNaumovich, Mikhail          1444701     GBR0921200619M  3             1444701                                                          N49
G08SS          Naumovich, Mikhail          1444701     1 4  50C 1:22.67                                                                        F             N56
F08SS          SSNUAXBSteele, Sophie M            1293413     GBR1113200718F  4             1293413                                                          N18
G08SS          Steele, Sophie M            1293413     1 4  50C 1:50.20                                                                        F             N25
E08SS      CSSNUAX  X 2007601 UNOV  011022025 1:50.56S                   1:52.41S     2 6     3                                                3N13005  X    N26
F08SS          SSNUAXCBeeley, Tom                 820745      GBR0602199926M  1             820745                                                           N66
G08SS          Beeley, Tom                 820745      1 4  50C   25.45                                                                        F             N53
F08SS          SSNUAXCMitchell, Jack              90001541    GBR0422200619M  2             90001541                                                         N87
G08SS          Mitchell, Jack              90001541    1 4  50C   55.06                                                                        F             N74
F08SS          SSNUAXCMiti, Tamenji Ada           1786377     GBR1230200718F  3             1786377                                                          N48
G08SS          Miti, Tamenji Ada           1786377     1 4  50C 1:24.07                                                                        F             N55
F08SS          SSNUAXCWood, Alison                1266640     GBR0625200718F  4             1266640                                                          N17
G08SS          Wood, Alison                1266640     1 4  50C 1:52.41                                                                        F             N24
E08SS      DSSNUAX  X 2007601 UNOV  011022025 1:52.19S                   1:56.90S     2 2     7                                                6N13005  X    N36
F08SS          SSNUAXDKirkwood, Jessica           90011236    GBR0214200916F  1             90011236                                                         N29
G08SS          Kirkwood, Jessica           90011236    1 4  50C   29.99                                                                        F             N16
F08SS          SSNUAXDCantley, Alex               90019608    GBR0721201015M  2             90019608                                                         N77
G08SS          Cantley, Alex               90019608    1 4  50C 1:01.92                                                                        F             N74
F08SS          SSNUAXDHodzic, Oliver              90027964    GBR0621201015M  3             90027964                                                         N28
G08SS          Hodzic, Oliver              90027964    1 4  50C 1:29.47                                                                        F             N25
F08SS          SSNUAXDLeune, Mya                  90015843    GBR0209201015F  4             90015843                                                         N56
G08SS          Leune, Mya                  90015843    1 4  50C 1:56.90                                                                        F             N63
C18SS      SSNWDXWesthill District Asc         Westhill        Westhill Swimming Pool                      Aberdeen            ABAB32 6XZ                    N12
D08SS      Carter, Finn                90027102    AGBR0326201213MM  503103 UNOV11012025   34.75S   35.05S                   2 8 0 0 56           9503      NN99
D390027102                                                                                                                                                   N48
D08SS      Carter, Finn                90027102    AGBR0326201213MM 2004105 UNOV11012025 2:42.74S 2:40.96S                   1 0 0 0 38           9504      NN40
G08SS          Carter, Finn                90027102    1 4  50C   35.97 1:16.52 2:00.10 2:40.96                                                P             N26
D08SS      Carter, Finn                90027102    AGBR0326201213MM 2003113 UNOV11012025 2:50.01S 2:48.80S                   8 1 0 0 52           9503      NN40
G08SS          Carter, Finn                90027102    1 4  50C   37.45 1:20.96 2:05.25 2:48.80                                                P             N26
D08SS      Carter, Finn                90027102    AGBR0326201213MM 1003528 UNOV11022025 1:20.10S 1:19.96S                   3 8     24           9503      NN20
G08SS          Carter, Finn                90027102    1 2  50C   38.07 1:19.96                                                                P             N84
D08SS      Carter, Finn                90027102    AGBR0326201213MM 1003408 UNOV11022025 1:20.10S 1:19.96S                   7 8 0 0 60           9503      NN40
G08SS          Carter, Finn                90027102    1 2  50C   38.07 1:19.96                                                                P             N84
D08SS      Carter, Sienna              90006418    AGBR0125200916FF 1003108 UNOV11012025 1:21.42S 1:23.74S                   3 9 0 0 39           9503      NN21
D390006418                                                                                                                                                   N48
G08SS          Carter, Sienna              90006418    1 2  50C   39.68 1:23.74                                                                P             N65
D08SS      Carter, Sienna              90006418    AGBR0125200916FF  503403 UNOV11022025   38.33S   38.37S                   2 4 0 0 41           9503      NN60
D08SS      Carter, Sienna              90006418    AGBR0125200916FF 2003413 UNOV11022025 2:55.53S 3:00.45S                   2 0 0 0 40           9503      NN11
G08SS          Carter, Sienna              90006418    1 4  50C   40.50 1:26.44 2:12.78 3:00.45                                                P             N07
D08SS      Carter, Sienna              90006418    AGBR0125200916FF 4005501 UNOV11022025 5:52.55S                        NSS     1 3     0       09505      NN80
G08SS          Carter, Sienna              90006418    1 8  50C                                                                                F             N34
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM  503103 UNOV11012025   35.20S   33.62S                   1 2 0 0 42           9503      NN79
D390040066                                                                                                                                                   N48
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM  502404 UNOV11022025   31.82S   31.78S                   1 3 0 0 56           9502      NN89
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM  501412 UNOV11022025   26.58S   26.53S                   1 6 0 0 44           9501      NN89
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 2002534 UNOV11022025 2:30.21S 2:31.24S                   1 4      7           9502      NN00
G08SS          Chooi, Ethan                90040066    1 4  50C   35.16 1:14.33 1:54.36 2:31.24                                                P             N16
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 1003528 UNOV11022025 1:19.24S 1:15.46S                   4 1     11           9503      NN20
G08SS          Chooi, Ethan                90040066    1 2  50C   35.14 1:15.46                                                                P             N74
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 2003113 UNOV11012025 2:49.18S 2:43.79S                   8 2 0 0 41           9503      NN40
G08SS          Chooi, Ethan                90040066    1 4  50C   35.89 1:17.75 2:01.18 2:43.79                                                P             N36
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 1002107 UNOV11012025 1:13.12S 1:10.01S                   5 7 0 0 59           9502      NN30
G08SS          Chooi, Ethan                90040066    1 2  50C   33.87 1:10.01                                                                P             N74
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 1003408 UNOV11022025 1:19.24S 1:15.46S                   8 1 0 0 46           9503      NN40
G08SS          Chooi, Ethan                90040066    1 2  50C   35.14 1:15.46                                                                P             N74
D08SS      Chooi, Ethan                90040066    AGBR1217201015MM 2002414 UNOV11022025 2:30.21S 2:31.24S                   5 4 0 0 45           9502      NN30
G08SS          Chooi, Ethan                90040066    1 4  50C   35.16 1:14.33 1:54.36 2:31.24                                                P             N16
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF  502104 UNOV11012025   33.00S   32.63S                   2 4 0 0 25           9502      NN30
D390003288                                                                                                                                                   N48
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF 1003108 UNOV11012025 1:22.62S 1:22.25S                   1 6 0 0 28           9503      NN90
G08SS          Coutts, Gemma               90003288    1 2  50C   39.03 1:22.25                                                                P             N35
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF 2002114 UNOV11012025 2:33.28S 2:30.48S                   3 0 0 0 15           9502      NN80
G08SS          Coutts, Gemma               90003288    1 4  50C   35.47 1:13.72 1:52.59 2:30.48                                                P             N86
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF  503403 UNOV11022025   38.56S   38.71S                   2 7 0 0 47           9503      NN40
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF 1002407 UNOV11022025 1:10.78S 1:11.07S                   4 0 0 0 22           9502      NN80
G08SS          Coutts, Gemma               90003288    1 2  50C   33.90 1:11.07                                                                P             N35
D08SS      Coutts, Gemma               90003288    AGBR0226200817FF 4005501 UNOV11022025 5:31.69S                        NSS     3 8     0       09505      NN60
G08SS          Coutts, Gemma               90003288    1 8  50C                                                                                F             N14
D08SS      Joensen, Eilidh             90019451    AGBR0917200916FF 8001202 UNOV1101202510:03.17S                  10:02.18S     1 4    21       49501      NN61
D390019451                                                                                                                                                   N48
G08SS          Joensen, Eilidh             90019451    116  50C   32.93 1:10.62 1:48.36 2:26.92 3:05.51 3:44.02 4:22.90 5:01.44 5:39.53 6:17.86F             N81
G08SS          Joensen, Eilidh             90019451    216  50C 6:56.79 7:35.07 8:13.11 8:50.86 9:28.1010:02.18                                F             N39
D08SS      Joensen, Eilidh             90019451    AGBR0917200916FF 4001401 UNOV11022025 4:54.76S 4:50.62S                   2 1 0 0 20           9501      NN51
G08SS          Joensen, Eilidh             90019451    1 8  50C   32.14 1:08.64 1:45.91 2:22.82 3:00.21 3:37.37 4:14.67 4:50.62                P             N30
D08SS      Joensen, Eilidh             90019451    AGBR0917200916FF 2003533 UNOV11022025 3:02.02S      NSS                   2 5      0           9503      NN01
G08SS          Joensen, Eilidh             90019451    1 4  50C                                                                                P             N74
D08SS      Joensen, Eilidh             90019451    AGBR0917200916FF 2003413 UNOV11022025 3:02.02S      NSS                   6 5 0 0  0           9503      NN21
G08SS          Joensen, Eilidh             90019451    1 4  50C                                                                                P             N74
D08SS      Kay, Isla                   90002888    AGBR0303200817FF 2004405 UNOV11022025 2:45.06S 2:48.64S                   4 0 0 0 25           9504      NN39
D390002888                                                                                                                                                   N58
G08SS          Kay, Isla                   90002888    1 4  50C   36.58 1:20.70 2:06.31 2:48.64                                                P             N15
D08SS      Kay, Isla                   90002888    AGBR0303200817FF  504411 UNOV11022025   31.40S   32.78S                   3 0 0 0 54           9504      NN78
D08SS      Kay, Isla                   90002888    AGBR0303200817FF 1004110 UNOV11012025 1:11.98S 1:14.27S                   5 4 0 0 42           9504      NN29
G08SS          Kay, Isla                   90002888    1 2  50C   34.35 1:14.27                                                                P             N63
D08SS      Laing, Cameron              90016896    AGBR0415200916MM 2004105 UNOV11012025 2:58.95S 2:53.04S                   5 1 0 0 46           9504      NN31
D390016896                                                                                                                                                   N58
G08SS          Laing, Cameron              90016896    1 4  50C   33.80 1:17.06 2:05.24 2:53.04                                                P             N96
D08SS      Laing, Cameron              90016896    AGBR0415200916MM 1002107 UNOV11012025 1:10.39S 1:13.11S                   7 1 0 0 69           9502      NN21
G08SS          Laing, Cameron              90016896    1 2  50C   35.48 1:13.11                                                                P             N55
D08SS      Laing, Cameron              90016896    AGBR0415200916MM 2002534 UNOV11022025 2:33.03S 2:30.07S                   1 3      5           9502      NN90
G08SS          Laing, Cameron              90016896    1 4  50C   35.55 1:14.39 1:53.44 2:30.07                                                P             N07
D08SS      Laing, Cameron              90016896    AGBR0415200916MM 2002414 UNOV11022025 2:33.03S 2:30.07S                   5 3 0 0 43           9502      NN21
G08SS          Laing, Cameron              90016896    1 4  50C   35.55 1:14.39 1:53.44 2:30.07                                                P             N07
D08SS      Louw, Imogen                1291658     AGBR0824200817FF 1002407 UNOV11022025 1:08.16S 1:10.57S                   2 7 0 0 21           9502      NN50
D31291658                                                                                                                                                    N48
G08SS          Louw, Imogen                1291658     1 2  50C   34.18 1:10.57                                                                P             N94
D08SS      Louw, Imogen                1291658     AGBR0824200817FF 1001529 UNOV11022025 1:02.00S 1:04.66S                   4 4     22           9501      NN30
G08SS          Louw, Imogen                1291658     1 2  50C   30.99 1:04.66                                                                P             N94
D08SS      Louw, Imogen                1291658     AGBR0824200817FF 1001409 UNOV11022025 1:02.00S 1:04.66S                   8 4 0 0 54           9501      NN50
G08SS          Louw, Imogen                1291658     1 2  50C   30.99 1:04.66                                                                P             N94
D08SS      MacLennan, Finlay           90017821    AGBR0424201015MM 2003113 UNOV11012025 2:49.23S 2:48.67S                   7 2 0 0 50           9503      NN22
D390017821                                                                                                                                                   N48
G08SS          MacLennan, Finlay           90017821    1 4  50C   37.54 1:20.21 2:04.40 2:48.67                                                P             N97
D08SS      MacLennan, Finlay           90017821    AGBR0424201015MM 1003528 UNOV11022025 1:17.00S 1:17.44S                   5 6     14           9503      NN02
G08SS          MacLennan, Finlay           90017821    1 2  50C   36.46 1:17.44                                                                P             N56
D08SS      MacLennan, Finlay           90017821    AGBR0424201015MM 4001101 UNOV11012025 4:52.38S 4:45.63S                   6 3 0 0 38           9501      NN22
G08SS          MacLennan, Finlay           90017821    1 8  50C   31.77 1:06.94 1:42.83 2:19.44 2:56.14 3:33.10 4:10.10 4:45.63                P             N80
D08SS      MacLennan, Finlay           90017821    AGBR0424201015MM 1003408 UNOV11022025 1:17.00S 1:17.44S                   9 6 0 0 50           9503      NN12
G08SS          MacLennan, Finlay           90017821    1 2  50C   36.46 1:17.44                                                                P             N56
D08SS      McLaren, Ben                90019447    AGBR1027200916MM  501412 UNOV11022025   26.31S   26.58S                   2 1 0 0 46           9501      NN79
D390019447                                                                                                                                                   N58
D08SS      McLaren, Ben                90019447    AGBR1027200916MM 1002107 UNOV11012025 1:11.65S 1:10.69S                   6 0 0 0 60           9502      NN20
G08SS          McLaren, Ben                90019447    1 2  50C   34.13 1:10.69                                                                P             N54
D08SS      McLaren, Ben                90019447    AGBR1027200916MM 1003528 UNOV11022025 1:21.49S 1:20.49S                   2 4     27           9503      NN10
G08SS          McLaren, Ben                90019447    1 2  50C   38.04 1:20.49                                                                P             N54
D08SS      McLaren, Ben                90019447    AGBR1027200916MM 1003408 UNOV11022025 1:21.49S 1:20.49S                   6 4 0 0 63           9503      NN30
G08SS          McLaren, Ben                90019447    1 2  50C   38.04 1:20.49                                                                P             N54
D08SS      Milne, Grace                90024705    AGBR0922201114FF 2004405 UNOV11022025 2:58.17S 2:50.86S                   1 3 0 0 28           9504      NN30
D390024705                                                                                                                                                   N48
G08SS          Milne, Grace                90024705    1 4  50C   37.88 1:21.66 2:07.03 2:50.86                                                P             N26
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM  503103 UNOV11012025   35.10S   35.82S                   1 6 0 0 59           9503      NN12
D390031090      Matty                                                                                                                                        N30
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM  501412 UNOV11022025   26.30S   26.65S                   2 7 0 0 48           9501      NN12
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM 2004105 UNOV11012025 2:59.87S 2:59.96S                   5 8 0 0 47           9504      NN82
G08SS          Plaskota, Mateusz           90031090    1 4  50C   37.61 1:23.36 2:11.90 2:59.96                                                P             N48
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM 1001109 UNOV11012025   58.09S 1:02.16S                   6 2 0 0 60           9501      NN32
G08SS          Plaskota, Mateusz           90031090    1 2  50C   29.09 1:02.16                                                                P             N96
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM 1003528 UNOV11022025 1:17.75S 1:18.56S                   5 7     18           9503      NN52
G08SS          Plaskota, Mateusz           90031090    1 2  50C   36.49 1:18.56                                                                P             N07
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM 4001101 UNOV11012025 5:03.75S 4:55.99S                   5 1 0 0 43           9501      NN62
G08SS          Plaskota, Mateusz           90031090    1 8  50C   32.25 1:08.50 1:45.73 2:23.33 3:02.42 3:41.12 4:20.04 4:55.99                P             N21
D08SS      Plaskota, Mateusz           90031090    AGBR0709201015MM 1003408 UNOV11022025 1:17.75S 1:18.56S                   9 7 0 0 54           9503      NN72
G08SS          Plaskota, Mateusz           90031090    1 2  50C   36.49 1:18.56                                                                P             N07
C18          NYNXYthan Asc                     Ythan           Alice Currie                                                                GBR               N18
D08        Breeman, Sophie             90032202    A   0911201213FF 2004525 UNOV11022025 3:09.54S 2:49.66S                   1 6      1           9504      NN10
D390032202                                                                                                                                                   N48
G08            Breeman, Sophie             90032202    1 4  50C   38.34         2:06.86 2:49.66                                                P             N26
D08        Breeman, Sophie             90032202    A   0911201213FF 2004405 UNOV11022025 3:09.54S 2:49.66S                   5 6 0 0 26           9504      NN40
G08            Breeman, Sophie             90032202    1 4  50C   38.34         2:06.86 2:49.66                                                P             N26
D08        Buchan, Ruairi              90018436    A   0405200916MM 2004105 UNOV11012025 2:29.40S 2:29.08S                   3 0 0 0 26           9504      NN10
D390018436                                                                                                                                                   N58
G08            Buchan, Ruairi              90018436    1 4  50C   31.83 1:09.46 1:48.36 2:29.08                                                P             N56
D08        Buchan, Ruairi              90018436    A   0405200916MM 4005201 UNOV11012025 5:13.80S                   5:35.15S     2 6    42       99505      NN00
G08            Buchan, Ruairi              90018436    1 8  50C   32.12 1:11.13 1:54.38 2:36.27 3:27.00 4:17.40 4:56.67 5:35.15                F             N39
D08        Buchan, Ruairi              90018436    A   0405200916MM 8001502 UNOV11022025 9:39.49S                  10:03.21S     1 5    23       59501      NN10
G08            Buchan, Ruairi              90018436    116  50C   31.65 1:08.76 1:46.67 2:24.53 3:02.23 3:40.20 4:19.04 4:57.12 5:36.30 6:15.77F             N90
G08            Buchan, Ruairi              90018436    216  50C 6:53.38 7:32.49 8:10.67 8:49.96 9:28.4610:03.21                                F             N58
D08        Buchan, Ruairi              90018436    A   0405200916MM 2005526 UNOV11022025 2:33.99S 2:36.21S                   3 9     27           9505      NN00
G08            Buchan, Ruairi              90018436    1 4  50C   31.18 1:11.14 1:59.25 2:36.21                                                P             N46
D08        Buchan, Ruairi              90018436    A   0405200916MM 1004530 UNOV11022025 1:06.10S 1:09.41S                   1 3     11           9504      NN89
G08            Buchan, Ruairi              90018436    1 2  50C   31.51 1:09.41                                                                P             N05
D08        Buchan, Ruairi              90018436    A   0405200916MM 2001522 UNOV11022025 2:11.20S 2:21.66S                   2 2     19           9501      NN89
G08            Buchan, Ruairi              90018436    1 4  50C   31.49 1:07.60 1:44.52 2:21.66                                                P             N56
D08        Buchan, Ruairi              90018436    A   0405200916MM 2001402 UNOV11022025 2:11.20S 2:21.66S                   6 2 0 0 57           9501      NN00
G08            Buchan, Ruairi              90018436    1 4  50C   31.49 1:07.60 1:44.52 2:21.66                                                P             N56
D08        Buchan, Ruairi              90018436    A   0405200916MM 2005406 UNOV11022025 2:33.99S 2:36.21S                   7 9 0 0 65           9505      NN20
G08            Buchan, Ruairi              90018436    1 4  50C   31.18 1:11.14 1:59.25 2:36.21                                                P             N46
D08        Buchan, Ruairi              90018436    A   0405200916MM 1004410 UNOV11022025 1:06.10S 1:09.41S                   5 3 0 0 48           9504      NN00
G08            Buchan, Ruairi              90018436    1 2  50C   31.51 1:09.41                                                                P             N05
D08        Laidlaw, Ava                90022783    A   1104200916FF  501112 UNOV11012025   28.20S   29.31S                   7 9 0 0 38           9501      NN68
D390022783                                                                                                                                                   N58
D08        Laidlaw, Ava                90022783    A   1104200916FF 1004110 UNOV11012025 1:17.41S 1:22.18S                   5 7 0 0 54           9504      NN19
G08            Laidlaw, Ava                90022783    1 2  50C   37.78 1:22.18                                                                P             N24
D08        Laidlaw, Ava                90022783    A   1104200916FF 1001529 UNOV11022025 1:03.70S 1:04.20S                   2 7     17           9501      NN98
G08            Laidlaw, Ava                90022783    1 2  50C   31.47 1:04.20                                                                P             N14
D08        Laidlaw, Ava                90022783    A   1104200916FF 2001102 UNOV11012025 2:24.21S 2:23.87S                   6 8 0 0 48           9501      NN19
G08            Laidlaw, Ava                90022783    1 4  50C   33.25 1:09.38 1:46.43 2:23.87                                                P             N65
D08        Laidlaw, Ava                90022783    A   1104200916FF 1001409 UNOV11022025 1:03.70S 1:04.20S                   6 7 0 0 48           9501      NN19
G08            Laidlaw, Ava                90022783    1 2  50C   31.47 1:04.20                                                                P             N14
D08        Payton, Leah                1300379     A   0809200718FF  502104 UNOV11012025   33.87S   34.96S                   2 1 0 0 40           9502      NN78
D31300379                                                                                                                                                    N38
D08        Payton, Leah                1300379     A   0809200718FF 1003108 UNOV11012025 1:21.30S 1:22.82S                   4 9 0 0 33           9503      NN19
G08            Payton, Leah                1300379     1 2  50C   40.00 1:22.82                                                                P             N14
D08        Payton, Leah                1300379     A   0809200718FF  501112 UNOV11012025   29.99S   30.65S                   1 3 0 0 62           9501      NN78
D08        Payton, Leah                1300379     A   0809200718FF  503403 UNOV11022025   38.10S   37.14S                   3 8 0 0 32           9503      NN68
D08        Payton, Leah                1300379     A   0809200718FF 2003413 UNOV11022025 2:56.25S 2:55.48S                   1 5 0 0 29           9503      NN39
G08            Payton, Leah                1300379     1 4  50C   39.08 1:23.70 2:09.43 2:55.48                                                P             N75
D08        Payton, Leah                1300379     A   0809200718FF 4005501 UNOV11022025 5:34.11S                   5:54.59S     3 0    36       89505      NN29
G08            Payton, Leah                1300379     1 8  50C   39.02 1:25.68 2:09.79 2:55.95 3:44.56 4:34.45 5:14.50 5:54.59                F             N78
D08        Wilson, Calum               90033569    A   0619201312MM 2004105 UNOV11012025 2:57.13S 2:46.54S                   5 7 0 0 44           9504      NN99
D390033569                                                                                                                                                   N58
G08            Wilson, Calum               90033569    1 4  50C   36.71 1:20.69 2:04.42 2:46.54                                                P             N36
Z08Meet Res02Successful Build on 02/11/2025  1  1  30  30  1905   366   30   120  1843                                                                       N00
